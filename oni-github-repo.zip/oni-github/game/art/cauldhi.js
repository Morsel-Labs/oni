/* ===== HI-RES CAULDRONS (drawn in a 480-space canvas) ===== */
function cauldHi(g,cx,base,kind,fill,t,amount){
  const S=kind==='season';
  const C=S?{rim0:'#FFF2B0',rim1:'#FFC93A',rim2:'#C88A00',rim3:'#7A4E00',body0:'#4A3A3A',body1:'#2A2226',body2:'#18141A',liq0:'#FF8A5A',liq1:'#E0282E',liq2:'#9E1620',liq3:'#5E0A10',glow:'255,70,40',fire:['#FFF2A8','#FFB000','#FF6A00','#C1121F'],mark:'#FFC93A',eye:'#FF3B30'}
          :{rim0:'#E6FFFF',rim1:'#7FE7FF',rim2:'#2EC4B6',rim3:'#16746B',body0:'#2E4A44',body1:'#1C302C',body2:'#0E1C1A',liq0:'#BFFFF8',liq1:'#2EC4B6',liq2:'#1E8A7A',liq3:'#0E4A42',glow:'46,196,182',fire:['#E6FFFF','#9BF07A','#2EC4B6','#146B5E'],mark:'#9BF07A',eye:'#BFFFF8'};
  const P=(x,y,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),1,1);};const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
  const ell=(x,y,rx,ry,c)=>{g.fillStyle=c;for(let dy=-ry;dy<=ry;dy++){const w=Math.round(rx*Math.sqrt(1-(dy*dy)/(ry*ry)));g.fillRect(Math.round(x-w),Math.round(y+dy),w*2+1,1);}};
  const glow=(x,y,r,a)=>{for(let k=12;k>=1;k--){g.fillStyle=`rgba(${C.glow},${a})`;g.beginPath();g.ellipse(x,y,r*k/12,r*k/12*0.8,0,0,Math.PI*2);g.fill();}};
  glow(cx,base-70,120,0.022);
  // stone fire pit
  ell(cx,base,78,12,'#2A2224');for(let i=0;i<16;i++){const a=i/16*Math.PI*2;const sx=cx+Math.cos(a)*70,sy=base+Math.sin(a)*9;ell(sx,sy-2,9,5,i%2?'#5A5058':'#4A4048');ell(sx-2,sy-4,4,2,'#6A6068');}
  // fire tongues
  for(let i=0;i<13;i++){const fx=cx-54+i*9,h=26+Math.round(10*Math.sin(t*0.22+i*1.3))+(i%3)*6;
    for(let r=0;r<h;r++){const q=r/h,w=Math.max(1,Math.round(5*(1-q)+(r<3?1:0)));const sway=Math.round(Math.sin(t*0.3+r*0.25+i)*q*2.5);
      R(fx-w+sway,base-4-r,w*2,1,q<0.3?C.fire[3]:q<0.6?C.fire[2]:q<0.85?C.fire[1]:C.fire[0]);}}
  // claw legs
  for(const lx of [-44,0,44]){g.fillStyle=C.rim2;g.fillRect(cx+lx-4,base-40,8,26);g.fillStyle=C.rim1;g.fillRect(cx+lx-4,base-40,3,26);for(const k of [-6,0,6]){R(cx+lx+k-1,base-16,3,5,C.rim3);P(cx+lx+k,base-11,C.rim1);}}
  // pot body (belly)
  const top=base-128,H=92;
  for(let y=0;y<H;y++){const q=y/H;const w=Math.round(66*Math.sqrt(Math.max(0.06,1-Math.pow((q-0.38)/0.66,2))));
    R(cx-w,top+y,w*2,1,C.body1);R(cx-w,top+y,Math.round(w*0.35),1,C.body0);R(cx+w-Math.round(w*0.28),top+y,Math.round(w*0.28),1,C.body2);}
  // bands
  for(const by of [top+10,top+60]){const q=(by-top)/H;const w=Math.round(66*Math.sqrt(Math.max(0.06,1-Math.pow((q-0.38)/0.66,2))));R(cx-w,by,w*2,5,C.rim2);R(cx-w,by,w*2,1,C.rim1);R(cx-w,by+4,w*2,1,C.rim3);
    for(let x=cx-w+6;x<cx+w-4;x+=10){P(x,by+2,C.rim0);}}
  // emblem: oni mask (season) or ghost face (curse)
  const ey=top+34;
  if(S){ell(cx,ey,15,13,C.rim3);ell(cx,ey,13,11,C.rim1);ell(cx-3,ey-4,6,3,C.rim0);R(cx-9,ey-16,3,8,C.rim0);R(cx+6,ey-16,3,8,C.rim0);R(cx-8,ey-3,5,3,C.eye);R(cx+3,ey-3,5,3,C.eye);R(cx-6,ey+4,12,3,C.rim3);P(cx-5,ey+4,'#FFFFFF');P(cx+4,ey+4,'#FFFFFF');}
  else{ell(cx,ey,14,14,C.rim3);ell(cx,ey,12,12,'#D8FFF6');R(cx-7,ey-3,5,5,C.body2);R(cx+2,ey-3,5,5,C.body2);P(cx-5,ey-1,C.eye);P(cx+4,ey-1,C.eye);R(cx-1,ey+3,2,3,C.body2);for(let k=-6;k<=6;k+=3)R(cx+k,ey+8,2,3,C.body2);}
  // side handles held by rings
  for(const s of [-1,1]){const hx=cx+s*70;for(let a=0;a<6.28;a+=0.12)P(hx+Math.cos(a)*9,top+26+Math.sin(a)*9,C.rim1);for(let a=0;a<6.28;a+=0.12)P(hx+Math.cos(a)*8,top+26+Math.sin(a)*8,C.rim2);}
  if(!S)for(const s of [-1,1])for(let k=0;k<7;k++){const x=cx+s*(60-k*2),y=top+34+k*6;R(x-1,y,3,4,'#6A7A78');R(x,y+1,1,2,'#9AAAA8');}
  // rim and liquid surface
  ell(cx,top,72,15,C.rim3);ell(cx,top-1,70,13,C.rim2);ell(cx,top-2,68,12,C.rim1);ell(cx,top-2,62,10,'#0A0406');
  const ly=top-2+Math.round((1-fill)*4);ell(cx,ly,60,9,C.liq3);ell(cx,ly-1,58,8,C.liq2);ell(cx,ly-1,50,6,C.liq1);
  for(let k=0;k<9;k++){const a=t*0.04+k*0.7;const bx=cx+Math.cos(a)*38,by=ly+Math.sin(a*1.3)*4;ell(bx,by,2+(k%2),1,C.liq0);}
  ell(cx-16,ly-3,14,2,C.liq0);
  // floating tokens: coins (season) or souls (curse)
  if(S){for(let k=0;k<6;k++){const a=t*0.035+k*1.05;const x=cx+Math.cos(a)*34,y=ly-2+Math.sin(a*2)*3;ell(x,y,4,2,'#8A5A00');ell(x,y-1,4,2,'#FFC93A');P(x-1,y-2,'#FFF2B0');}}
  else{for(let k=0;k<5;k++){const ph=(t*0.9+k*37)%90;const x=cx-30+k*15+Math.sin((t+k*20)*0.08)*5,y=ly-6-ph*0.9;const al=Math.max(0,1-ph/90);
    g.globalAlpha=al;ell(x,y,4,5,'#D8FFF6');R(x-2,y-1,1,2,'#0E1C1A');R(x+1,y-1,1,2,'#0E1C1A');R(x-3,y+4,2,4,'#D8FFF6');R(x+1,y+5,2,3,'#BFFFF8');g.globalAlpha=1;}}
  // rising embers / sparks
  for(let k=0;k<14;k++){const ph=(t*1.3+k*29)%110;const x=cx-40+((k*37)%80)+Math.sin((t+k*9)*0.05)*6,y=ly-4-ph;g.globalAlpha=Math.max(0,1-ph/110);P(x,y,k%2?C.fire[1]:C.liq0);g.globalAlpha=1;}
  // plaque with name and amount
  const pw=150;R(cx-pw/2-3,base+16,pw+6,40,'#1A0B0C');R(cx-pw/2,base+19,pw,34,S?'#3A1410':'#0E2A26');R(cx-pw/2,base+19,pw,2,C.rim1);R(cx-pw/2,base+51,pw,2,C.rim2);
  g.textAlign='center';g.textBaseline='middle';g.font='7px "Press Start 2P"';g.fillStyle=C.rim1;g.fillText(S?'SEASON CAULDRON':'CURSE CAULDRON',cx,base+28);
  g.font='14px "Press Start 2P"';g.fillStyle='#1A0506';g.fillText(amount,cx+1,base+44);g.fillStyle=S?'#FFE08A':'#BFFFF8';g.fillText(amount,cx,base+43);
}
