/* ===== ONI VILLAGE: map, chibis (480-space pixels) ===== */
const VW=1120,VH=720,VOX=200,VOY=110; // the original village sits at (VOX,VOY) inside the bigger world
const VZ0=[ // interaction zones: door positions and what they open
 {id:'dojo',x:360,y:206,label:'Enter the Dojo'},{id:'gate',x:201,y:208,label:'Face Enma'},{id:'lords',x:505,y:202,label:'Hall of Lords'},
 {id:'market',x:174,y:296,label:'Oni Market'},{id:'shrine',x:553,y:298,label:'Tenka'},{id:'home',x:180,y:394,label:'Your home'},
 {id:'arena',x:550,y:396,label:'Arena 1v1'},{id:'cauldrons',x:360,y:302,label:'The Cauldrons'}];
const VZ=VZ0.map(z=>Object.assign({},z,{x:z.x+VOX,y:z.y+VOY})).concat([{id:'champs',x:110,y:470,label:'Season champions'},{id:'cell',x:1010,y:470,label:'Shuten-doji, PvE Final Boss, soon'}]);
const VBLOCK0=[[542,400,44,20],[300,130,120,70],[160,140,82,60],[455,138,100,58],[130,232,88,58],[505,226,96,66],[140,338,80,50],[500,336,100,54]];
const VCIRC=[[322,282,24],[398,282,24]];
const VBLOCK_NEW=[[20,256,180,124],[30,388,160,46],[930,246,170,140],[880,388,48,26],[914,392,180,40]];
function vilBlocked(x,y){if(x<10||x>VW-10||y<230||y>VH-8)return true;
  for(const [bx,by,bw,bh] of VBLOCK_NEW)if(x>bx-4&&x<bx+bw+4&&y>by&&y<by+bh)return true;
  if(y>650&&y<682&&!(x>530&&x<590))return true;   // the stream, crossable only on the bridge
  const lx=x-VOX,ly=y-VOY;
  for(const [bx,by,bw,bh] of VBLOCK0)if(lx>bx-4&&lx<bx+bw+4&&ly>by&&ly<by+bh)return true;
  for(const [cx,cy,r] of VCIRC)if(Math.hypot(lx-cx,(ly-cy)*1.8)<r)return true;
  if(Math.hypot(lx-650,(ly-432)*2)<66)return true;return false;}
function buildVillageBG(){
  const cv=document.createElement('canvas');cv.width=VW;cv.height=VH;const g0=cv.getContext('2d');g0.imageSmoothingEnabled=false;
  buildVillageOuter(g0);g0.save();g0.translate(VOX,VOY);const g=g0;
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};const P=(x,y,c)=>R(x,y,1,1,c);
  const poly=(pts,c)=>hiPoly(g,pts,c);
  const disc=(cx,cy,r,c,sy)=>{sy=sy||1;g.fillStyle=c;for(let dy=-Math.round(r*sy);dy<=Math.round(r*sy);dy++){const w=Math.round(r*Math.sqrt(Math.max(0,1-(dy/(r*sy))**2)));g.fillRect(Math.round(cx-w),Math.round(cy+dy),w*2+1,1);}};
  let seed=21;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  const glow=(x,y,r,rgb,a)=>{for(let k=10;k>=1;k--){g.fillStyle=`rgba(${rgb},${a})`;g.beginPath();g.ellipse(x,y,r*k/10,r*k/10*0.75,0,0,Math.PI*2);g.fill();}};
  R(0,0,720,470,'#3F6A46');for(let i=0;i<6500;i++){const x=rnd()*720,y=rnd()*470;P(x,y,rnd()<0.45?'#4A7A50':rnd()<0.6?'#365C3C':'#5A8E5E');}
  for(let i=0;i<420;i++){const x=rnd()*720,y=rnd()*470;P(x,y,'#7AB070');P(x+1,y-1,'#6AA062');}
  for(let i=0;i<90;i++){const x=rnd()*720,y=120+rnd()*350;P(x,y,rnd()<0.5?'#F4E4A0':'#FFB7D0');}
  R(0,0,720,108,'#2A4A30');for(let i=0;i<800;i++)P(rnd()*720,rnd()*108,rnd()<0.5?'#335A38':'#24402A');
  function path(x0,y0,x1,y1,w){const L=Math.hypot(x1-x0,y1-y0);for(let i=0;i<=L;i+=2){const x=x0+(x1-x0)*i/L,y=y0+(y1-y0)*i/L;R(x-w/2,y-w/2,w,w,'#8A7A68');}
    for(let i=0;i<=L;i+=9){const x=x0+(x1-x0)*i/L,y=y0+(y1-y0)*i/L;R(x-w/2+2+(i%18?0:4),y-w/2+2,w/2-2,w/2-2,'#A08E7A');R(x+1,y+1,w/2-3,w/2-3,'#96846E');}}
  const PX=360,PY=288;
  path(PX,PY,PX,200,28);path(PX,PY,210,PY,28);path(PX,PY,530,PY,28);path(PX,PY,PX,460,28);path(PX,PY,505,200,22);path(PX,PY,205,205,22);path(PX,PY,180,392,22);path(PX,PY,550,392,22);
  disc(PX,PY,98,'#6A5C4E',0.6);disc(PX,PY,94,'#B0A088',0.6);
  for(let r=18;r<94;r+=14)for(let a=0;a<6.28;a+=0.04)P(PX+Math.cos(a)*r,PY+Math.sin(a)*r*0.6,'#8E7E6A');
  for(let a=0;a<6.28;a+=0.26)for(let r=10;r<94;r+=2)P(PX+Math.cos(a)*r,PY+Math.sin(a)*r*0.6,'#A08E78');
  // raised stone dais for the cauldrons
  disc(PX,PY-6,64,'#5A4C40',0.42);disc(PX,PY-9,62,'#8E7E6A',0.4);disc(PX,PY-11,58,'#C8B89C',0.38);for(let a=0;a<6.28;a+=0.2)P(PX+Math.cos(a)*50,PY-11+Math.sin(a)*19,'#A8987E');
  for(const s of [-1,1]){R(PX-14+s*0,PY+13,28,3,'#8E7E6A');R(PX-12,PY+16,24,3,'#6A5C4E');}
  disc(650,432,72,'#2A5A7A',0.5);disc(650,432,68,'#3A7AA8',0.5);for(let i=0;i<80;i++){const a=rnd()*6.28,d=rnd()*62;P(650+Math.cos(a)*d,432+Math.sin(a)*d*0.5,'#8AC8E8');}
  for(const [lx,ly] of [[612,424],[680,438],[636,446]]){disc(lx,ly,5,'#4E9A4A',0.5);P(lx,ly-1,'#FFB7D0');}
  disc(668,424,8,'#C1121F',0.5);for(const [kx,ky,c] of [[620,444,'#FF8A2A'],[640,422,'#F3E9E4'],[688,444,'#FF8A2A']]){R(kx,ky,4,2,c);P(kx+4,ky,c);}
  function tree(x,y,sak){R(x-2,y-10,5,12,'#3A2018');const c=sak?['#FFB7D0','#FF8FB8','#FFD8E6']:['#1F4A2A','#2A5A34','#163A20'];
    for(let i=0;i<80;i++){const a=rnd()*6.28,d=rnd()*17;R(x+Math.cos(a)*d*1.2,y-21+Math.sin(a)*d*0.9,3,3,c[Math.floor(rnd()*3)]);}g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+3,y+2,14,4,0,0,6.28);g.fill();}
  for(const [tx,ty,s] of [[262,244,1],[458,244,1],[262,362,1],[458,362,1],[100,430,0],[40,380,0]])tree(tx,ty,s);
  function bldg(x,y,w,h,roofH,wall,roof,roofL,sign){
    g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x+4,y+h,w,6);
    R(x,y,w,h,wall);for(let xx=x;xx<x+w;xx+=8)R(xx,y,1,h,'rgba(0,0,0,.18)');R(x,y+h-3,w,3,'rgba(0,0,0,.25)');
    R(x+w/2-10,y+h-24,20,24,'#1A0F0A');R(x+w/2-10,y+h-24,20,1,'#6A4A2A');glow(x+w/2,y+h-8,18,'255,170,80',0.03);
    poly([[x-8,y+2],[x+w+8,y+2],[x+w-4,y-roofH],[x+4,y-roofH]],roof);for(let yy=y-roofH+3;yy<y+2;yy+=3)R(x-6,yy,w+12,1,'rgba(0,0,0,.2)');
    R(x-8,y+1,w+16,2,roofL);R(x+4,y-roofH,w-8,2,roofL);
    if(sign){g.font='8px "Press Start 2P"';const sw=g.measureText(sign).width+12;const sy=y-roofH-16;R(x+w/2-sw/2-2,sy-2,sw+4,17,'#1A0B0C');R(x+w/2-sw/2,sy,sw,13,'#C8962A');R(x+w/2-sw/2,sy,sw,1,'#FFE08A');
      g.fillStyle='#1A0B0C';g.textAlign='center';g.textBaseline='middle';g.fillText(sign,x+w/2,sy+7);}}
  function win(x,y){R(x,y,12,10,'#F8E0B0');R(x+6,y,1,10,'#6A4A2A');R(x,y+5,12,1,'#6A4A2A');glow(x+6,y+5,14,'255,200,120',0.02);}
  function lantern(x,y){glow(x,y+4,24,'255,140,50',0.035);R(x-1,y,3,12,'#2A1410');R(x-3,y-6,7,7,'#E0503A');R(x-2,y-5,5,5,'#FFD27A');}
  bldg(300,158,120,44,28,'#6A4A30','#1E2230','#3A4058','DOJO');win(314,174);win(394,174);R(304,162,6,34,'#C1121F');R(410,162,6,34,'#C1121F');
  glow(200,178,60,'150,40,220',0.045);R(160,146,10,56,'#1A0B20');R(232,146,10,56,'#1A0B20');R(154,140,94,8,'#0E0612');R(170,152,62,50,'#0A0410');
  for(let i=0;i<34;i++)P(174+rnd()*54,156+rnd()*44,rnd()<0.5?'#9B59D0':'#FF3B30');disc(201,172,8,'#C1121F');R(197,170,3,2,'#FFE14A');R(203,170,3,2,'#FFE14A');
  bldg(455,160,100,38,22,'#4A4A58','#2A2E40','#4A5070','HALL OF LORDS');for(const [sx,c] of [[478,'#C8CCD8'],[505,'#FFC93A'],[532,'#C07A3A']]){R(sx-4,206,8,4,'#6A6A78');R(sx-3,194,6,12,c);R(sx-2,190,4,4,c);}
  bldg(130,252,88,40,20,'#4A2A1A','#5A1A12','#8E2A1A','MARKET');for(let k=0;k<6;k++)R(132+k*14,272,14,6,k%2?'#F3E9E4':'#C1121F');
  bldg(505,252,96,42,26,'#E8DCC0','#8E1015','#C1121F','TENKA');R(544,270,18,20,'#FFB000');glow(553,280,24,'255,190,60',0.03);R(492,280,6,28,'#C1121F');R(608,280,6,28,'#C1121F');R(488,276,130,4,'#1A0708');
  bldg(140,356,80,34,18,'#5A3A26','#2A2E40','#4A5070','HOME');win(150,368);win(198,368);
  bldg(500,356,100,36,20,'#3A2A2A','#8E1015','#C1121F','ARENA 1V1');R(504,360,4,28,'#FFB000');R(592,360,4,28,'#FFB000');
  // Enma sign over the gate
  g.font='8px "Press Start 2P"';R(158,122,86,15,'#1A0B0C');R(160,124,82,11,'#9B59D0');g.fillStyle='#FFFFFF';g.textAlign='center';g.textBaseline='middle';g.fillText('ENMA',201,130);
  for(const [lx,ly] of [[280,232],[440,232],[280,340],[440,340],[236,290],[484,290],[330,450],[390,450]])lantern(lx,ly);
  // bench by the pond
  R(544,410,40,4,'#6A4A2A');R(544,410,40,1,'#8A6A3A');R(546,414,3,6,'#4A2A1A');R(579,414,3,6,'#4A2A1A');R(544,402,40,3,'#6A4A2A');
  g0.restore();
  {const R2=(x,y,w,h,c)=>{g0.fillStyle=c;g0.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
   const path=(x0,x1,y,w)=>{for(let x=x0;x<x1;x+=2)R2(x,y-w/2,2,w,'#8A7A68');for(let x=x0;x<x1;x+=9){R2(x+2,y-w/2+2,w/2-2,w/2-2,'#A08E7A');R2(x+5,y+1,w/2-3,w/2-3,'#96846E');}};
   path(196,476,446,26);path(648,920,446,26);for(let y=572;y<648;y+=2)R2(546,y,28,2,'#8A7A68');for(let y=686;y<VH;y+=2)R2(546,y,28,2,'#8A7A68');}
  g0.fillStyle='rgba(255,170,90,.05)';g0.fillRect(0,0,VW,VH);
  return cv;
}
function vilCauldron(g,cx,cy,kind,t,amt){
  const S=kind==='season';
  const C=S?{r0:'#FFF2B0',r1:'#FFC93A',r2:'#C88A00',r3:'#7A4E00',b0:'#5A4A4A',b1:'#34282C',b2:'#1E161A',l0:'#FF8A5A',l1:'#E0282E',l2:'#9E1620',glow:'255,90,40',f:['#C1121F','#FF6A00','#FFB000','#FFF2A8']}
          :{r0:'#E6FFFF',r1:'#7FE7FF',r2:'#2EC4B6',r3:'#16746B',b0:'#3A5A54',b1:'#223A36',b2:'#12221F',l0:'#BFFFF8',l1:'#2EC4B6',l2:'#1E8A7A',glow:'46,196,182',f:['#146B5E','#2EC4B6','#9BF07A','#E6FFFF']};
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};const P=(x,y,c)=>R(x,y,1,1,c);
  const el=(x,y,rx,ry,c)=>{g.fillStyle=c;for(let dy=-ry;dy<=ry;dy++){const w=Math.round(rx*Math.sqrt(Math.max(0,1-(dy*dy)/(ry*ry))));g.fillRect(Math.round(x-w),Math.round(y+dy),w*2+1,1);}};
  for(let k=10;k>=1;k--){g.fillStyle=`rgba(${C.glow},0.035)`;g.beginPath();g.ellipse(cx,cy-6,58*k/10,44*k/10,0,0,6.28);g.fill();}
  // stone fire ring and flames
  el(cx,cy+20,26,6,'#4A4048');for(let k=0;k<10;k++){const a=k/10*6.28;el(cx+Math.cos(a)*24,cy+20+Math.sin(a)*5,4,2,k%2?'#8A8090':'#6A6070');}
  for(let i=0;i<9;i++){const h=8+Math.round(4*Math.sin(t*0.25+i*1.4))+(i%2)*3;for(let r=0;r<h;r++){const q=r/h;R(cx-18+i*4.5-Math.max(1,Math.round(2*(1-q))),cy+20-r,Math.max(1,Math.round(4*(1-q))),1,C.f[Math.min(3,Math.floor(q*4))]);}}
  // legs
  for(const lx of [-16,0,16])R(cx+lx-2,cy+8,4,10,C.r2);
  // pot body
  for(let y=0;y<26;y++){const q=y/26;const w=Math.round(26*Math.sqrt(Math.max(0.08,1-Math.pow((q-0.3)/0.72,2))));R(cx-w,cy-12+y,w*2,1,C.b1);R(cx-w,cy-12+y,Math.round(w*0.35),1,C.b0);R(cx+w-Math.round(w*0.3),cy-12+y,Math.round(w*0.3),1,C.b2);}
  R(cx-25,cy-6,50,3,C.r2);R(cx-25,cy-6,50,1,C.r1);
  // emblem
  if(S){el(cx,cy+3,6,5,C.r3);el(cx,cy+3,5,4,C.r1);R(cx-4,cy-3,2,3,C.r0);R(cx+2,cy-3,2,3,C.r0);R(cx-3,cy+2,2,1,'#FF3B30');R(cx+1,cy+2,2,1,'#FF3B30');}
  else{el(cx,cy+3,5,5,'#D8FFF6');R(cx-3,cy+2,2,2,C.b2);R(cx+1,cy+2,2,2,C.b2);R(cx-2,cy+6,4,1,C.b2);}
  // handles
  for(const s of [-1,1])for(let a=0;a<6.28;a+=0.3)P(cx+s*28+Math.cos(a)*3,cy-6+Math.sin(a)*3,C.r1);
  // rim and liquid
  el(cx,cy-13,29,8,C.r3);el(cx,cy-14,28,7,C.r2);el(cx,cy-15,27,6,C.r1);el(cx,cy-15,24,5,'#0A0406');el(cx,cy-15,22,4,C.l2);el(cx,cy-16,18,3,C.l1);el(cx-6,cy-17,6,1,C.l0);
  for(let k=0;k<5;k++){const a=t*0.05+k*1.25;const bx=cx+Math.cos(a)*13,by=cy-15+Math.sin(a*1.3)*2;if(S){R(bx-1,by-1,3,2,'#FFC93A');P(bx,by-1,'#FFF2B0');}else P(bx,by,C.l0);}
  // rising sparks or souls
  for(let k=0;k<6;k++){const ph=(t*0.8+k*19)%70;const x=cx-12+k*5+Math.sin((t+k*9)*0.1)*3,y=cy-18-ph*0.8;g.globalAlpha=Math.max(0,1-ph/70);
    if(S)R(x,y,2,2,k%2?'#FFB000':'#FFE08A');else{R(x-1,y-2,3,3,'#D8FFF6');P(x-1,y+1,'#BFFFF8');}g.globalAlpha=1;}
  // amount plaque
  g.font='8px "Press Start 2P"';g.textAlign='center';g.textBaseline='middle';const w=g.measureText(amt).width+12;
  R(cx-w/2-1,cy-47,w+2,16,'#1A0B0C');R(cx-w/2,cy-46,w,14,S?'#3A1410':'#0E2A26');R(cx-w/2,cy-46,w,1,C.r1);g.fillStyle=S?'#FFE08A':'#BFFFF8';g.fillText(amt,cx,cy-39);
}
const CHIBI={genesis:['#2A1418','#1A0A0E','#6A2A30','#FF3B30'],aka:['#D7262E','#9E1620','#FF7A6A','#FFB000'],ao:['#2F6FE0','#1B4AA8','#8FBCFF','#FFE14A'],kin:['#FFC93A','#C88A00','#FFF4B0','#FF3B30'],kongo:['#CFF6FF','#7FD8F0','#FFFFFF','#FF5AD8']};
const CHIBI_ARM={genesis:['#1E1418','#140C10','#FF3B30','#1E1418','#140C10'],kin:['#1E1A14','#14110C','#FFD86A','#221D16','#15120D'],kongo:['#D8E6F2','#9AB4CC','#BFFFF8','#C8DAEA','#8AA6C2']};
/* per-character chibi palettes: body, bodyDark, accent, legs, legsDark, head, headDark, headLight, eye */
const CHB={saru:['#B3161F','#7A0A12','#FFC93A','#8E1015','#5A0A0E','#C98A2E','#8A5A1A','#F4DDB8','#FFB000'],
 kappa:['#5FA85A','#3A7A3A','#C1121F','#5FA85A','#3A7A3A','#5FA85A','#3A7A3A','#E8DCA8','#FFE14A'],
 kitsune:['#F8F0EA','#C8C0B8','#C1121F','#C1121F','#7A0A12','#E8A040','#A86A20','#FFD890','#FFB000'],
 tengu:['#EDE8DC','#B8B0A0','#C1121F','#2A2A38','#16161E','#2A2A38','#16161E','#5A5A76','#FFE14A'],
 ryu:['#2E9E4F','#1B6B33','#E8D9A0','#2E9E4F','#1B6B33','#2E9E4F','#1B6B33','#8BE8A6','#FFE14A'],
 onryo:['#E8E8F0','#A8A8C0','#5A3A7A','#E8E8F0','#A8A8C0','#D8E0E8','#0A0A12','#2A2A3A','#FF3B30']};
function chibiDraw(g,x,y,dir,look,step,t){
  const R=(px,py,w,h,col)=>{g.fillStyle=col;g.fillRect(Math.round(px),Math.round(py),w,h);};const P=(px,py,col)=>R(px,py,1,1,col);
  g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(x,y,9,3,0,0,6.28);g.fill();
  const lo=step?1:0;const side=dir==='left'?-1:1;const back=dir==='up',front=dir==='down',prof=!back&&!front;
  if(CHIBI[look]){ // ONI and its skins
    const c=CHIBI[look];const a=CHIBI_ARM[look]||['#3A3F52','#262A38',c[0],'#2E3240','#1E212C'];
    R(x-6,y-9,5,8+lo,a[3]);R(x+1,y-9,5,8-lo,a[4]);R(x-7,y-2+lo,6,2,'#3A2414');R(x+1,y-2-lo,6,2,'#3A2414');
    R(x-7,y-17,14,9,a[0]);R(x+2,y-17,5,9,a[1]);for(const yy of [y-15,y-12])for(let k=-5;k<6;k+=3)P(x+k,yy,a[2]);R(x-7,y-9,14,2,c[1]);
    R(x-9,y-16,3,7,a[0]);R(x+6,y-16,3,7,a[1]);R(x-9,y-10,3,2,'#B07A52');R(x+6,y-10,3,2,'#7A4E30');
    if(back){R(x-6,y-26,2,18,'#DDE4EE');R(x-6,y-28,2,3,'#1A1A22');}else for(let i=0;i<12;i++)P(x-side*8+side*i*0.2,y-18-i,'#9AA4B4');
    const hx=x-8,hy=y-31;
    if(back){R(hx,hy,16,14,'#1C1C24');R(hx+2,hy+1,12,4,'#2A2A34');R(x-2,hy-4,4,4,'#1C1C24');}
    else{R(hx,hy,16,14,c[0]);R(hx,hy,16,2,c[2]);R(hx+12,hy,4,14,c[1]);R(hx-1,hy+1,2,6,'#1C1C24');R(hx+15,hy+1,2,6,'#1C1C24');
      if(front){R(hx+3,hy+5,3,2,c[3]);R(hx+10,hy+5,3,2,c[3]);R(hx+2,hy+4,4,1,c[1]);R(hx+10,hy+4,4,1,c[1]);R(hx+4,hy+9,8,2,'#2A0505');P(hx+4,hy+9,'#FFFFFF');P(hx+11,hy+9,'#FFFFFF');}
      else{R(side<0?hx+2:hx+10,hy+5,3,2,c[3]);R(side<0?hx+1:hx+9,hy+9,6,2,'#2A0505');R(side<0?hx+10:hx,hy,6,14,'#1C1C24');}}
    const hc=look==='kongo'?'#BFFFF8':look==='kin'?'#FFE08A':look==='genesis'?'#FF5A4E':'#DCCA9C';
    if(look==='genesis'&&t%4===0){g.fillStyle=Math.random()<0.5?'#FF6A00':'#FF3B30';g.fillRect(Math.round(x+(Math.random()*2-1)*10),Math.round(y-10-Math.random()*28),1,1);}R(hx+1,hy-5,2,5,hc);R(hx,hy-7,2,3,hc);R(hx+13,hy-5,2,5,hc);R(hx+14,hy-7,2,3,hc);
    if(look==='kin'&&t%3===0)for(let i=0;i<3;i++)P(x+(Math.random()*2-1)*12,y-8-Math.random()*30,'#FFD86A');
    if(look==='kongo'&&t%4===0){const px=Math.round(x+(Math.random()*2-1)*12),py=Math.round(y-8-Math.random()*30);P(px,py,'#FFFFFF');P(px-1,py,'#BFFFF8');P(px+1,py,'#BFFFF8');}
    return;}
  const c=CHB[look]||CHB.saru;const[b0,b1,acc,l0,l1,h0,h1,h2,eye]=c;const hx=x-8,hy=y-31;
  // things behind the body when seen from the front or side: tails, shell, wings
  const behind=()=>{
    if(look==='saru'){const s=-side*(back?0:1);for(let i=0;i<9;i++)R(x+s*(5+i)+(back?(i-4):0),y-10-Math.round(Math.sin(i*0.5)*4)-(i>6?(i-6)*2:0),2,2,h0);}
    if(look==='kitsune'){for(let k=0;k<3;k++)for(let i=0;i<7;i++)R(x-side*(5+i)+(back?(k-1)*4:0),y-10-i-k*2,3,3,i>5?'#FFFFFF':k===1?h0:h1);}
    if(look==='ryu'){for(let i=0;i<10;i++)R(x-side*(5+i)+(back?(i-5):0),y-5-Math.round(i*0.3),Math.max(2,4-Math.floor(i/4)),3,i%3===1?'#D02030':b0);}
    if(look==='tengu'){R(x-7,y-24,4,12,'#16161E');R(x+3,y-24,4,12,'#16161E');}
    if(look==='kappa'){R(x-8,y-24,16,15,'#8A6A2A');for(const [dx,dy] of [[-5,-21],[1,-21],[-3,-15],[3,-15]])R(x+dx,y+dy,3,3,'#C8A050');}};
  if(!back)behind();
  // legs, or a floating hem for Kage
  if(look==='onryo'){const hov=Math.round(Math.sin(t*0.1)*1.5);for(let k=-7;k<=7;k++)R(x+k,y-10+hov,1,6+((k*7+(t>>3))%3+3)%3,b1);R(x-7,y-18+hov,14,10,b0);R(x-6,y-14+hov,12,2,acc);y+=hov;}
  else{R(x-6,y-9,5,8+lo,l0);R(x+1,y-9,5,8-lo,l1);R(x-7,y-2+lo,6,2,look==='tengu'?'#F0B030':look==='ryu'?'#F3E9E4':'#3A2414');R(x+1,y-2-lo,6,2,look==='tengu'?'#F0B030':look==='ryu'?'#F3E9E4':'#3A2414');}
  // torso and arms
  if(look!=='onryo'){R(x-7,y-17,14,9,b0);R(x+2,y-17,5,9,b1);R(x-7,y-10,14,2,acc);
    if(look==='kappa'&&!back)R(x-3,y-16,6,7,'#E8DCA8');if(look==='ryu'&&!back)R(x-3,y-16,6,7,'#E8D9A0');if(look==='tengu'&&!back){P(x-2,y-15,'#C1121F');P(x+1,y-12,'#C1121F');}
    if(look==='kitsune'&&!back){P(x-1,y-17,acc);P(x,y-16,acc);P(x+1,y-17,acc);}}
  const armC=look==='onryo'?b0:look==='saru'||look==='kappa'||look==='ryu'?h0:b0;R(x-9,y-16,3,7,armC);R(x+6,y-16,3,7,look==='onryo'?b1:h1);
  if(look==='saru'&&!back)for(let i=0;i<14;i++)P(x+side*(4+i*0.2)-side*6,y-22+i*1.2,'#B3161F');
  if(back)behind();
  // heads
  if(look==='saru'){R(hx+1,hy+1,14,13,h0);R(hx,hy+4,2,5,h0);R(hx+14,hy+4,2,5,h0);if(!back){if(front){R(hx+3,hy+4,10,9,h2);R(hx+4,hy+6,2,2,'#1A0506');R(hx+10,hy+6,2,2,'#1A0506');R(hx+6,hy+10,4,1,'#5A2A1A');}
    else{R(side<0?hx+1:hx+7,hy+4,8,9,h2);R(side<0?hx+3:hx+11,hy+6,2,2,'#1A0506');}}R(hx+1,hy+2,14,2,acc);R(hx+6,hy-1,4,3,acc);}
  else if(look==='kappa'){R(hx+1,hy+2,14,12,h0);R(hx+12,hy+2,3,12,h1);R(hx,hy+1,16,2,'#1E3A1E');R(hx+3,hy-1,10,2,'#9ADFE8');R(hx+5,hy-2,6,1,'#FFFFFF');
    if(!back){if(front){R(hx+4,hy+6,2,2,eye);R(hx+10,hy+6,2,2,eye);R(hx+5,hy+10,6,3,'#E0B040');}else{R(side<0?hx+2:hx+10,hy+6,2,2,eye);R(side<0?hx-3:hx+12,hy+9,6,3,'#E0B040');}}}
  else if(look==='kitsune'){R(hx+1,hy+2,14,12,h0);R(hx+1,hy-4,4,6,h0);R(hx+11,hy-4,4,6,h0);R(hx+2,hy-2,2,3,'#C1121F');R(hx+12,hy-2,2,3,'#C1121F');
    if(!back){if(front){R(hx+5,hy+8,6,5,h2);R(hx+3,hy+5,3,2,eye);R(hx+10,hy+5,3,2,eye);R(hx+7,hy+9,2,1,'#1A0506');}else{R(side<0?hx-3:hx+11,hy+7,8,4,h0);R(side<0?hx-3:hx+11,hy+9,8,2,h2);R(side<0?hx+3:hx+9,hy+5,3,2,eye);}}}
  else if(look==='tengu'){R(hx+1,hy+1,14,13,h0);R(hx+4,hy-2,8,3,h1);if(!back){if(front){R(hx+6,hy+7,4,7,'#F0B030');R(hx+3,hy+4,3,2,eye);R(hx+10,hy+4,3,2,eye);}else{R(side<0?hx-6:hx+12,hy+6,10,3,'#F0B030');R(side<0?hx+3:hx+10,hy+4,3,2,eye);}}}
  else if(look==='ryu'){for(let k=0;k<5;k++)R(back?hx+1+k*3:(side<0?hx+12:hx),hy+2+k*3,4,3,'#D02030');R(hx+1,hy+1,14,13,h0);R(hx+12,hy+1,3,13,h1);
    R(hx+2,hy-5,2,6,'#FFC93A');R(hx+12,hy-5,2,6,'#FFC93A');if(!back){if(front){R(hx+4,hy+5,3,2,eye);R(hx+10,hy+5,3,2,eye);R(hx+4,hy+10,8,3,h2);}else{R(side<0?hx-6:hx+12,hy+6,10,6,h0);R(side<0?hx-6:hx+12,hy+10,10,2,'#E8D9A0');R(side<0?hx+2:hx+11,hy+5,3,2,eye);}}}
  else if(look==='onryo'){R(hx+2,hy+2,12,12,h0);R(hx,hy,16,6,h1);R(hx,hy,3,20,h1);R(hx+13,hy,3,20,h1);
    if(back)R(hx+2,hy,12,22,h1);else{for(const k of [3,6,9,12])R(hx+k,hy+4,1,10,h1);R(front?hx+7:(side<0?hx+4:hx+9),hy+7,2,2,eye);}}
}
/* ===== village signboard and NPCs ===== */
function vilSignboard(g,x,y,count){ // x,y = bottom center in screen space
  const R=(px,py,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(px),Math.round(py),w,h);};
  g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(x,y+1,40,4,0,0,6.28);g.fill();
  R(x-34,y-40,5,40,'#3A2418');R(x+29,y-40,5,40,'#3A2418');R(x-33,y-40,2,40,'#5A3A26');R(x+30,y-40,2,40,'#5A3A26');
  R(x-44,y-66,88,34,'#1A0B0C');R(x-42,y-64,84,30,'#6A4A2A');for(let k=0;k<4;k++)R(x-42,y-58+k*7,84,1,'#5A3A20');R(x-42,y-64,84,2,'#8A6A3A');
  R(x-46,y-70,92,5,'#2A1E30');R(x-44,y-72,88,3,'#3A3048');
  for(const [nx,ny] of [[-39,-61],[37,-61],[-39,-38],[37,-38]]){R(x+nx,y+ny,2,2,'#C8A060');}
  g.textAlign='center';g.textBaseline='middle';g.font='7px "Press Start 2P"';g.fillStyle='#1A0B0C';g.fillText('ONLINE NOW',x,y-57);
  g.font='14px "Press Start 2P"';g.fillStyle='#1A0506';g.fillText(String(count),x+1,y-43);g.fillStyle='#FFE08A';g.fillText(String(count),x,y-44);
}
const NPCS=[];
function npcDraw(g,n,x,y,t){
  const R=(px,py,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(px),Math.round(py),w,h);};const P=(px,py,c)=>R(px,py,1,1,c);
  const face=n.dir<0?-1:1;const X=v=>x+v*face;
  g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(x,y,8,2.5,0,0,6.28);g.fill();
  const bob=Math.round(Math.sin(t*0.15+n.hx)*1);
  if(n.id==='inu'){const st=n.walk?Math.floor(t/7)%2:0;
    R(x-8,y-9,16,7,'#E8A040');R(x-6,y-5,12,3,'#FFE8C8');R(x-7,y-3+st,3,3,'#C88030');R(x+4,y-3-st,3,3,'#C88030');
    for(const [cx,cy] of [[-5,-8],[1,-7],[4,-9]])P(X(cx),y+cy,'#6A3A1A');
    R(X(face>0?-11:9),y-11,3,3,'#E8A040');P(X(-10),y-12,'#FFE8C8');
    R(X(face>0?5:-12),y-16,8,8,'#E8A040');R(X(face>0?7:-10),y-12,5,4,'#FFE8C8');R(X(face>0?5:-12),y-19,3,3,'#E8A040');R(X(face>0?10:-7),y-19,3,3,'#E8A040');
    P(X(face>0?8:-8),y-14,'#1A0506');P(X(face>0?12:-12),y-12,'#1A0506');R(X(face>0?9:-10),y-10,2,1,'#6A3A1A');}
  else if(n.id==='frog'){R(x-7,y-9+bob,14,8,'#4E9A4A');R(x-7,y-3+bob,14,2,'#3A7A3A');R(x-5,y-5+bob,10,3,'#A8D890');
    R(x-6,y-12+bob,4,4,'#4E9A4A');R(x+2,y-12+bob,4,4,'#4E9A4A');P(x-4,y-11+bob,'#1A0506');P(x+4,y-11+bob,'#1A0506');R(x-2,y-7+bob,4,1,'#2A5A2A');
    R(x-10,y-15+bob,20,2,'#C8A060');R(x-6,y-17+bob,12,2,'#D8B070');R(x-2,y-19+bob,4,2,'#E8C888');for(let i=0;i<8;i++)P(X(6+i),y-6-i*0.5+bob,'#9AA4B4');}
  else if(n.id==='tanuki'){R(x-7,y-12,14,11,'#8A6A4A');R(x-4,y-8,8,6,'#D8C0A0');R(x-6,y-16,12,6,'#8A6A4A');R(x-6,y-13,12,3,'#3A2A1A');P(x-3,y-13,'#FFFFFF');P(x+2,y-13,'#FFFFFF');
    R(x-6,y-18,3,3,'#6A4A2A');R(x+3,y-18,3,3,'#6A4A2A');R(x-2,y-21,5,4,'#5FA85A');P(x,y-22,'#8AD88A');R(X(8),y-10,4,7,'#E8DCC0');R(X(8),y-10,4,2,'#C1121F');}
  else if(n.id==='neko'){const wave=Math.floor(t/10)%2;R(x-6,y-10,12,9,'#FFFFFF');R(x-6,y-4,12,3,'#E8E8F0');R(x-5,y-17,10,8,'#FFFFFF');R(x-5,y-19,3,3,'#FFFFFF');R(x+2,y-19,3,3,'#FFFFFF');
    P(x-4,y-18,'#FF8FB8');P(x+3,y-18,'#FF8FB8');P(x-3,y-14,'#1A0506');P(x+2,y-14,'#1A0506');P(x,y-12,'#FF8FB8');R(x-5,y-10,10,2,'#C1121F');R(x-1,y-9,2,2,'#FFD86A');
    R(x+6,y-(wave?18:15),3,5,'#FFFFFF');P(x+7,y-(wave?18:15),'#FF8FB8');R(x-9,y-8,4,3,'#FFC93A');P(x-8,y-7,'#FFF2B0');}
  else if(n.id==='kasa'){const hop=Math.abs(Math.round(Math.sin(t*0.2)*3));const by=y-hop;
    for(let r=0;r<10;r++){const w=Math.round(2+r*1.1);for(let s=-w;s<w;s++)P(x+s,by-22+r,(Math.floor((s+20)/4)%2)?'#C1121F':'#F3E9E4');}
    R(x-1,by-12,2,9,'#6A4A2A');R(x-1,by-3,2,3,'#E8B090');R(x-3,by-18,6,4,'#FFFFFF');R(x-1,by-17,2,2,'#1A0506');R(x,by-14,2,3,'#FF5A6A');R(x-1,by-24,2,2,'#1A0506');}
  else if(n.id==='kodama'){g.globalAlpha=0.9;R(x-4,y-8,8,7,'#E8F0E8');R(x-5,y-16,10,9,'#F4FAF4');P(x-2,y-13,'#1A1A1A');P(x+1,y-13,'#1A1A1A');R(x-1,y-10,2,1,'#1A1A1A');g.globalAlpha=1;
    if(t%40<20){g.fillStyle='rgba(200,255,200,.12)';g.beginPath();g.ellipse(x,y-10,10,10,0,0,6.28);g.fill();}}
  else if(n.id==='chochin'){const fl=Math.round(Math.sin(t*0.08)*2);const by=y-6+fl;
    g.fillStyle='rgba(255,140,50,.14)';g.beginPath();g.ellipse(x,by-8,16,14,0,0,6.28);g.fill();
    R(x-6,by-16,12,2,'#1A0506');for(let r=0;r<12;r++){const w=Math.round(6*Math.sqrt(1-Math.pow((r-6)/7,2)));R(x-w,by-14+r,w*2,1,r%3===0?'#C04028':'#E8603A');}R(x-6,by-2,12,2,'#1A0506');
    R(x-4,by-11,3,3,'#FFFFFF');P(x-3,by-10,'#1A0506');R(x+1,by-11,3,3,'#FFFFFF');P(x+2,by-10,'#1A0506');R(x-2,by-6,4,1,'#2A0505');R(x-1,by-5,2,4,'#FF5A6A');}
}

/* ===== champions statues, the boss in his cell with the Curse Bag, and two sitters ===== */
function vilChamps(g,ox,oy,names,season){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x+ox),Math.round(y+oy),w,h);};
  const MET=[['#FFE08A','#C88A00'],['#E8ECF4','#9AA4B4'],['#E0A060','#8A5A2A'],['#A8A0B0','#6A6070'],['#A8A0B0','#6A6070']];
  [[87,34,0],[66,26,1],[108,20,2],[45,14,3],[129,10,4]].forEach(([px,h,rank])=>{if(!names[rank])return;const [c1,c2]=MET[rank];const top=164-h;
    R(px-5,top-14,10,14,c1);R(px+1,top-14,4,14,c2);R(px-6,top-24,12,10,c1);R(px+2,top-24,4,10,c2);R(px-6,top-27,2,4,c1);R(px+4,top-27,2,4,c1);
    R(px-3,top-21,2,2,c2);R(px+1,top-21,2,2,c2);for(let i=0;i<10;i++)R(px+6+i*0.4,top-12-i,1,1,c2);});
  g.font='6px "Press Start 2P"';g.textAlign='left';g.textBaseline='middle';
  g.fillStyle='#1A0B0C';g.fillText('SEASON '+season,40+ox,191+oy);
  for(let i=0;i<5;i++){const n=names[i]||'-';g.fillStyle=i===0?'#8A5A00':'#1A0B0C';g.fillText((i+1)+' '+String(n).slice(0,12),40+ox,199+i*4.2+oy);}
}
function vilCell(g,ox,oy,bag,t){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x+ox),Math.round(y+oy),w,h);};
  // the boss, chained, sitting
  const br=Math.round(Math.sin(t*0.05));
  R(628,160+br,46,36,'#8E1015');R(628,160+br,14,36,'#B3161F');R(636,188,30,10,'#5A0A0E');
  R(634,136+br,34,26,'#B3161F');R(634,136+br,10,26,'#D7262E');R(630,128+br,8,10,'#F3E9E4');R(664,128+br,8,10,'#F3E9E4');
  R(640,146+br,6,4,'#FFE14A');R(656,146+br,6,4,'#FFE14A');R(642,156+br,18,4,'#2A0505');R(643,156+br,2,3,'#FFFFFF');R(657,156+br,2,3,'#FFFFFF');
  for(let i=0;i<9;i++){R(604+i*3,150+i*2,3,2,'#6A6A7A');R(698-i*3,150+i*2,3,2,'#6A6A7A');}
  // bars in front
  for(let x=604;x<704;x+=9){R(x,122,3,78,'#4A4A5A');R(x,122,1,78,'#7A7A8A');}R(600,128,104,3,'#4A4A5A');R(600,190,104,3,'#4A4A5A');
  // the Curse Bag next to the cell
  const bx=580,by=196;R(bx-14,by-18,28,18,'#8A6A3A');R(bx-12,by-22,24,6,'#A07A44');R(bx-4,by-26,8,5,'#6A4A2A');R(bx-16,by-4,32,4,'#6A4A2A');
  for(const [dx,dy] of [[-8,-10],[2,-14],[6,-6],[-2,-4]]){R(bx+dx,by+dy,4,3,'#FFC93A');R(bx+dx,by+dy,2,1,'#FFF2B0');}
  g.font='6px "Press Start 2P"';g.textAlign='center';g.textBaseline='middle';const txt='CURSE BAG '+bag;const w=g.measureText(txt).width+8;
  R(bx-w/2,by+4,w,11,'#1A0B0C');g.fillStyle='#FFC93A';g.fillText(txt,bx+ox,by+10+oy);
}
function vilSitters(g,ox,oy,t){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x+ox),Math.round(y+oy),w,h);};
  const D=(cx,cy,r,c)=>{g.fillStyle=c;for(let dy=-r;dy<=r;dy++){const w=Math.round(Math.sqrt(r*r-dy*dy));g.fillRect(Math.round(cx-w+ox),Math.round(cy+dy+oy),w*2+1,1);}};
  const b=Math.round(Math.sin(t*0.06));
  // Cookie
  D(556,401+b,7,'#8A5A2A');D(556,401+b,6,'#D8A060');for(const [dx,dy] of [[-3,-3],[2,-2],[-1,2],[3,3]])R(556+dx,401+b+dy,2,2,'#5A3A1A');
  R(553,399+b,1,2,'#1A0506');R(558,399+b,1,2,'#1A0506');R(554,403+b,4,1,'#5A2A1A');R(552,408,2,4,'#8A5A2A');R(558,408,2,4,'#8A5A2A');
  // Morsel: a small bitten piece
  const mb=Math.round(Math.sin(t*0.06+1.5));D(571,404+mb,4,'#8A5A2A');D(571,404+mb,3,'#D8A060');R(573,401+mb,3,3,'#6A4A2A');
  R(569,403+mb,1,1,'#1A0506');R(572,403+mb,1,1,'#1A0506');R(570,405+mb,2,1,'#5A2A1A');R(569,408,1,3,'#8A5A2A');R(572,408,1,3,'#8A5A2A');
}

/* ===== the outer world: forest frame, two new districts, paths and a stream ===== */
function buildVillageOuter(g){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};const P=(x,y,c)=>R(x,y,1,1,c);
  let seed=91;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  R(0,0,VW,VH,'#3F6A46');for(let i=0;i<14000;i++){const x=rnd()*VW,y=rnd()*VH;P(x,y,rnd()<0.45?'#4A7A50':rnd()<0.6?'#365C3C':'#5A8E5E');}
  for(let i=0;i<220;i++){const x=rnd()*VW,y=240+rnd()*(VH-240);P(x,y,rnd()<0.5?'#F4E4A0':'#FFB7D0');}
  // forest along the top
  R(0,0,VW,222,'#2A4A30');for(let i=0;i<2600;i++)P(rnd()*VW,rnd()*222,rnd()<0.5?'#335A38':'#24402A');
  for(let x=0;x<VW;x+=14){const h=18+Math.round(rnd()*14);R(x,222-h,14,h,'#244A2C');R(x+2,222-h-6,10,8,'#2E5A34');R(x+4,222-h-4,4,3,'#3E7040');}
  // paths to the new districts
  const path=(x0,x1,y,w)=>{for(let x=x0;x<x1;x+=2)R(x,y-w/2,2,w,'#8A7A68');for(let x=x0;x<x1;x+=9){R(x+2,y-w/2+2,w/2-2,w/2-2,'#A08E7A');R(x+5,y+1,w/2-3,w/2-3,'#96846E');}};
  // the stream and its red bridge
  for(let y=652;y<682;y++)R(0,y,VW,1,y<656||y>677?'#2A5A7A':'#3A7AA8');for(let i=0;i<160;i++)R(rnd()*VW,656+rnd()*22,3,1,'#8AC8E8');
  R(526,646,68,40,'#8E1015');R(530,650,60,32,'#C1121F');for(let x=532;x<588;x+=6)R(x,650,2,32,'#8E1015');R(526,646,68,3,'#FF5A4E');R(526,683,68,3,'#5A0A0E');
  // champions plaza: stone floor
  for(let y=258;y<450;y+=2)for(let x=14;x<206;x+=2)if(((x/2+y/2)|0)%9===0)P(x,y,'#9A8A74');
  R(14,256,192,196,'#B0A088');for(let y=262;y<450;y+=12)for(let x=18+((y/12)%2)*12;x<204;x+=24)R(x,y,22,10,'#C0B098');R(14,256,192,3,'#D8C8B0');
  // prison yard: dark stone
  R(914,240,196,212,'#4A4450');for(let y=246;y<450;y+=12)for(let x=918+((y/12)%2)*12;x<1108;x+=24)R(x,y,22,10,'#56505E');R(914,240,196,3,'#6A6472');
  // a few trees outside the districts
  const tree=(x,y)=>{R(x-2,y-10,5,12,'#3A2018');for(let i=0;i<80;i++){const a=rnd()*6.28,d=rnd()*17;R(x+Math.cos(a)*d*1.2,y-21+Math.sin(a)*d*0.9,3,3,['#1F4A2A','#2A5A34','#163A20'][Math.floor(rnd()*3)]);}};
  for(const [x,y] of [[60,560],[150,610],[980,560],[1080,600],[700,610],[400,620]])tree(x,y);
}
/* ===== champions plaza (big podium) ===== */
function vilChampsBig(g,ox,oy,names,season){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x+ox),Math.round(y+oy),Math.round(w),Math.round(h));};
  // arch with the title
  R(26,262,8,118,'#8E1015');R(186,262,8,118,'#8E1015');R(18,256,184,12,'#1A0708');R(22,270,176,6,'#C1121F');
  g.font='8px "Press Start 2P"';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#FFE08A';g.fillText('SEASON '+season+' CHAMPIONS',110+ox,262+oy);
  // podium: 4 2 1 3 5
  const MET=[['#FFE08A','#C88A00'],['#E8ECF4','#9AA4B4'],['#E0A060','#8A5A2A'],['#B8B0C0','#7A7280'],['#B8B0C0','#7A7280']];
  const ped=[[44,22,3],[77,34,1],[110,46,0],[143,28,2],[176,16,4]];
  R(28,376,164,10,'#6A6070');R(28,376,164,2,'#9A92A0');
  for(const [px,h,rank] of ped){const top=376-h;R(px-15,top,30,h,'#8A8090');R(px-15,top,30,2,'#C0B8C8');R(px+9,top,6,h,'#6A6070');
    g.font='8px "Press Start 2P"';g.fillStyle=rank===0?'#FFE08A':'#2A2430';g.fillText(String(rank+1),px+ox,top+h/2+1+oy);
    if(!names[rank])continue;const [c1,c2]=MET[rank];const s=rank===0?1.35:rank<3?1.15:1;
    const fy=top;R(px-7*s,fy-20*s,14*s,20*s,c1);R(px+2*s,fy-20*s,5*s,20*s,c2);R(px-8*s,fy-34*s,16*s,14*s,c1);R(px+3*s,fy-34*s,5*s,14*s,c2);
    R(px-8*s,fy-39*s,3*s,6*s,c1);R(px+5*s,fy-39*s,3*s,6*s,c1);R(px-4*s,fy-29*s,3*s,3*s,c2);R(px+1*s,fy-29*s,3*s,3*s,c2);
    for(let i=0;i<14*s;i++)R(px+8*s+i*0.3,fy-16*s-i,1.5,1.5,c2);}
  // name tablet
  R(30,392,160,52,'#5A5260');R(33,395,154,46,'#7A7280');R(30,392,160,2,'#A09AA8');
  g.textAlign='left';g.font='7px "Press Start 2P"';
  for(let i=0;i<5;i++){const n=names[i]||'Open spot';g.fillStyle=i===0?'#FFE08A':i===1?'#F3F3F8':i===2?'#F0B880':'#E0DCE4';g.fillText((i+1)+'. '+String(n).slice(0,16),40+ox,401+i*9+oy);}
}
/* ===== Shuten-doji's prison with the Curse Bag board ===== */
function vilPrison(g,ox,oy,bag,t){
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x+ox),Math.round(y+oy),Math.round(w),Math.round(h));};
  // cell
  R(934,262,136,120,'#2A2430');R(938,266,128,112,'#0C0A10');R(926,252,152,14,'#3A3440');R(926,252,152,2,'#5A5460');R(934,380,136,6,'#3A3440');
  // the boss, clean and big, sitting in chains
  const b=Math.round(Math.sin(t*0.04));const x=1002,y=376;
  R(x-30,y-46+b,60,44,'#B3161F');R(x-30,y-46+b,16,44,'#D7262E');R(x+16,y-46+b,14,44,'#8E1015');R(x-34,y-8,68,8,'#5A0A0E');
  R(x-20,y-80+b,40,34,'#B3161F');R(x-20,y-80+b,12,34,'#D7262E');R(x-26,y-92+b,8,14,'#F3E9E4');R(x+18,y-92+b,8,14,'#F3E9E4');
  R(x-12,y-68+b,8,5,'#FFE14A');R(x+4,y-68+b,8,5,'#FFE14A');R(x-12,y-56+b,24,5,'#2A0505');R(x-10,y-56+b,3,4,'#FFFFFF');R(x+7,y-56+b,3,4,'#FFFFFF');
  R(x-24,y-82+b,48,4,'#1A0A0A');
  for(let i=0;i<10;i++){R(940+i*3.4,300+i*2.6,3,2,'#7A7A8A');R(1062-i*3.4,300+i*2.6,3,2,'#7A7A8A');}
  // bars
  for(let bx=944;bx<1066;bx+=14){R(bx,266,4,112,'#4A4A5A');R(bx,266,1,112,'#8A8A9A');}R(938,288,128,4,'#4A4A5A');R(938,356,128,4,'#4A4A5A');
  // sign
  R(950,236,104,16,'#1A0B0C');R(952,238,100,12,'#8E1015');g.font='7px "Press Start 2P"';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#FFE08A';g.fillText('SHUTEN-DOJI',1002+ox,244+oy);
  // Curse Bag board: big and easy to read
  R(916,396,180,52,'#1A0B0C');R(919,399,174,46,'#2A1410');R(919,399,174,2,'#FFC93A');
  g.font='7px "Press Start 2P"';g.fillStyle='#FFC93A';g.fillText('CURSE BAG',1006+ox,407+oy);
  g.font='14px "Press Start 2P"';g.fillStyle='#1A0506';g.fillText(bag,1007+ox,423+oy);g.fillStyle='#FFE08A';g.fillText(bag,1006+ox,422+oy);
  g.font='6px "Press Start 2P"';g.fillStyle='#C9A9A2';g.fillText('$1-2 PER TRY  ·  SOON',1006+ox,437+oy);
  // the sack beside the board
  const sx=896,sy=410;R(sx-12,sy-16,24,18,'#8A6A3A');R(sx-10,sy-20,20,6,'#A07A44');R(sx-3,sy-24,6,5,'#6A4A2A');for(const [dx,dy] of [[-7,-9],[2,-12],[5,-5]])R(sx+dx,sy+dy,4,3,'#FFC93A');
}
