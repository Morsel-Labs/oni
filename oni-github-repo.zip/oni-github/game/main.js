/* ===================== RENDER PRIMITIVES ===================== */
const cv=document.getElementById('cv');const ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
let G=ctx;const FONT='"Press Start 2P", monospace';
function rect(x,y,w,h,c){G.fillStyle=c;G.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function px(x,y,c){G.fillStyle=c;G.fillRect(Math.round(x),Math.round(y),1,1);}
function ell(cx,cy,rx,ry,c){G.fillStyle=c;cx=Math.round(cx);cy=Math.round(cy);for(let dy=-ry;dy<=ry;dy++){const w=Math.round(rx*Math.sqrt(Math.max(0,1-(dy*dy)/((ry+0.5)*(ry+0.5)))));G.fillRect(cx-w,cy+dy,w*2+1,1);}}
function disc(cx,cy,r,c){ell(cx,cy,r,r,c);}

const COM={eye:'#FFB000',eyeHi:'#FFF2A8',mouth:'#2A0505',fang:'#FFFFFF',hair:'#121218',horn:'#EAD9B0',hornD:'#A8946A',
  gi:'#343B4E',giD:'#20242F',giL:'#6B7593',pant:'#262A36',pantD:'#161920',sandal:'#6B4226',hand:'#8A5A3A',
  blade:'#DDE3EE',bladeD:'#8C95A6',hilt:'#3A1A12',guard:'#C9A227',swoosh:'rgba(255,255,255,.6)',claw:'#F3E9E4'};
const PAL={
  oni:[{face:'#D7262E',faceD:'#8E1015',faceL:'#FF6B5E',belt:'#C1121F',beltD:'#7A0A12',flame:['#FFF2A8','#FFB000','#FF6A00','#C1121F'],main:'#D7262E',name:'#FF8A80'},
       {face:'#2F6FE0',faceD:'#173E8A',faceL:'#7FB0FF',belt:'#2EC4B6',beltD:'#16746B',flame:['#E6FFFF','#7FE7FF','#2EC4B6','#1B5FD1'],main:'#2F6FE0',name:'#8FB8FF'},
       {face:'#FFC93A',faceD:'#C88A00',faceL:'#FFF4B0',belt:'#FFD86A',beltD:'#A87000',gi:'#1E1A14',giD:'#14110C',giL:'#FFB000',pant:'#221D16',pantD:'#15120D',blade:'#FFF4C8',bladeD:'#E0B040',flame:['#FFFFFF','#FFF2A8','#FFC93A','#C88A00'],main:'#FFC93A',name:'#FFD86A'},
       {face:'#CFF6FF',faceD:'#7FD8F0',faceL:'#FFFFFF',belt:'#BFFFF8',beltD:'#2EC4B6',gi:'#D8E6F2',giD:'#9AB4CC',giL:'#FFFFFF',pant:'#C8DAEA',pantD:'#8AA6C2',hair:'#B8CCE0',blade:'#E6FFFF',bladeD:'#7FE7FF',flame:['#FFFFFF','#E6FFFF','#7FE7FF','#2EC4B6'],main:'#9FE8FF',name:'#CFF6FF'},
       {face:'#2A1418',faceD:'#1A0A0E',faceL:'#6A2A30',belt:'#FF3B30',beltD:'#8E1015',gi:'#1E1418',giD:'#140C10',giL:'#FF3B30',pant:'#1E1418',pantD:'#140C10',blade:'#FFD0C8',bladeD:'#FF3B30',flame:['#FFE0D0','#FF8A5A','#FF3B30','#8E1015'],main:'#FF3B30',name:'#FF8A7A'}],
  saru:[{fur:'#C98A2E',furD:'#8A5A1A',furL:'#F0C060',face:'#E8C9A0',band:'#C1121F',bandL:'#FF4A55',vest:'#7A0A12',vestD:'#4A060B',staff:'#6B3A1A',staffD:'#40210E',cap:'#FFB000',main:'#E0A030',name:'#F0C060'},
        {fur:'#6A4A3A',furD:'#3E2A20',furL:'#9A7A5A',face:'#D8B890',band:'#2EC4B6',bandL:'#8FF0E6',vest:'#1B3A5A',vestD:'#0E2238',staff:'#3A2A22',staffD:'#221812',cap:'#DDE3EE',main:'#9A7A5A',name:'#D8B890'}],
  ryu:[{body:'#2E9E4F',bodyD:'#1B6B33',bodyL:'#6BD88A',belly:'#E8D9A0',mane:'#C1121F',maneD:'#7A0A12',horn:'#FFB000',breath:['#F0FFE0','#9BF07A','#2E9E4F','#145A2A'],main:'#2E9E4F',name:'#8BE0A0'},
       {body:'#1F5F5A',bodyD:'#123B38',bodyL:'#4FA59C',belly:'#D9D0B8',mane:'#6B2FA0',maneD:'#3E1560',horn:'#DDE3EE',breath:['#F4E6FF','#C49BFF','#6B2FA0','#2A0F45'],main:'#3F9A92',name:'#9FE0D8'}],
  kitsune:[{fur:'#E8A040',furD:'#A86A20',furL:'#FFD890',mark:'#C1121F',robe:'#F3E9E4',robeD:'#C8C0B8',hakama:'#C1121F',hakamaD:'#7A0A12',fire:'#7FE7FF',main:'#E8A040',name:'#FFD890'},
           {fur:'#F4F0EA',furD:'#B8B2A8',furL:'#FFFFFF',mark:'#9B59D0',robe:'#2A2440',robeD:'#1A1628',hakama:'#4A2A7A',hakamaD:'#2A1848',fire:'#C49BFF',main:'#C8C0E0',name:'#E6DCFF'}],
  tengu:[{feather:'#1C1C26',featherD:'#0E0E14',featherL:'#4A4A62',robe:'#E8E4D8',robeD:'#B0A898',pom:'#C1121F',beak:'#F0B030',beakD:'#A87010',leaf:'#3E8A3A',leafD:'#245A22',main:'#6A6A88',name:'#C8C8E0'},
         {feather:'#D8D8E0',featherD:'#9A9AA8',featherL:'#FFFFFF',robe:'#2A2A36',robeD:'#18181F',pom:'#2EC4B6',beak:'#E08A30',beakD:'#A05A10',leaf:'#8A3A8A',leafD:'#5A1A5A',main:'#B8B8C8',name:'#F0F0FF'}],
  kappa:[{skin:'#5FA85A',skinD:'#3A7A3A',skinL:'#9AD88A',shell:'#7A6530',shellD:'#4A3A18',shellL:'#A8904A',belly:'#E0D8A8',beak:'#E0B040',dish:'#9ADFE8',hair:'#1E3A1E',water:'#7FE7FF',main:'#5FA85A',name:'#9AD88A'},
         {skin:'#4A8AB8',skinD:'#2A5A80',skinL:'#8ABAE0',shell:'#5A3A5A',shellD:'#3A2238',shellL:'#8A6A8A',belly:'#D8D8E0',beak:'#C0C0C8',dish:'#FFD890',hair:'#1A2A3A',water:'#9BF07A',main:'#4A8AB8',name:'#8ABAE0'}],
  enma:[{robe:'#8E1015',robeD:'#5A0A0E',robeL:'#C1121F',inner:'#F3E9E4',skin:'#D7262E',skinD:'#8E1015',beard:'#121218',crown:'#16161C',gold:'#FFB000',club:'#2A2A34',stud:'#9AA0B0',hilt:'#5A3A1A',main:'#C1121F',name:'#FF8A80',flame:['#FFF2A8','#FFB000','#FF6A00','#8E1015']},
        {robe:'#3A1560',robeD:'#1E0A36',robeL:'#6B2FA0',inner:'#E8DCFF',skin:'#2F6FE0',skinD:'#173E8A',beard:'#F3E9E4',crown:'#0A0A12',gold:'#2EC4B6',club:'#1A1A22',stud:'#BFFFF8',hilt:'#3A2A5A',main:'#6B2FA0',name:'#C49BFF',flame:['#E6FFFF','#7FE7FF','#2EC4B6','#1B5FD1']}],
  onryo:[{robe:'#E8E8F0',robeD:'#A8A8C0',robeL:'#FFFFFF',hair:'#0A0A12',hairL:'#2A2A3A',skin:'#D8E0E8',aura:'#9B59D0',eyeR:'#FF3B30',nail:'#E8E8F0',main:'#C8C8E0',name:'#E6DCFF'},
         {robe:'#B8D8E8',robeD:'#7898A8',robeL:'#E8F8FF',hair:'#101820',hairL:'#2A3848',skin:'#C8E0E8',aura:'#2EC4B6',eyeR:'#FFB000',nail:'#E8F8FF',main:'#8AB8C8',name:'#BFFFF8'}]
};
const fname=(kit,pal,skin)=>kit==='oni'?(skin==='kin'?'KIN-ONI':skin==='kongo'?'KONGO-ONI':pal===4?'GENESIS ONI':pal?'AO ONI':'AKA ONI'):CH[kit].name;
const palOf=(m,i)=>m&&m.pal?m.pal[i]:i;

function kitTools(f,side){
  const s=f.face,x=Math.round(f.x),y=Math.round(f.y),fl=f.flash>0&&f.flash%2===0;const P=PAL[f.ch][side];
  const col=k=>fl&&k!=='swoosh'?'#FFFFFF':(P[k]||COM[k]||k);
  const R=(dx,dy,w,h,k)=>rect(s>0?x+dx:x-dx-w+1,y+dy,w,h,col(k));
  return{s,x,y,P,col,R};
}
function lineT(L,x0,y0,ax,ay,len,k,k2){for(let i=0;i<len;i++){const lx=Math.round(x0+ax*i),ly=Math.round(y0+ay*i);L(lx,ly,1,1,k);if(k2)L(lx,ly+1,1,1,k2);}}

/* ---------- ONI ---------- */
function drawOni(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;
  if(!NOSHADOW)ell(x,GROUND+1,12,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){
    R(-16,-6,22,5,'gi');R(-16,-2,22,1,'giD');R(-21,-5,5,4,'pant');R(-5,-6,2,5,'belt');
    R(6,-9,8,7,'face');R(12,-9,2,7,'faceD');R(8,-11,1,2,'horn');R(12,-11,1,2,'horn');R(14,-8,2,6,'hair');
    R(8,-6,1,1,'hair');R(11,-6,1,1,'hair');R(8,-4,4,1,'mouth');for(let k=0;k<20;k++)R(-24+k,-1,1,1,k<16?'blade':'hilt');return;
  }
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/20)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-Math.abs(Math.round(Math.sin(fr*0.15)*3));
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);const line=(a,b,c,d,e,k,k2)=>lineT(L,a,b,c,d,e,k,k2);
  const A=CH.oni;const wk=st==='walk'?(Math.floor(fr/7)%2?2:-2):0;
  const kick=st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4;
  if(f.air&&st!=='hurt'){R(-6,-15,5,8,'pant');R(2,-15,5,8,'pant');R(-7,-8,5,2,'sandal');R(3,-8,5,2,'sandal');}
  else{R(-7+wk,-12,4,10,'pant');R(-6+wk,-12,1,10,'pantD');R(-9+wk,-2,6,2,'sandal');
    if(kick){R(2,-15,14,4,'pant');R(2,-12,14,1,'pantD');R(15,-17,3,7,'sandal');}
    else{R(3-wk,-12,4,10,'pant');R(6-wk,-12,1,10,'pantD');R(3-wk,-2,6,2,'sandal');}}
  L(-8,-17,16,6,'pant');L(4,-17,4,6,'pantD');L(-8,-26,3,8,'giD');L(-6,-27,12,11,'gi');L(2,-27,4,11,'giD');
  for(let k=0;k<5;k++){L(-2+k,-27+k,1,1,'giL');L(3-k,-27+k,1,1,'giL');}
  L(-7,-18,14,2,'belt');L(-7,-17,14,1,'beltD');L(5,-18,2,5,'belt');
  L(-1,-40,3,3,'hair');L(-5,-37,10,3,'hair');L(-6,-35,2,7,'hair');L(-4,-35,9,8,'face');L(3,-35,2,8,'faceD');L(-4,-35,3,1,'faceL');
  L(-4,-39,1,3,'horn');L(-5,-40,1,2,'horn');L(4,-39,1,3,'horn');L(5,-41,1,2,'horn');L(5,-39,1,1,'hornD');
  L(-1,-33,2,1,'faceD');L(3,-33,2,1,'faceD');L(1,-32,1,1,'faceD');
  if(st==='hurt'){L(-1,-31,2,1,'hair');L(3,-31,2,1,'hair');}else{L(0,-32,1,2,'eye');L(3,-32,1,2,'eye');L(0,-32,1,1,'eyeHi');L(3,-32,1,1,'eyeHi');}
  L(-1,-29,6,1,'mouth');L(-1,-28,1,1,'fang');L(4,-28,1,1,'fang');
  const pS=A.punch.s,pA=A.punch.a;
  if(st==='punch'&&f.t<=pS){L(-1,-36,3,3,'hand');L(-3,-38,4,2,'hilt');line(-3,-39,-0.6,-0.8,15,'blade','bladeD');}
  else if(st==='punch'&&f.t<=pS+pA+3){L(3,-26,8,3,'gi');L(10,-26,3,3,'hand');L(13,-27,1,5,'guard');line(14,-25,1,0,A.punch.reach-14,'blade','bladeD');
    for(let a=-1.3;a<=0.35;a+=0.1)L(Math.round(8+Math.cos(a)*22),Math.round(-24+Math.sin(a)*22),1,1,'swoosh');}
  else if(st==='punch'){L(5,-22,3,3,'hand');L(8,-22,3,2,'hilt');line(11,-21,0.9,0.45,16,'blade','bladeD');}
  else if(st==='block'){L(6,-29,3,3,'hand');L(7,-31,2,2,'guard');line(8,-44,0,1,13,'blade');line(9,-44,0,1,13,'bladeD');}
  else if(st==='special'){if(f.t<10){L(-10,-28,3,3,'hand');disc(s>0?x-10:x+10,y-31+bob,2+(fr%2),P.flame[2]);}else{L(3,-27,9,3,'gi');L(11,-27,3,3,'hand');}}
  else if(st==='win'){L(-1,-44,3,3,'hand');L(-1,-46,3,2,'guard');line(0,-60,0,1,14,'blade');line(1,-60,0,1,14,'bladeD');}
  else{L(5,-22,3,3,'hand');L(6,-23,4,2,'hilt');L(9,-24,1,3,'guard');line(10,-24,0.8,-0.6,17,'blade','bladeD');}
}
/* ---------- SARU ---------- */
function drawSaru(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.saru;
  if(!NOSHADOW)ell(x,GROUND+1,11,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){
    R(-14,-6,18,5,'fur');R(-14,-2,18,1,'furD');R(-8,-6,8,4,'vest');R(4,-9,8,7,'fur');R(6,-8,5,5,'face');R(4,-9,8,1,'band');
    R(7,-6,1,1,'hair');R(9,-6,1,1,'hair');for(let k=0;k<30;k++)R(-26+k,-1,1,1,k<2||k>27?'cap':'staff');
    R(-18,-4,4,2,'fur');R(-21,-6,3,2,'fur');return;
  }
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/14)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-Math.abs(Math.round(Math.sin(fr*0.2)*4));
  if(f.air&&st==='jump')bob=-1;
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);const line=(a,b,c,d,e,k,k2)=>lineT(L,a,b,c,d,e,k,k2);
  const staff=(x0,y0,ax,ay,len)=>{for(let i=0;i<len;i++){const lx=Math.round(x0+ax*i),ly=Math.round(y0+ay*i);L(lx,ly,1,1,(i<2||i>=len-2)?'cap':'staff');L(lx,ly+1,1,1,(i<2||i>=len-2)?'cap':'staffD');}};
  // tail
  const sw=Math.round(Math.sin(fr*0.1)*1.5);
  [[-7,-11],[-9,-12],[-11,-14],[-12,-16],[-12+sw,-18],[-11+sw,-20],[-9+sw,-21]].forEach(([a,b],i)=>{L(a,b,2,2,i===6?'furL':'fur');});
  const wk=st==='walk'?(Math.floor(fr/5)%2?2:-2):0;
  const kick=st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4;
  if(f.air&&st!=='hurt'&&!kick){R(-6,-13,4,6,'fur');R(1,-13,4,6,'fur');R(-7,-8,5,2,'furD');R(1,-8,5,2,'furD');}
  else{R(-6+wk,-10,4,8,'fur');R(-8+wk,-2,5,2,'furD');
    if(kick){R(1,-14,14,4,'fur');R(1,-11,14,1,'furD');R(14,-15,3,5,'furD');}
    else{R(2-wk,-10,4,8,'fur');R(3-wk,-2,5,2,'furD');}}
  L(-7,-14,14,5,'vest');L(3,-14,4,5,'vestD');
  L(-5,-24,10,11,'fur');L(-2,-22,5,7,'face');L(-6,-24,3,10,'vest');L(3,-24,3,10,'vest');L(-6,-14,12,1,'cap');
  // head
  L(-2,-34,1,2,'fur');L(0,-35,1,2,'fur');L(2,-34,1,2,'fur');
  L(-4,-32,9,8,'fur');L(-2,-30,7,6,'face');L(-5,-30,2,3,'face');
  L(-4,-31,9,1,'band');L(-5,-31,1,4,'band');L(-6,-29,1,3,'bandL');L(0,-32,1,1,'cap');
  if(st==='hurt'){L(1,-28,2,1,'hair');L(4,-28,1,1,'hair');}else{L(1,-29,1,2,'eye');L(4,-29,1,2,'eye');L(1,-29,1,1,'eyeHi');L(0,-27,1,1,'band');L(5,-27,1,1,'band');}
  L(2,-26,3,1,'mouth');L(4,-25,1,1,'fang');
  // staff by state
  const pS=A.punch.s,pA=A.punch.a,sp=A.special;
  if(st==='punch'&&f.t<=pS){L(-2,-20,3,3,'fur');staff(-16,-20,1,0,30);}
  else if(st==='punch'&&f.t<=pS+pA+3){L(3,-20,3,3,'fur');L(8,-20,3,3,'fur');staff(-2,-19,1,0,A.punch.reach+2);for(let k=0;k<3;k++)L(-8-k*4,-23+k*3,3,1,'swoosh');}
  else if(st==='punch'){L(4,-19,3,3,'fur');staff(-8,-18,1,0.08,32);}
  else if(st==='block'){L(4,-24,3,3,'fur');L(4,-15,3,3,'fur');staff(8,-36,0,1,32);}
  else if(st==='special'){
    if(f.t<=sp.at){const a=fr*0.7;L(-1,-37,3,3,'fur');for(let i=-15;i<15;i++){const lx=Math.round(Math.cos(a)*i),ly=Math.round(-38+Math.sin(a)*i*0.35);L(lx,ly,1,1,Math.abs(i)>12?'cap':'staff');}}
    else{const k=f.t<=sp.at+sp.act+2?1:Math.max(0.3,1-(f.t-sp.at-sp.act-2)/12);const len=Math.round(6+(sp.reach-6)*k);
      L(3,-20,3,3,'fur');staff(4,-19,1,0,len);for(let i=10;i<len;i+=6)L(i,-21,2,1,'bandL');L(len+2,-21,3,5,'cap');}
  }
  else if(st==='win'){L(-4,-38,3,3,'fur');L(3,-38,3,3,'fur');const a=fr*0.4;for(let i=-15;i<15;i++){L(Math.round(Math.cos(a)*i),Math.round(-40+Math.sin(a)*i*0.3),1,1,Math.abs(i)>12?'cap':'staff');}}
  else{L(1,-18,3,3,'fur');L(-4,-13,3,3,'fur');staff(-10,-6,0.8,-0.78,34);}
}
/* ---------- RYU ---------- */
function drawRyu(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.ryu;
  if(!NOSHADOW)ell(x,GROUND+1,15,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){
    R(-18,-7,28,6,'body');R(-18,-2,28,1,'bodyD');for(let k=-14;k<8;k+=4)R(k,-4,3,2,'belly');R(-30,-4,12,3,'body');R(-34,-2,4,2,'bodyD');
    R(10,-10,10,8,'body');R(18,-8,5,5,'body');R(13,-7,1,1,'hair');R(15,-7,1,1,'hair');R(11,-13,1,3,'horn');R(14,-13,1,3,'horn');
    for(let k=-16;k<8;k+=3)R(k,-9,2,2,'mane');return;
  }
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/24)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-2;
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);
  const kick=st==='kick'&&f.t>A.kick.s-3&&f.t<=A.kick.s+A.kick.a+6;
  const sw=Math.round(Math.sin(fr*0.08)*2);
  // tail
  if(kick){R(6,-9,8,5,'body');R(13,-7,9,4,'body');R(21,-5,9,3,'body');R(29,-4,4,2,'bodyD');for(let k=8;k<30;k+=4)R(k,-10+Math.floor(k/12),2,1,'mane');
    for(let k=0;k<3;k++)R(18+k*4,-12+k,3,1,'swoosh');}
  else{R(-12,-9,6,5,'body');R(-18,-7,7,4,'body');R(-24,-5+sw,7,3,'body');R(-29,-4+sw,5,2,'bodyD');for(let k=-26;k<-10;k+=4)R(k,-10+(k<-20?sw:0)+2,2,1,'mane');}
  // legs
  const wk=st==='walk'?(Math.floor(fr/9)%2?2:-2):0;
  if(f.air&&st!=='hurt'){R(-7,-15,6,8,'body');R(2,-15,6,8,'body');R(-8,-8,7,2,'bodyD');R(2,-8,7,2,'bodyD');}
  else{R(-7+wk,-13,6,11,'body');R(-7+wk,-13,2,11,'bodyD');R(-9+wk,-2,8,2,'bodyD');R(-2+wk,-2,1,1,'claw');
    R(2-wk,-13,6,11,'body');R(2-wk,-13,2,11,'bodyD');R(2-wk,-2,8,2,'bodyD');R(9-wk,-2,1,1,'claw');}
  // mane + torso
  for(let k=0;k<11;k++)L(-10+(k%2),-40+k*2,3,2,k%3?'mane':'maneD');
  L(-7,-31,14,19,'body');L(4,-31,3,19,'bodyD');for(let k=0;k<6;k++)L(-2,-29+k*3,6,2,'belly');
  // head
  const roar=st==='win'||(st==='special'&&f.t>=A.special.at-4&&f.t<A.special.at+10);const hy=st==='win'?-3:0;
  L(-4,-43+hy,10,9,'body');L(5,-40+hy,7,5,'body');L(5,-40+hy,7,1,'bodyL');L(11,-39+hy,1,1,'hair');
  if(roar){L(5,-35+hy,7,1,'mouth');L(5,-34+hy,7,2,'bodyD');L(6,-35+hy,1,1,'claw');L(10,-35+hy,1,1,'claw');}
  else{L(5,-35+hy,7,2,'bodyD');L(7,-36+hy,1,1,'claw');L(10,-36+hy,1,1,'claw');}
  if(st==='hurt')L(2,-40+hy,3,1,'hair');else{L(2,-40+hy,2,2,'eye');L(2,-40+hy,1,1,'eyeHi');L(1,-42+hy,4,1,'bodyD');}
  lineT(L,-2,-44+hy,-0.5,-1,6,'horn');lineT(L,-4,-47+hy,-1,0,3,'horn');lineT(L,1,-44+hy,-0.2,-1,5,'horn');
  lineT(L,12,-37+hy,1,0.35,8,'belly');lineT(L,11,-36+hy,0.8,0.8,6,'belly');
  // arms
  const pS=A.punch.s,pA=A.punch.a;
  if(st==='punch'&&f.t<=pS){L(-6,-28,5,4,'body');L(-8,-30,2,2,'claw');}
  else if(st==='punch'&&f.t<=pS+pA+4){L(5,-27,12,4,'body');L(16,-28,3,1,'claw');L(17,-26,3,1,'claw');L(16,-24,3,1,'claw');
    for(let k=0;k<3;k++)lineT(L,17+k*4,-36,0.5,1,11,'swoosh');}
  else if(st==='block'){L(2,-32,7,10,'body');L(8,-33,2,1,'claw');L(8,-24,2,1,'claw');}
  else{L(4,-27,5,3,'body');L(8,-25,2,2,'body');L(9,-24,1,1,'claw');}
}

/* ---------- KITSUNE ---------- */
function drawKitsune(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.kitsune;
  if(!NOSHADOW)ell(x,GROUND+1,10,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){R(-14,-6,18,5,'robe');R(-14,-2,18,1,'robeD');R(-19,-5,6,4,'hakama');R(4,-9,8,7,'fur');R(10,-7,4,3,'fur');
    R(5,-12,2,3,'fur');R(9,-12,2,3,'fur');R(7,-7,1,1,'hair');R(10,-6,1,1,'hair');R(-28,-4,10,3,'fur');R(-26,-7,8,2,'fur');R(-29,-4,2,2,'furL');return;}
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/16)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-Math.abs(Math.round(Math.sin(fr*0.2)*3));
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);
  const sw=Math.round(Math.sin(fr*0.12)*2);
  for(let t=2;t>=0;t--){for(let u=0;u<=1.001;u+=0.07){const a=Math.round(-6-9*u-t*3+sw*u*u),b=Math.round(-10-15*u+t*2*u-(t===1?3*u:0));
    const w=u<0.2?2:u>0.8?2:4;L(a-1,b-1,w,w,u>0.78?'furL':(t===1?'fur':'furD'));}}
  const wk=st==='walk'?(Math.floor(fr/5)%2?2:-2):0;const kick=st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4;
  if(f.air&&st!=='hurt'&&!kick){R(-6,-13,5,7,'hakama');R(1,-13,5,7,'hakama');R(-6,-6,4,2,'furD');R(2,-6,4,2,'furD');}
  else{R(-7+wk,-12,5,10,'hakama');R(-8+wk,-2,5,2,'furD');
    if(kick){R(1,-14,14,4,'hakama');R(14,-15,3,4,'fur');}else{R(2-wk,-12,5,10,'hakama');R(2-wk,-2,5,2,'furD');}}
  L(-7,-15,14,4,'hakama');L(3,-15,4,4,'hakamaD');
  L(-6,-25,3,8,'robeD');L(-5,-25,10,11,'robe');L(2,-25,3,11,'robeD');
  for(let k=0;k<4;k++){L(-2+k,-25+k,1,1,'hakama');L(2-k,-25+k,1,1,'hakama');}
  L(-4,-33,8,7,'fur');L(3,-31,5,3,'fur');L(7,-31,1,1,'hair');L(-4,-33,8,1,'furL');
  L(-3,-37,2,4,'fur');L(-3,-36,1,2,'mark');L(1,-37,2,4,'fur');L(1,-36,1,2,'mark');L(0,-31,3,1,'mark');
  if(st==='hurt')L(1,-30,2,1,'hair');else{L(1,-30,2,1,'eye');L(2,-30,1,1,'hair');}
  L(4,-28,3,1,'mouth');
  const pS=A.punch.s,pA=A.punch.a,fl=fr%2?'fire':'furL';
  if(st==='punch'&&f.t<=pS){L(-8,-24,3,3,'fur');}
  else if(st==='punch'&&f.t<=pS+pA+3){L(3,-23,7,3,'robe');L(9,-23,3,3,'fur');L(12,-24,2,1,'claw');L(12,-22,2,1,'claw');
    for(let a=-1.1;a<=0.35;a+=0.1)L(Math.round(6+Math.cos(a)*(A.punch.reach-6)),Math.round(-22+Math.sin(a)*18),1,1,'fire');}
  else if(st==='block'){L(3,-27,4,9,'robe');L(6,-28,2,2,'fur');}
  else if(st==='special'){L(-9,-28,3,3,fl);L(8,-28,3,3,fl);L(-1,-40,3,3,'fire');}
  else if(st==='win'){L(3,-38,3,9,'robe');L(3,-41,3,3,'fur');L(3,-45,3,3,fl);}
  else{L(3,-22,3,6,'robe');L(4,-17,3,3,'fur');L(8,-20+(Math.floor(fr/8)%2),2,2,fl);}
}
/* ---------- TENGU ---------- */
function drawTengu(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.tengu;
  if(!NOSHADOW)ell(x,GROUND+1,11,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){R(-14,-6,20,5,'robe');R(-22,-4,10,3,'feather');R(-20,-7,8,2,'featherD');R(6,-9,8,7,'feather');R(14,-7,6,2,'beak');R(9,-6,1,1,'hair');R(11,-6,1,1,'hair');return;}
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/18)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-2;
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);
  const spread=f.air||st==='win'||st==='special';const flap=Math.floor(fr/5)%2;
  if(spread){L(-24,-33+flap*2,17,3,'feather');L(-22,-30+flap*2,15,3,'featherD');L(-20,-27+flap,12,3,'feather');L(-17,-24,8,3,'featherD');for(let k=0;k<5;k++)L(-24+k*3,-30+flap*2+ (k%2),1,2,'featherL');}
  else{L(-10,-28,5,15,'featherD');L(-11,-26,2,11,'feather');}
  const wk=st==='walk'?(Math.floor(fr/6)%2?2:-2):0;const kick=st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4;
  if(f.air&&st!=='hurt'&&!kick){R(-4,-13,3,7,'featherD');R(2,-13,3,7,'featherD');R(-5,-6,5,2,'beak');R(2,-6,5,2,'beak');}
  else{R(-5+wk,-12,3,10,'featherD');R(-6+wk,-2,6,2,'beak');
    if(kick){R(2,-15,13,3,'featherD');R(14,-17,3,6,'beak');}else{R(2-wk,-12,3,10,'featherD');R(1-wk,-2,6,2,'beak');}}
  L(-6,-26,12,14,'robe');L(3,-26,3,14,'robeD');L(-2,-24,2,2,'pom');L(1,-21,2,2,'pom');L(-6,-14,12,1,'robeD');
  L(-4,-35,8,8,'feather');L(-4,-35,8,1,'featherL');L(-1,-37,3,2,'featherD');
  L(4,-31,6,2,'beak');L(4,-29,5,1,'beakD');L(9,-30,2,1,'beakD');
  if(st==='hurt'){L(1,-32,2,1,'hair');}else{L(1,-32,2,2,'eye');L(2,-32,1,1,'hair');}
  const pS=A.punch.s,pA=A.punch.a;
  if(st==='punch'&&f.t<=pS){L(-6,-34,3,3,'feather');L(-10,-42,5,8,'leaf');L(-9,-41,3,6,'leafD');}
  else if(st==='punch'&&f.t<=pS+pA+3){L(4,-24,8,3,'robe');const e=A.punch.reach;L(e-9,-31,6,11,'leaf');L(e-8,-30,4,9,'leafD');L(e-12,-22,3,1,'beakD');
    for(let k=0;k<3;k++)L(12,-30+k*4,e-20,1,'swoosh');}
  else if(st==='block'){L(4,-25,3,3,'feather');L(7,-35,6,12,'leaf');L(8,-34,4,10,'leafD');}
  else if(st==='special'&&f.t>A.special.at){for(let k=0;k<4;k++)L(-10-k*4,-34+k*5,8,1,'swoosh');L(4,-22,4,3,'feather');}
  else{L(4,-20,3,3,'feather');L(7,-28,5,8,'leaf');L(8,-27,3,6,'leafD');L(6,-21,1,2,'beakD');}
}
/* ---------- KAPPA ---------- */
function drawKappa(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.kappa;
  if(!NOSHADOW)ell(x,GROUND+1,13,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){R(-12,-7,22,6,'shell');R(-12,-3,22,2,'shellD');R(-10,-10,18,3,'belly');R(-9,-14,3,4,'skin');R(4,-14,3,4,'skin');
    R(10,-10,8,7,'skin');R(10,-12,8,2,'hair');R(16,-8,3,2,'beak');R(12,-8,1,1,'hair');R(14,-8,1,1,'hair');R(20,-4,2,1,'water');R(23,-3,1,1,'water');return;}
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/22)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-Math.abs(Math.round(Math.sin(fr*0.2)*2));
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);
  L(-12,-24,4,13,'shellD');L(-11,-27,7,18,'shell');L(-10,-24,2,2,'shellL');L(-10,-18,2,2,'shellL');L(-8,-21,2,2,'shellL');
  const wk=st==='walk'?(Math.floor(fr/8)%2?2:-2):0;const kick=st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4;
  if(f.air&&st!=='hurt'){R(-6,-12,5,6,'skin');R(2,-12,5,6,'skin');R(-7,-6,7,2,'skinD');R(1,-6,7,2,'skinD');}
  else{R(-6+wk,-9,5,7,'skin');R(-8+wk,-2,7,2,'skinD');
    if(kick){R(2,-9,15,3,'skin');R(16,-10,3,4,'skinD');}else{R(2-wk,-9,5,7,'skin');R(1-wk,-2,7,2,'skinD');}}
  L(-6,-24,12,15,'skin');L(4,-24,2,15,'skinD');L(-1,-22,6,12,'belly');L(-1,-18,6,1,'shellL');L(-1,-14,6,1,'shellL');
  L(-4,-32,9,8,'skin');L(-4,-32,9,1,'skinL');L(4,-28,5,3,'beak');L(4,-26,4,1,'shellD');
  L(-5,-33,11,2,'hair');L(-3,-35,7,2,'dish');L(-2,-36,5,1,'dish');
  if(st==='hurt')L(1,-30,2,1,'hair');else{L(1,-30,2,2,'eye');L(2,-30,1,1,'hair');}
  const pS=A.punch.s,pA=A.punch.a;
  const ring=(r)=>{for(let a=0;a<6.28;a+=0.35){const aa=a+fr*0.15;L(Math.round(Math.cos(aa)*r),Math.round(-18+Math.sin(aa)*r*1.1),1,1,'water');}};
  if(st==='punch'&&f.t<=pS){L(-8,-22,3,3,'skin');}
  else if(st==='punch'&&f.t<=pS+pA+3){L(3,-22,A.punch.reach-16,3,'skin');const e=A.punch.reach-13;L(e,-24,3,7,'skinL');for(let k=0;k<5;k++)L(e+3+k,-26+k*2,1,1,'water');}
  else if(st==='block'){L(2,-30,4,9,'skin');L(5,-31,2,2,'skinD');}
  else if(st==='special'){L(2,-31,4,10,'skin');L(-7,-31,3,6,'skin');ring(16);}
  else if(st==='win'){L(-7,-40,3,8,'skin');L(4,-40,3,8,'skin');for(let k=0;k<4;k++)L(0+(k%2),-38-k*2,1,1,'water');}
  else{L(4,-21,3,6,'skin');L(5,-16,4,2,'skinD');}
}
/* ---------- ONRYO ---------- */
function drawOnryo(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.onryo;
  if(!NOSHADOW)ell(x,GROUND+1,9,2,'rgba(0,0,0,.35)');
  if(st==='ko'&&!f.air){R(-14,-5,24,5,'robe');R(-14,-1,24,1,'robeD');R(8,-6,12,4,'hair');R(15,-3,7,2,'hair');R(6,-7,4,4,'skin');return;}
  const hov=-3+Math.round(Math.sin(fr*0.08)*1.5);let lean=st==='hurt'?-2:0;
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+hov,w,h,k);
  for(let k=-9;k<=9;k++)L(k,-6+((k*7+(fr>>3))%3),1,3,'robeD');
  for(let r=0;r<24;r++){const w=Math.round(6+r*0.16);L(-w,-30+r,w*2,1,'robe');L(w-2,-30+r,2,1,'robeD');}
  L(-6,-20,12,2,'robeD');
  L(-7,-35,3,24,'hair');L(-3,-37,7,7,'skin');L(-4,-38,9,3,'hair');
  L(-1,-35,1,9,'hair');L(1,-35,1,11,'hair');L(3,-35,1,13,'hair');L(5,-35,1,8,'hair');
  if(st!=='hurt')L(2,-32,1,1,'eyeR');
  const pS=A.punch.s,pA=A.punch.a;
  if(st==='punch'&&f.t<=pS){L(-8,-27,4,4,'robe');L(-10,-27,2,3,'skin');}
  else if(st==='punch'&&f.t<=pS+pA+3){const e=A.punch.reach;L(4,-27,e-12,3,'robe');L(e-8,-28,3,4,'skin');L(e-5,-28,3,1,'nail');L(e-5,-26,3,1,'nail');
    for(let k=0;k<4;k++)L(-6-k*3,-30+k*2,2,1,'hair');}
  else if(st==='kick'&&f.t>A.kick.s-2&&f.t<=A.kick.s+A.kick.a+4){L(2,-11,20,2,'hair');L(20,-13,5,5,'hair');L(4,-26,4,9,'robe');}
  else if(st==='block'){L(2,-31,6,11,'robe');L(6,-31,2,3,'skin');}
  else if(st==='special'){L(-13,-28,7,3,'robe');L(6,-28,7,3,'robe');L(-15,-28,2,3,'skin');L(13,-28,2,3,'skin');
    for(let a=0;a<6.28;a+=0.4)L(Math.round(Math.cos(a+fr*0.2)*14),Math.round(-20+Math.sin(a+fr*0.2)*16),1,1,'aura');}
  else if(st==='win'){L(-10,-36,4,10,'robe');L(6,-36,4,10,'robe');L(-10,-38,3,3,'skin');L(7,-38,3,3,'skin');}
  else{L(4,-27,4,10,'robe');L(6,-17,2,3,'skin');L(6,-14,2,1,'nail');}
  if(fr%24<2)L(Math.round(Math.sin(fr)*8),-38,1,1,'aura');
}

/* ---------- ENMA (boss) ---------- */
function drawEnma(f,fr,side){
  const {s,x,y,P,R}=kitTools(f,side);const st=f.st;const A=CH.enma;
  if(!NOSHADOW)ell(x,GROUND+1,16,2,'rgba(0,0,0,.45)');
  if(st==='ko'&&!f.air){R(-22,-8,32,7,'robe');R(-22,-2,32,1,'robeD');R(-12,-8,3,7,'gold');R(10,-13,10,10,'skin');R(18,-11,5,8,'beard');R(10,-17,9,4,'crown');R(13,-16,3,2,'gold');
    for(let i=0;i<26;i++){R(-34+i,-3,1,3,i<6?'hilt':'club');if(i%5===2)R(-34+i,-4,1,1,'stud');}return;}
  let bob=0,lean=0;if(st==='idle')bob=Math.floor(fr/26)%2;if(st==='hurt')lean=-2;if(st==='win')bob=-1;
  const L=(dx,dy,w,h,k)=>R(dx+lean,dy+bob,w,h,k);
  const club=(x0,y0,ax,ay,len)=>{for(let i=0;i<len;i++){const lx=Math.round(x0+ax*i),ly=Math.round(y0+ay*i);const th=i<6?2:3;L(lx,ly,th,th,i<6?'hilt':'club');if(i>6&&i%4===1)L(lx+(ax>0?0:1),ly-1,1,1,'stud');}};
  const wk=st==='walk'?(Math.floor(fr/9)%2?2:-2):0;const kick=st==='kick'&&f.t>A.kick.s-3&&f.t<=A.kick.s+A.kick.a+5;
  // legs and boots
  if(f.air&&st!=='hurt'){R(-9,-15,7,8,'robeD');R(3,-15,7,8,'robeD');R(-10,-8,9,2,'crown');R(3,-8,9,2,'crown');}
  else{R(-10+wk,-11,7,9,'robeD');R(-11+wk,-2,9,2,'crown');
    if(kick){R(3,-15,16,5,'robeD');R(18,-18,4,9,'crown');}else{R(4-wk,-11,7,9,'robeD');R(4-wk,-2,9,2,'crown');}}
  // back sleeve
  L(-18,-34,7,14,'robeD');L(-18,-21,7,2,'gold');
  // robe
  for(let r=0;r<24;r++){const w=Math.round(12-Math.abs(r-6)*0.08);L(-w,-34+r,w*2,1,'robe');L(w-3,-34+r,3,1,'robeD');}
  L(-3,-34,6,7,'inner');for(let k=0;k<4;k++){L(-4+k,-34+k,1,1,'robeL');L(3-k,-34+k,1,1,'robeL');}
  L(-12,-19,24,3,'gold');L(-12,-17,24,1,'#8A5A00');L(-2,-19,4,6,'gold');
  // head, beard, crown
  L(-6,-45,12,11,'skin');L(4,-45,2,11,'skinD');
  L(-5,-42,4,1,'beard');L(2,-42,4,1,'beard');L(-4,-43,2,1,'beard');L(3,-43,2,1,'beard');
  if(st==='hurt'){L(-3,-40,3,1,'beard');L(2,-40,3,1,'beard');}else{L(-3,-41,2,2,'eye');L(3,-41,2,2,'eye');L(-3,-41,1,1,'eyeHi');L(3,-41,1,1,'eyeHi');}
  L(0,-38,2,2,'skinD');
  L(-7,-36,14,7,'beard');for(let k=0;k<7;k++)L(-6+k*2,-29+(k%2),1,2,'beard');L(-1,-35,5,2,'mouth');L(0,-35,1,1,'fang');L(3,-35,1,1,'fang');
  L(-7,-54,14,9,'crown');L(-9,-46,18,2,'crown');L(-10,-49,2,7,'crown');L(8,-49,2,7,'crown');
  L(-3,-52,6,5,'gold');L(-2,-51,4,1,'crown');L(-2,-49,4,1,'crown');L(-2,-48,4,1,'crown');L(0,-52,1,5,'crown');
  // arms and the iron club
  const pS=A.punch.s,pA=A.punch.a;
  if(st==='punch'&&f.t<=pS){L(-2,-46,5,5,'skin');club(-1,-46,-0.7,-0.6,26);}
  else if(st==='punch'&&f.t<=pS+pA+3){L(6,-32,9,5,'robe');L(13,-31,5,5,'skin');club(16,-30,1,0.28,A.punch.reach-12);
    for(let a=-1.4;a<=0.35;a+=0.09)L(Math.round(10+Math.cos(a)*30),Math.round(-26+Math.sin(a)*30),1,1,'swoosh');}
  else if(st==='punch'){L(8,-24,5,5,'skin');club(11,-22,0.78,0.62,24);}
  else if(st==='block'){L(8,-34,5,5,'skin');club(11,-52,0,1,32);}
  else if(st==='special'){L(-16,-36,5,5,'skin');const fc=P.flame;const r=2+Math.min(4,Math.floor(f.t/3));if(!fl0(f))disc(s>0?x-14:x+14,y-42+bob,r,fc[2]);L(8,-24,5,5,'skin');club(10,-24,-0.35,-1,24);}
  else if(st==='win'){L(6,-50,5,5,'skin');club(8,-52,0.25,-1,26);}
  else{L(9,-24,5,5,'skin');club(12,-22,0.12,-1,28);}
}
function fl0(f){return f.flash>0&&f.flash%2===0;}
function poseOf(f){
  const c=CH[f.ch];let st=f.st,t=f.t;
  if(st==='crouch')st='idle';
  else if(st==='dash')st='walk';
  else if(st==='grabbed')st='hurt';
  else if(st==='throw'){st='punch';t=c.punch.s+1;}
  else if(st==='super'){if(t<SUPER.startup){st='special';t=Math.min(t,8);}else{st='punch';t=c.punch.s+1;}}
  else if((st==='punch'||st==='kick')&&(f.atk==='cpunch'||f.atk==='sweep')){const a=c[f.atk],b=c[st];t=Math.round(f.t*(b.s+b.a+b.r)/(a.s+a.a+a.r));}
  return Object.assign({},f,{st,t});
}
function drawFighterRaw(f,fr,side){
  f=poseOf(f);
  switch(f.ch){case 'saru':drawSaru(f,fr,side);break;case 'ryu':drawRyu(f,fr,side);break;case 'kitsune':drawKitsune(f,fr,side);break;
    case 'tengu':drawTengu(f,fr,side);break;case 'kappa':drawKappa(f,fr,side);break;case 'onryo':drawOnryo(f,fr,side);break;case 'enma':drawEnma(f,fr,side);break;default:drawOni(f,fr,side);}
}
let NOSHADOW=false;
const SPR=document.createElement('canvas');SPR.width=288;SPR.height=144;const SG=SPR.getContext('2d');const SOX=144,SOY=128;
const OUT=document.createElement('canvas');OUT.width=288;OUT.height=144;const OG=OUT.getContext('2d');
function outline(){
  OG.globalCompositeOperation='source-over';OG.clearRect(0,0,288,144);
  OG.drawImage(SPR,-1,0);OG.drawImage(SPR,1,0);OG.drawImage(SPR,0,-1);OG.drawImage(SPR,0,1);
  OG.globalCompositeOperation='source-in';OG.fillStyle='rgba(10,5,6,.92)';OG.fillRect(0,0,288,144);
  OG.globalCompositeOperation='source-over';OG.drawImage(SPR,0,0);
}
const HB=document.createElement('canvas');HB.width=560;HB.height=240;const HG=HB.getContext('2d');
const HO=document.createElement('canvas');HO.width=560;HO.height=240;const HOG=HO.getContext('2d');
const HR=document.createElement('canvas');HR.width=560;HR.height=240;const HRG=HR.getContext('2d');
const HAX=280,HAY=212;
function hiSkin(f,side){if(f.skin)return f.skin;return side===4?'genesis':side===2?'kin':side===3?'kongo':side?'ao':'aka';}
function hiRender(f,fr,side,rim){
  HG.setTransform(1,0,0,1,0,0);HG.clearRect(0,0,560,240);HG.imageSmoothingEnabled=false;
  HG.setTransform(f.face>0?1:-1,0,0,1,HAX,HAY);if(f.ch==='oni')hiDrawOni(HG,f,fr,hiSkin(f,side));else hiDrawAny(HG,f,fr,side);HG.setTransform(1,0,0,1,0,0);
  HOG.globalCompositeOperation='source-over';HOG.clearRect(0,0,560,240);
  HOG.drawImage(HB,-1,0);HOG.drawImage(HB,1,0);HOG.drawImage(HB,0,-1);HOG.drawImage(HB,0,1);
  HOG.globalCompositeOperation='source-in';HOG.fillStyle='rgba(8,3,4,.95)';HOG.fillRect(0,0,560,240);HOG.globalCompositeOperation='source-over';HOG.drawImage(HB,0,0);
  if(rim){HRG.globalCompositeOperation='source-over';HRG.clearRect(0,0,560,240);HRG.drawImage(HB,0,0);HRG.globalCompositeOperation='destination-out';HRG.drawImage(HB,-1,0);
    HRG.globalCompositeOperation='source-in';HRG.fillStyle=rim;HRG.fillRect(0,0,560,240);HRG.globalCompositeOperation='source-over';HOG.drawImage(HR,0,0);}
  return HO;
}
const RIM={7:'rgba(120,255,160,.55)',0:'rgba(255,220,160,.55)',1:'rgba(255,120,90,.7)',2:'rgba(120,230,220,.6)',3:'rgba(255,200,120,.6)',4:'rgba(255,170,90,.7)',5:'rgba(200,210,255,.6)',6:'rgba(255,200,110,.6)'};
const GFX={hd:(()=>{try{return localStorage.getItem('oni-gfx')!=='classic';}catch(e){return true;}})()};
const HDW=640,HDH=420,HDAX=320,HDAY=400;const HDC=new WeakMap();
function hdMk(){const c=document.createElement('canvas');c.width=HDW;c.height=HDH;return c;}
function hdSkinOf(f,side){const s=hiSkin(f,side);return (typeof HDPAL!=='undefined'&&HDPAL[s])?s:null;}
function hiRenderHD(f,fr,side,rim){
  const skin=hdSkinOf(f,side);let c=HDC.get(f);if(!c){c={B:hdMk(),O:hdMk(),R:hdMk(),key:''};HDC.set(f,c);}
  const P=hiPose(f,fr);const r2=a=>a?Math.round(a[0]*2)+','+Math.round(a[1]*2):'';
  const key=[P.hip,P.kb,P.fb,P.kf,P.ff,P.grip,P.hb].map(r2).join('|')+'|'+[P.lean,P.ang,P.len].map(v=>Math.round((v||0)*60)).join(',')+'|'+f.st+f.face+skin+(f.flash>0&&f.flash%2===0?'F':'')+(P.arc?'a':'')+(rim||'');
  if(key===c.key)return c.O;c.key=key;
  const BG=c.B.getContext('2d'),OG=c.O.getContext('2d'),RG=c.R.getContext('2d');
  BG.setTransform(1,0,0,1,0,0);BG.clearRect(0,0,HDW,HDH);BG.imageSmoothingEnabled=false;
  BG.setTransform(f.face>0?2:-2,0,0,2,HDAX,HDAY);hdDrawOni(BG,f,fr,skin);BG.setTransform(1,0,0,1,0,0);
  OG.globalCompositeOperation='source-over';OG.clearRect(0,0,HDW,HDH);
  for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]])OG.drawImage(c.B,dx,dy);
  OG.globalCompositeOperation='source-in';OG.fillStyle='rgba(8,3,4,.95)';OG.fillRect(0,0,HDW,HDH);OG.globalCompositeOperation='source-over';OG.drawImage(c.B,0,0);
  if(rim){RG.globalCompositeOperation='source-over';RG.clearRect(0,0,HDW,HDH);RG.drawImage(c.B,0,0);RG.globalCompositeOperation='destination-out';RG.drawImage(c.B,-2,1);
    RG.globalCompositeOperation='source-in';RG.fillStyle=rim;RG.fillRect(0,0,HDW,HDH);RG.globalCompositeOperation='source-over';OG.drawImage(c.R,0,0);}
  return c.O;}
function drawOniHi(f,fr,side){
  if(GFX.hd&&f.ch==='oni'&&typeof hdDrawOni==='function'&&hdSkinOf(f,side)&&f.st!=='ko'){
    const img=hiRenderHD(f,fr,side,null);const tf=ctx.getTransform();ctx.save();ctx.setTransform(1,0,0,1,tf.e,tf.f);ctx.imageSmoothingEnabled=false;
    if(f.phase>0)ctx.globalAlpha=0.35+0.15*Math.sin(fr*0.5);ctx.drawImage(img,Math.round(f.x*3-HDAX),Math.round(f.y*3-HDAY));ctx.restore();return;}
  hiRender(f,fr,side,RIM[M?M.map:1]||null);
  const tf=ctx.getTransform();ctx.save();ctx.setTransform(2,0,0,2,tf.e,tf.f);ctx.imageSmoothingEnabled=false;
  if(f.phase>0)ctx.globalAlpha=0.35+0.15*Math.sin(fr*0.5);
  ctx.drawImage(HO,Math.round(f.x*1.5-HAX),Math.round(f.y*1.5-HAY));ctx.restore();
}
function drawFighter(f,fr,side,scale){
  scale=scale||GEO;const target=G;
  if(target===ctx&&typeof hiDrawAny==='function'){if(!NOSHADOW&&f.st!=='ko')ell(f.x,GROUND+1,Math.round(12*scale),2,'rgba(0,0,0,.42)');drawOniHi(f,fr,side);return;}
  if(!NOSHADOW&&f.st!=='ko')ell(f.x,GROUND+1,Math.round(12*scale),2,'rgba(0,0,0,.42)');
  SG.setTransform(1,0,0,1,0,0);SG.clearRect(0,0,288,144);
  G=SG;const ns=NOSHADOW;NOSHADOW=true;drawFighterRaw(Object.assign({},f,{x:SOX,y:SOY,phase:0}),fr,side);NOSHADOW=ns;G=target;
  outline();
  target.save();target.imageSmoothingEnabled=false;
  if(f.phase>0||f.inv>0&&f.st!=='super')target.globalAlpha=0.35+0.15*Math.sin(fr*0.5);
  const dx=Math.round(f.x-SOX*scale),dy=Math.round(f.y-SOY*scale);
  const crouch=f.crouch&&!f.air&&f.st!=='ko'&&f.st!=='hurt';
  if(crouch){
    const drop=Math.round(CH[f.ch].h*0.34),legs=14;const cut=SOY-legs;
    target.drawImage(OUT,0,0,288,cut,dx,dy+Math.round(drop*scale),Math.round(288*scale),Math.round(cut*scale));
    target.drawImage(OUT,0,cut,288,legs+2,dx,dy+Math.round((cut+drop)*scale),Math.round(288*scale),Math.round(Math.max(4,legs-drop)*scale+2));
  } else target.drawImage(OUT,dx,dy,Math.round(288*scale),Math.round(144*scale));
  if(f.st==='super'&&f.t<SUPER.startup){target.globalAlpha=0.5;const pc=PAL[f.ch][side]||{};target.fillStyle=pc.main||'#FFB000';
    for(let k=0;k<8;k++){const a=k/8*6.28+fr*0.3;target.fillRect(Math.round(f.x+Math.cos(a)*22),Math.round(f.y-24+Math.sin(a)*22),2,2);}}
  target.restore();
}
function drawProj(p,fr,pal){
  if(pal==null)pal=p.owner;const s=p.vx>0?1:-1;
  if(p.kit==='ryu'||p.kit==='enma'){const c=p.kit==='enma'?PAL.enma[pal].flame:PAL.ryu[pal].breath;const r=p.r;
    for(let k=1;k<6;k++)disc(p.x-s*k*4,p.y+Math.sin((fr+k)*0.8),Math.max(1,r-3-k),c[3]);
    disc(p.x,p.y,r,c[3]);disc(p.x+s,p.y,r-2,c[2]);disc(p.x+s*2,p.y-1,r-4,c[1]);disc(p.x+s*3,p.y-1,Math.max(1,r-7),c[0]);
    for(let k=0;k<4;k++)px(p.x+Math.cos(fr*0.5+k)*r,p.y+Math.sin(fr*0.5+k)*r,c[1]);return;}
  const c=PAL.oni[pal].flame;
  for(let k=1;k<6;k++)px(p.x-s*(k*3+3),p.y+((fr+k)%3)-1,c[(k%3)+1]);
  disc(p.x,p.y,6,c[3]);disc(p.x+s,p.y-1,4,c[2]);disc(p.x+s*2,p.y-1,3,c[1]);disc(p.x+s*2,p.y-2,1,c[0]);
  rect(p.x-s*7,p.y-4+(fr%2),4,1,c[2]);rect(p.x-s*8,p.y+2-(fr%2),4,1,c[3]);
}

/* ===================== ARENAS ===================== */
const MAPS=[
  {id:'summit',name:'Kurama Summit',stake:300,amb:'petal'},
  {id:'temple',name:'Blood Moon Temple',stake:1000,amb:'ember'},
  {id:'yomi',name:'Gates of Yomi',stake:2500,amb:'wisp'},
  {id:'colosseum',name:'Oni Colosseum',stake:null,min:5000,max:50000,amb:'gold'},
  {id:'bridge',name:'Sunset Bridge',tourney:true,amb:'fire'},
  {id:'castle',name:'Daimyo Castle',tourney:true,amb:'spark'},
  {id:'hall',name:"Shogun's Hall",tourney:true,amb:'ember'},
  {id:'launchpad',name:'The Launchpad',stake:10000,amb:'spark'},
  {id:'helipad',name:'Sky Helipad',tourney:true,amb:'spark'}
];
const BG=[];
function mkRnd(seed){return()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};}
function bands(cols,h){for(let i=0;i<cols.length;i++){rect(0,i*h,W,h,cols[i]);if(i>0)for(let x=0;x<W;x+=2){px(x+(i%2),i*h,cols[i-1]);px(x+((i+1)%2),i*h+2,cols[i-1]);}}}
function kanji(list,color,size){G.textAlign='center';G.textBaseline='middle';G.font=(size||12)+'px serif';G.fillStyle=color;list.forEach(([k,a,b])=>G.fillText(k,a,b));}
function lantern(lx,ly,body,core){rect(lx,0,1,ly-8,'#2A0C0D');G.fillStyle='rgba(255,106,0,.14)';G.beginPath();G.arc(lx,ly,14,0,Math.PI*2);G.fill();
  rect(lx-3,ly-9,7,2,'#1A0506');ell(lx,ly,5,7,body);ell(lx,ly,3,5,core);rect(lx-5,ly-2,11,1,'#00000055');rect(lx-5,ly+3,11,1,'#00000055');rect(lx-3,ly+7,7,2,'#1A0506');}
function buildSummit(){
  const r=mkRnd(5);
  // bright sky
  const sky=['#5FB4F0','#72C0F2','#86CBF4','#9AD5F5','#AEDEF6','#C2E7F7','#D6EFF8'];bands(sky,12);
  disc(250,26,13,'#FFF4C8');disc(250,26,10,'#FFFFFF');
  const cloud=(x,y,w)=>{ell(x,y,w,4,'#FFFFFF');ell(x-w*0.4,y+2,w*0.6,3,'#F2F8FC');ell(x+w*0.4,y+1,w*0.5,3,'#FFFFFF');};
  cloud(60,22,20);cloud(170,14,26);cloud(290,40,16);cloud(120,46,14);
  // far sea
  rect(0,62,W,12,'#2F7FC8');rect(0,62,W,1,'#9AD5F5');for(let i=0;i<50;i++)rect(r()*W,63+r()*10,2+r()*4,1,'#BFE4FF');
  // distant islands
  ell(40,62,22,3,'#4C8FB0');ell(210,62,14,2,'#4C8FB0');
  // plains with patchwork fields and a river
  rect(0,74,W,40,'#7CC46A');
  const fieldC=['#8ED27A','#A6DA6E','#C8E06A','#6FB85E','#E2D27A','#94CC84'];
  for(let y=74;y<114;y+=5)for(let x=-10;x<W;){const w=10+r()*22;rect(x,y,w,5,fieldC[Math.floor(r()*fieldC.length)]);rect(x,y,w,1,'rgba(255,255,255,.18)');x+=w;}
  let rx=150;for(let y=74;y<114;y++){rx+=Math.round((r()-0.5)*3);rect(rx,y,3+Math.floor((y-74)/10),1,'#5AA8E0');}
  for(let i=0;i<9;i++){const vx=20+r()*280,vy=80+r()*28;rect(vx,vy,4,3,'#F3E9E4');rect(vx-1,vy-1,6,1,'#C1121F');}
  // forested mountainside below the summit
  rect(0,112,W,30,'#4E7E4E');for(let x=0;x<W;x+=2)rect(x,110+Math.round(Math.sin(x*0.07)*2),2,3,'#5A8A55');
  for(let i=0;i<70;i++){const tx=r()*W,ty=114+r()*24;rect(tx,ty,1,3,'#2E4A2E');rect(tx-1,ty+1,3,2,'#3E6A40');px(tx,ty-1,'#3E6A40');}
  for(let i=0;i<30;i++)px(r()*W,113+r()*26,'#7FB070');
  // side mountains
  const slope=(x0,dir,top,c,cs)=>{for(let i=0;i<150;i++){const x=x0+dir*i;const h=Math.max(0,top-i*0.9+Math.sin(i*0.25)*3);rect(x,150-h,1,h,c);if(i%3===0)px(x,150-h,cs);}};
  slope(0,1,95,'#6A8A7A','#E8F0F0');slope(W-1,-1,88,'#6A8A7A','#E8F0F0');
  slope(0,1,66,'#4F7A5A','#7FA880');slope(W-1,-1,60,'#4F7A5A','#7FA880');
  // summit plateau
  rect(0,140,W,40,'#8A7A66');for(let x=0;x<W;x+=2)rect(x,138+Math.round(Math.sin(x*0.1)*2),2,3,'#9A8A74');
  rect(0,150,W,30,'#7A6A58');rect(0,150,W,1,'#B0A088');
  for(let i=0;i<40;i++){const gx=r()*W,gy=151+r()*26;rect(gx,gy,4+r()*8,2,'#6A5A4A');}
  for(let i=0;i<22;i++){const gx=r()*W;rect(gx,149,1,3,'#5FA85A');rect(gx+2,148,1,4,'#6FB85E');}
  // shrine gate and sacred rope
  rect(18,96,4,54,'#C1121F');rect(62,96,4,54,'#C1121F');rect(12,92,60,4,'#D7262E');rect(12,92,60,1,'#FF6B5E');px(11,91,'#D7262E');px(72,91,'#D7262E');rect(16,102,52,3,'#C1121F');
  for(let x=22;x<62;x+=1)px(x,109+Math.round(Math.sin((x-22)/40*Math.PI)*3),'#E8D9A0');
  [30,40,50].forEach(x=>{rect(x,112,1,5,'#FFFFFF');rect(x+1,114,1,4,'#FFFFFF');});
  // cherry tree on the right edge
  rect(292,100,5,50,'#5A3A2A');rect(286,108,8,3,'#5A3A2A');rect(280,104,8,3,'#5A3A2A');
  for(let i=0;i<60;i++){const a=r()*6.28,d=r()*22;rect(290+Math.cos(a)*d*1.2,94+Math.sin(a)*d*0.7,3,3,r()<0.5?'#FFB7D0':'#FF8FB8');}
  G.fillStyle='rgba(255,183,208,.0)';
}
function buildBridge(){
  const r=mkRnd(71);
  bands(['#2A1A4A','#4A2256','#7A2E56','#B8424A','#E0683A','#F29444','#F8BC62'],13);
  // sun on the horizon
  for(let k=5;k>=0;k--){G.fillStyle=`rgba(255,${180+k*10},${90+k*20},${0.08+k*0.02})`;G.beginPath();G.arc(206,84,26+k*6,0,Math.PI*2);G.fill();}
  disc(206,84,20,'#FFB24A');disc(206,84,17,'#FFD27A');disc(202,80,9,'#FFF0B8');
  // mountains
  const ridge=(base,amp,c,seed)=>{for(let x=0;x<W;x++){const h=amp*(0.55+0.45*Math.sin(x*0.02+seed)+0.2*Math.sin(x*0.07+seed*2));rect(x,base-h,1,h+2,c);}};
  ridge(86,26,'#5A2A5A',1);ridge(88,14,'#3E1E48',4);
  // lake with sun reflection
  rect(0,88,W,62,'#2E3A6A');for(let y=90;y<150;y+=3)rect(0,y,W,1,'#34427A');
  for(let y=90;y<150;y+=2){const w=Math.round(18-((y-90)/60)*8+Math.sin(y)*3);rect(206-w,y,w*2,1,y%4?'#F29444':'#FFD27A');}
  for(let i=0;i<60;i++)rect(r()*W,90+r()*58,2+r()*3,1,'#6A7AB0');
  // floating lanterns
  for(let i=0;i<9;i++){const lx=20+r()*280,ly=108+r()*36;rect(lx,ly,4,3,'#FF9A3A');px(lx+1,ly-1,'#FFE08A');rect(lx,ly+3,4,1,'#5A2A1A');G.fillStyle='rgba(255,154,58,.18)';G.fillRect(lx-2,ly+4,8,2);}
  // pines
  const pine=(x,h)=>{rect(x,150-h,2,h,'#1A0E1E');for(let k=0;k<5;k++){const w=10-k*1.6;rect(x-w+1,150-h+k*6+2,w*2,4,'#1E1428');}};
  pine(14,62);pine(30,48);pine(300,58);pine(284,44);
  // bridge railing (behind the fighters)
  rect(0,126,W,4,'#C1121F');rect(0,126,W,1,'#FF5A4E');rect(0,138,W,2,'#9A0E18');
  for(let x=8;x<W;x+=40){rect(x,122,4,28,'#C1121F');rect(x+1,122,1,28,'#FF5A4E');disc(x+2,120,3,'#E0B040');px(x+1,118,'#FFE08A');}
  // wooden deck
  rect(0,150,W,30,'#6A3A22');rect(0,150,W,2,'#9A5A32');for(let y=154;y<H;y+=5)rect(0,y,W,1,'#4A2616');
  for(let x=0;x<W;x+=26)rect(x+((Math.floor(x/26))%2)*8,152,1,28,'#4A2616');
}
function buildCastle(){
  const r=mkRnd(83);
  bands(['#060A22','#0A1030','#0E163C','#131C48','#182254','#1C2860'],20);
  for(let i=0;i<70;i++)px(r()*W,r()*100,r()<0.2?'#FFE08A':'#AFC0FF');
  disc(52,36,16,'#FFF4C8');disc(52,36,14,'#FFFBE8');ell(47,31,4,2,'#FFFFFF');px(57,40,'#E8DCB0');px(50,42,'#E8DCB0');
  // fireworks
  const burst=(cx,cy,rad,c1,c2)=>{for(let a=0;a<6.28;a+=0.26){for(let k=3;k<=rad;k+=3){px(cx+Math.cos(a)*k,cy+Math.sin(a)*k,k>rad-4?c2:c1);}}disc(cx,cy,2,'#FFFFFF');};
  burst(250,30,16,'#FF5A4E','#FFD27A');burst(292,58,11,'#2EC4B6','#BFFFF8');burst(206,20,9,'#FFB000','#FFFFFF');
  // castle keep
  const cx=160;
  rect(cx-54,104,108,34,'#4A4A58');for(let y=106;y<138;y+=6)for(let x=cx-54+((y/6)%2)*6;x<cx+54;x+=12)rect(x,y,11,5,'#5A5A6A');
  const tier=(y,w,h)=>{rect(cx-w/2,y,w,h,'#E8E4DC');rect(cx-w/2,y,w,2,'#FFFFFF');for(let x=cx-w/2+6;x<cx+w/2-6;x+=12)rect(x,y+h/2-2,5,4,'#FFB24A');
    rect(cx-w/2-8,y-5,w+16,5,'#2A2F45');px(cx-w/2-9,y-6,'#2A2F45');px(cx+w/2+8,y-6,'#2A2F45');rect(cx-w/2-6,y-6,w+12,1,'#4A5070');};
  tier(84,86,20);tier(66,66,18);tier(50,46,16);tier(38,28,12);
  rect(cx-10,30,20,4,'#2A2F45');px(cx-12,29,'#FFB000');px(cx+11,29,'#FFB000');rect(cx-13,26,3,3,'#FFB000');rect(cx+10,26,3,3,'#FFB000');
  // courtyard walls with tile caps
  rect(0,122,cx-58,20,'#E8E4DC');rect(cx+58,122,W,20,'#E8E4DC');rect(0,118,cx-56,4,'#2A2F45');rect(cx+56,118,W,4,'#2A2F45');
  for(let x=0;x<W;x+=6)if(x<cx-58||x>cx+58)px(x,117,'#4A5070');
  // clan banners
  [[24],[120],[200],[296]].forEach(([bx],i)=>{rect(bx,92,2,58,'#3A2A1A');rect(bx+2,94,12,34,i%2?'#F3E9E4':'#C1121F');disc(bx+8,110,4,i%2?'#C1121F':'#F3E9E4');});
  // pine
  rect(62,112,4,38,'#3A2A1A');[[50,108,20],[56,100,16],[62,94,12]].forEach(([x,y,w])=>rect(x,y,w,6,'#1E4A2E'));
  // raked gravel
  rect(0,150,W,30,'#8A8A94');rect(0,150,W,1,'#B0B0BA');for(let y=154;y<H;y+=4)for(let x=0;x<W;x+=2)px(x,y+Math.round(Math.sin(x*0.08)*1),'#7A7A84');
}
function buildHall(){
  const r=mkRnd(97);
  rect(0,0,W,H,'#1A0E0A');
  // ceiling beams
  rect(0,0,W,14,'#2A1A12');for(let x=0;x<W;x+=40)rect(x,0,6,14,'#3A2418');rect(0,14,W,2,'#8A5A20');
  // gold folding screens with pines and clouds
  for(let i=0;i<8;i++){const x=i*40,y=22;rect(x+1,y,38,104,i%2?'#D8A83A':'#C8962A');rect(x+1,y,38,2,'#FFE08A');rect(x+39,y,1,104,'#8A5A10');
    for(let k=0;k<30;k++)px(x+2+r()*36,y+2+r()*100,'#E8C060');}
  const cloud=(x,y,w)=>{ell(x,y,w,3,'#F3E9E4');ell(x+w*0.6,y-2,w*0.5,3,'#F3E9E4');};
  cloud(40,40,14);cloud(150,34,18);cloud(260,46,14);cloud(96,64,10);
  const pineB=(x,y)=>{rect(x,y,3,30,'#4A2A1A');rect(x-10,y+2,24,5,'#2E6A3A');rect(x-6,y-3,16,5,'#3A7A44');rect(x-14,y+10,18,4,'#2E6A3A');};
  pineB(70,70);pineB(236,64);
  // throne dais
  rect(116,104,88,22,'#5A1A12');rect(116,104,88,2,'#C88A20');rect(126,96,68,8,'#6A2016');rect(126,96,68,1,'#FFB000');
  rect(146,78,28,20,'#C1121F');rect(146,78,28,2,'#FF6B5E');
  // helmet on the throne
  ell(160,72,9,6,'#2A2A34');rect(151,72,18,4,'#2A2A34');rect(157,62,6,6,'#FFB000');px(155,61,'#FFB000');px(164,61,'#FFB000');
  // pillars
  [[8],[48],[272],[304]].forEach(([x])=>{rect(x,14,10,122,'#8E1015');rect(x+2,14,2,122,'#C1121F');rect(x-2,126,14,6,'#3A2418');rect(x-2,14,14,4,'#C88A20');});
  // hanging banners
  [[90],[222]].forEach(([x])=>{rect(x,16,16,40,'#8E1015');rect(x,16,16,2,'#FFB000');rect(x+4,52,8,6,'#8E1015');disc(x+8,30,5,'#FFB000');disc(x+8,30,3,'#8E1015');});
  // braziers
  [[34],[286]].forEach(([x])=>{rect(x-6,132,12,6,'#3A2A20');rect(x-2,138,4,12,'#2A1A12');G.fillStyle='rgba(255,140,40,.2)';G.beginPath();G.arc(x,126,18,0,Math.PI*2);G.fill();
    disc(x,128,5,'#FF6A00');disc(x,126,3,'#FFB000');px(x,122,'#FFF2A8');});
  // tatami floor
  rect(0,136,W,14,'#3A2418');rect(0,136,W,1,'#8A5A20');
  rect(0,150,W,30,'#B8B070');rect(0,150,W,1,'#E0D890');
  for(let x=0;x<W;x+=64)rect(x,150,2,30,'#2A3A2A');rect(0,164,W,2,'#2A3A2A');for(let x=32;x<W;x+=64)rect(x,164,2,16,'#2A3A2A');
  for(let i=0;i<120;i++)px(r()*W,151+r()*28,'#A8A060');
  G.fillStyle='rgba(255,200,90,.08)';G.fillRect(0,150,W,30);
}
function buildBamboo(){
  const r=mkRnd(3);bands(['#06140E','#0A1C14','#0E2419','#122C1E','#173524','#1C3F2A','#224A31'],22);
  disc(78,36,20,'#1E3A2A');disc(78,36,18,'#E8E4C8');disc(74,32,14,'#F6F2DC');ell(70,28,4,2,'#FFFFFF');
  for(let i=0;i<30;i++)px(r()*W,r()*80,'#CFE8C0');
  const stalk=(x,w,c,cd,node,top)=>{rect(x,top,w,150-top,c);rect(x+w-1,top,1,150-top,cd);for(let y=top+10;y<150;y+=14+Math.floor(r()*6)){rect(x-1,y,w+2,2,node);}
    for(let k=0;k<3;k++){const ly=top+10+r()*80;for(let j=0;j<7;j++)px(x+w+j,ly+j*0.5,'#2F6B3A');}};
  for(let i=0;i<22;i++)stalk(r()*W,3,'#123322','#0B2217','#1E4A30',20+r()*30);
  for(let i=0;i<14;i++)stalk(r()*W,5,'#2E6B3E','#1E4A2A','#4F9A5E',r()*20);
  [[40,120],[282,122]].forEach(([tx,ty])=>{rect(tx-5,ty,10,30,'#3A3A36');rect(tx-9,ty-4,18,4,'#4A4A44');rect(tx-4,ty+6,8,7,'#FFB000');rect(tx-3,ty+7,6,5,'#FFE08A');rect(tx-11,ty-7,22,3,'#4A4A44');G.fillStyle='rgba(255,176,0,.12)';G.beginPath();G.arc(tx,ty+9,16,0,Math.PI*2);G.fill();});
  rect(0,150,W,30,'#1D2A1E');rect(0,150,W,1,'#4F7A4A');for(let gx=0;gx<W;gx+=18)rect(gx,152,1,28,'#162118');for(let gy=160;gy<H;gy+=9)rect(0,gy,W,1,'#162118');
  for(let i=0;i<40;i++)px(r()*W,152+r()*26,r()<0.5?'#3F6B3A':'#6B8A4A');
  kanji([['竹',160,60]],'rgba(207,232,192,.18)',14);
}
function buildTemple(){
  const r=mkRnd(11);bands(['#070304','#0D0506','#140708','#1E090A','#2A0C0D','#3A1012','#4A1513'],22);
  for(let i=0;i<40;i++)px(r()*W,r()*80,r()<0.3?'#FF6A00':'#6B3A3A');
  disc(252,40,24,'#3A0A0C');disc(252,40,22,'#6E0B10');disc(252,40,21,'#8E1015');disc(248,36,16,'#B3161F');ell(244,31,5,3,'#D7262E');
  for(let k=0;k<9;k++)px(258+k,34+Math.round(k*0.7),'#5A0A0E');
  kanji([['呪',30,38],['鬼',74,22],['火',196,62],['刀',298,96],['桜',22,98],['甘',132,28]],'rgba(46,196,182,.32)',12);
  const pagoda=(cx,base,w,tiers)=>{let yy=base;for(let t=0;t<tiers;t++){const bw=w-t*6,h=12;rect(cx-bw/2+3,yy-h,bw-6,h,'#0B0506');rect(cx-bw/2-3,yy-h-3,bw+6,3,'#0B0506');
      px(cx-bw/2-4,yy-h-4,'#0B0506');px(cx+bw/2+3,yy-h-4,'#0B0506');if(r()<0.8)rect(cx-2,yy-h+4,4,4,'#FF6A00');yy-=h+3;}rect(cx-1,yy-8,2,8,'#0B0506');};
  pagoda(30,150,44,4);pagoda(290,150,40,3);pagoda(262,150,30,2);
  let x=0;while(x<W){const w=14+r()*20,h=12+r()*16;rect(x,150-h,w,h,'#120708');x+=w;}
  rect(98,72,6,78,'#6E0B10');rect(216,72,6,78,'#6E0B10');rect(99,72,2,78,'#8E1015');rect(217,72,2,78,'#8E1015');
  rect(84,64,152,6,'#8E1015');rect(84,64,152,2,'#B3161F');px(83,63,'#8E1015');px(82,62,'#8E1015');px(236,63,'#8E1015');px(237,62,'#8E1015');
  rect(92,78,136,4,'#6E0B10');rect(152,66,16,14,'#1A0506');kanji([['鬼',160,73]],'#FFB000',9);
  [[46,48],[274,74],[128,40]].forEach(([a,b])=>lantern(a,b,'#C1121F','#FF6A00'));
  rect(0,140,W,10,'rgba(193,18,31,.12)');rect(0,150,W,30,'#1A1111');rect(0,150,W,1,'#7A1A12');rect(0,151,W,1,'#2A0C0D');
  for(let gx=0;gx<W;gx+=24)rect(gx,152,1,28,'#241818');for(let gy=160;gy<H;gy+=8)rect(0,gy,W,1,'#241818');
  for(let i=0;i<20;i++)px(r()*W,156+r()*22,r()<0.5?'#FF6A00':'#7A1A12');
}
function buildYomi(){
  const r=mkRnd(23);bands(['#05030A','#090512','#0E071B','#140A24','#1A0D2C','#1F1034','#23123A'],22);
  for(let i=0;i<50;i++)px(r()*W,r()*100,r()<0.4?'#2EC4B6':'#4A3A6A');
  // great gate
  rect(104,34,112,116,'#07040C');rect(108,38,104,112,'#120B1C');rect(158,38,4,112,'#07040C');
  for(let k=0;k<6;k++){rect(112,48+k*17,42,1,'#1F1430');rect(166,48+k*17,42,1,'#1F1430');}
  rect(96,26,128,8,'#07040C');rect(92,22,136,4,'#1F1430');px(90,21,'#1F1430');px(229,21,'#1F1430');
  ell(160,30,7,4,'#3A0A0C');ell(160,30,5,3,'#C1121F');rect(159,28,2,5,'#FFB000');
  G.fillStyle='rgba(46,196,182,.10)';G.fillRect(108,120,104,30);
  kanji([['黄泉',160,90]],'rgba(46,196,182,.55)',14);
  // jagged rocks
  const rock=(x0,w,h,c)=>{for(let i=0;i<w;i++){const hh=Math.round(h*(0.5+0.5*Math.sin(i*0.35+x0))+r()*4);rect(x0+i,150-hh,1,hh,c);}};
  rock(0,100,50,'#0B0714');rock(220,100,54,'#0B0714');rock(0,90,26,'#140C20');rock(236,84,30,'#140C20');
  // hitodama flames
  [[40,70],[282,62],[70,104],[250,100]].forEach(([a,b])=>{G.fillStyle='rgba(46,196,182,.15)';G.beginPath();G.arc(a,b,10,0,Math.PI*2);G.fill();disc(a,b,3,'#2EC4B6');disc(a,b-1,2,'#BFFFF8');rect(a-1,b-6,2,3,'#2EC4B6');});
  // river of souls + floor
  rect(0,144,W,6,'#0C3A3A');for(let i=0;i<W;i+=3)px(i,145+((i*7)%4),'#2EC4B6');
  rect(0,150,W,30,'#120D18');rect(0,150,W,1,'#2EC4B6');
  for(let i=0;i<14;i++){let cx=r()*W,cy=154+r()*22;for(let k=0;k<8;k++){px(cx,cy,'#1E6B66');cx+=r()<0.5?1:-1;cy+=r()<0.5?1:0;}}
  for(let gy=160;gy<H;gy+=9)rect(0,gy,W,1,'#1A1222');
}
function buildColosseum(){
  const r=mkRnd(41);bands(['#0A0506','#120708','#1A0A0B','#220C0D','#2A0E0F'],22);
  // stands
  for(let t=0;t<6;t++){const yy=30+t*16;rect(0,yy,W,16,t%2?'#1A0E0E':'#221212');rect(0,yy,W,1,'#3A1A18');
    for(let x=2;x<W;x+=4){if(r()<0.85){const c=['#C1121F','#FFB000','#F3E9E4','#2F6FE0','#2EC4B6','#8A5A3A','#6B7593'][Math.floor(r()*7)];rect(x,yy+5+(x%3),2,2,c);rect(x,yy+8+(x%3),2,3,'#0E0808');}}}
  // banners
  [[30],[100],[220],[290]].forEach(([bx],i)=>{rect(bx-1,0,2,40,'#3A1A18');rect(bx-10,4,20,30,i%2?'#C1121F':'#1A0506');rect(bx-10,34,4,4,i%2?'#C1121F':'#1A0506');rect(bx+6,34,4,4,i%2?'#C1121F':'#1A0506');
    kanji([['鬼',bx,18]],i%2?'#FFB000':'#C1121F',12);});
  // spotlights
  G.fillStyle='rgba(255,236,190,.07)';G.beginPath();G.moveTo(60,0);G.lineTo(110,150);G.lineTo(160,150);G.closePath();G.fill();
  G.beginPath();G.moveTo(260,0);G.lineTo(160,150);G.lineTo(210,150);G.closePath();G.fill();
  // wall + torches
  rect(0,126,W,24,'#2A1614');rect(0,126,W,2,'#5A2A20');for(let x=0;x<W;x+=20)rect(x,128,1,22,'#1A0C0A');
  [[20],[160],[300]].forEach(([tx])=>{rect(tx-1,110,3,16,'#3A1A12');disc(tx,108,3,'#FF6A00');disc(tx,107,2,'#FFE08A');G.fillStyle='rgba(255,106,0,.15)';G.beginPath();G.arc(tx,108,12,0,Math.PI*2);G.fill();});
  // sand
  rect(0,150,W,30,'#6B4A2A');rect(0,150,W,1,'#A87A45');for(let i=0;i<260;i++)px(r()*W,151+r()*29,r()<0.5?'#7E5A34':'#58391E');
  ell(160,166,70,9,'rgba(193,18,31,.18)');
}

/* ===================== HI-RES ARENAS (480x270) ===================== */
const BGHI={};
function buildTempleHi(){
  const W=480,H=270,GROUND=232;const cvh=document.createElement('canvas');cvh.width=W;cvh.height=H;let g=cvh.getContext('2d');g.imageSmoothingEnabled=false;
  const R=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};const P=(x,y,c)=>R(x,y,1,1,c);
  const poly=(pts,c)=>hiPoly(g,pts,c);
  const disc=(cx,cy,r,c)=>{g.fillStyle=c;for(let dy=-r;dy<=r;dy++){const w=Math.round(Math.sqrt(r*r-dy*dy));g.fillRect(Math.round(cx-w),Math.round(cy+dy),w*2+1,1);}};
  let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
const sky=['#070304','#0B0405','#110607','#18080A','#210B0D','#2C0E10','#3A1213','#4A1715','#5C1D17','#6E2419'];
for(let i=0;i<sky.length;i++){R(0,i*20,W,20,sky[i]);if(i)for(let x=0;x<W;x+=2){P(x+(i%2),i*20,sky[i-1]);P(x+((i+1)%2),i*20+2,sky[i-1]);P(x+(i%2),i*20+4,sky[i-1]);}}
R(0,200,W,70,'#6E2419');
for(let i=0;i<110;i++){const x=rnd()*W,y=rnd()*130;P(x,y,rnd()<0.15?'#FFB06A':rnd()<0.5?'#8A5A5A':'#D8C0B0');}
// blood moon with glow and craters
for(let k=20;k>=1;k--){g.fillStyle='rgba(255,70,40,0.014)';g.beginPath();g.arc(372,78,36+k*3.4,0,Math.PI*2);g.fill();}
disc(372,78,36,'#5A0A0E');disc(372,78,34,'#8E1015');disc(368,74,30,'#B3161F');disc(363,69,22,'#D02A26');disc(356,62,10,'#E8483A');
for(const [x,y,r] of [[384,70,5],[364,92,4],[390,92,3],[352,80,3],[378,58,2],[396,78,2]]){disc(x,y,r,'#8E1015');disc(x-1,y-1,r-1,'#A8151D');}
// thin clouds over the moon
for(const [x,y,w] of [[300,70,110],[330,86,90],[270,104,70],[410,60,60]]){R(x,y,w,2,'rgba(26,6,8,.85)');R(x+8,y+2,w-24,1,'rgba(26,6,8,.6)');}
// mountains
const ridge=(base,amp,c,sd,f)=>{for(let x=0;x<W;x++){const h=amp*(0.55+0.45*Math.sin(x*f+sd)+0.18*Math.sin(x*f*3.3+sd*2));R(x,base-h,1,h+2,c);}};
ridge(176,46,'#2A0C0E',1.3,0.011);ridge(186,30,'#1E0809',4.1,0.017);
// pagodas with rim light and lit windows
function pagoda(cx,base,w,tiers,dark,rim){let y=base;for(let t=0;t<tiers;t++){const bw=w-t*9,h=17;
  R(cx-bw/2+4,y-h,bw-8,h,dark);for(let k=0;k<3;k++)R(cx-bw/2+8+k*((bw-20)/2),y-h+6,4,6,rnd()<0.8?'#FF8A2A':'#3A1010');
  poly([[cx-bw/2-8,y-h],[cx+bw/2+8,y-h],[cx+bw/2+2,y-h-5],[cx-bw/2-2,y-h-5]],dark);P(cx-bw/2-9,y-h-1,dark);P(cx+bw/2+9,y-h-1,dark);R(cx-bw/2-2,y-h-5,bw+4,1,rim);y-=h+5;}
  R(cx-1,y-12,3,12,dark);P(cx,y-13,rim);}
pagoda(44,212,60,5,'#0C0405','#5A1E16');pagoda(438,212,54,4,'#0C0405','#5A1E16');pagoda(398,212,40,3,'#0A0304','#4A1612');
// far roofs
let x=0;while(x<W){const w=24+rnd()*36,h=16+rnd()*20;R(x,212-h,w,h,'#120607');poly([[x-4,212-h],[x+w+4,212-h],[x+w-4,212-h-6],[x+4,212-h-6]],'#120607');x+=w+4;}
// fog band
for(let y=196;y<216;y++){g.fillStyle=`rgba(180,60,40,${0.06*(1-Math.abs(y-206)/10)})`;g.fillRect(0,y,W,1);}
// torii gate, shaded
const tc='#A0141C',tl='#D02A26',td='#6E0B10',bk='#1A0708';
R(150,106,10,110,tc);R(150,106,3,110,tl);R(157,106,3,110,td);R(320,106,10,110,tc);R(320,106,3,110,tl);R(327,106,3,110,td);
R(146,208,18,10,'#2A1210');R(316,208,18,10,'#2A1210');
poly([[120,92],[360,92],[368,84],[112,84]],bk);R(112,84,256,2,'#3A1A18');P(110,82,bk);P(111,83,bk);P(369,83,bk);P(370,82,bk);
R(128,92,224,8,tc);R(128,92,224,2,tl);R(128,98,224,2,td);R(140,114,200,6,tc);R(140,114,200,1,tl);R(140,119,200,1,td);
R(228,98,24,18,bk);R(230,100,20,14,'#2A0C0D');g.fillStyle='#FFB000';g.font='12px serif';g.textAlign='center';g.textBaseline='middle';g.fillText('鬼',240,107);
// hanging lanterns with glow
for(const [lx,ly] of [[80,70],[420,112],[196,58]]){R(lx,0,1,ly-11,'#2A0C0D');
  for(let k=14;k>=1;k--){g.fillStyle=`rgba(255,120,40,${0.018})`;g.beginPath();g.arc(lx,ly,6+k*2.6,0,Math.PI*2);g.fill();}
  R(lx-5,ly-12,11,3,'#1A0506');for(let dy=-9;dy<=9;dy++){const w=Math.round(8*Math.sqrt(1-(dy*dy)/100));R(lx-w,ly+dy,w*2+1,1,dy<-6||dy>6?'#8E1015':'#C1121F');}
  for(let dy=-7;dy<=7;dy++){const w=Math.round(5*Math.sqrt(1-(dy*dy)/64));R(lx-w,ly+dy,w*2+1,1,Math.abs(dy)<3?'#FFD27A':'#FF8A2A');}
  for(const dy of [-5,0,5])R(lx-8,ly+dy,17,1,'rgba(90,10,14,.6)');R(lx-5,ly+10,11,3,'#1A0506');R(lx,ly+13,1,4,'#C1121F');}
// stone floor with perspective and moon reflection
R(0,216,W,54,'#1E1413');
for(let y=216;y<H;y++){const t=(y-216)/54;g.fillStyle=`rgba(0,0,0,${0.35*(1-t)})`;g.fillRect(0,y,W,1);}
for(let i=-12;i<=12;i++){const x0=240+i*18,x1=240+i*62;for(let y=216;y<H;y++){const t=(y-216)/54;P(x0+(x1-x0)*t,y,'#2C1E1C');}}
for(const y of [219,224,231,240,252,266])R(0,y,W,1,'#2C1E1C');
R(0,216,W,1,'#8A2A1A');R(0,217,W,1,'#3A1414');
for(let y=220;y<H;y+=2){const w=Math.round(10+(y-220)*0.35+Math.sin(y)*3);R(372-w,y,w*2,1,`rgba(210,40,36,${0.22-(y-220)*0.003})`);}
for(let i=0;i<40;i++)P(rnd()*W,222+rnd()*46,rnd()<0.5?'#FF8A2A':'#6E2A1A');

  return cvh;
}

/* ===================== EYE COMFORT: calmer arenas ===================== */
const CALM={0:{s:.84,c:.9,b:.93},1:{s:.74,c:.88,b:.95},2:{s:.9,c:.92,b:.97},3:{s:.6,c:.8,b:.9},4:{s:.8,c:.88,b:.92},5:{s:.88,c:.92,b:.96},6:{s:.72,c:.85,b:.88},7:{s:.66,c:.85,b:.9},8:{s:.84,c:.9,b:.95}};
function calmArena(cv,p){if(!cv||!p)return cv;const g=cv.getContext('2d');const d=g.getImageData(0,0,cv.width,cv.height);const a=d.data;
  for(let i=0;i<a.length;i+=4){const l=0.299*a[i]+0.587*a[i+1]+0.114*a[i+2];
    for(let k=0;k<3;k++){let v=l+(a[i+k]-l)*p.s;v=(v-96)*p.c+96;v*=p.b;if(v>215)v=215+(v-215)*0.5;a[i+k]=v<0?0:v>255?255:v;}a[i+3]=255;}
  g.putImageData(d,0,0);return cv;}
const COMFORT={on:(()=>{try{return localStorage.getItem('oni-comfort')==='on';}catch(e){return false;}})()};
function buildAll(){[buildSummit,buildTemple,buildYomi,buildColosseum,buildBridge,buildCastle,buildHall].forEach((fn,i)=>{const c=document.createElement('canvas');c.width=W;c.height=H;G=c.getContext('2d');fn();BG[i]=c;});G=ctx;try{BGHI[1]=buildTempleHi();}catch(e){}
  const HIB={0:'buildSummitHi',2:'buildYomiHi',3:'buildColosseumHi',4:'buildBridgeHi',5:'buildCastleHi',6:'buildHallHi',7:'buildLaunchpadHi',8:'buildHelipadHi'};
  for(const k in HIB){try{if(typeof window[HIB[k]]==='function')BGHI[k]=window[HIB[k]]();}catch(e){}}
  for(const k in BGHI){try{calmArena(BGHI[k],CALM[k]);}catch(e){}}
  if(!BG[7]){const c=document.createElement('canvas');c.width=W;c.height=H;const g2=c.getContext('2d');if(BGHI[7])g2.drawImage(BGHI[7],0,0,W,H);BG[7]=c;}}

/* ===================== FX ===================== */
const FX={sparks:[],pops:[],amb:[],aura:[],fin:null,shake:0,flash:0};
function sparks(x,y,n,cols){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,sp=0.8+Math.random()*2.4;FX.sparks.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-0.6,life:10+Math.random()*12,c:cols[i%cols.length]});}}
function pop(text,x,y,c){FX.pops.push({text,x,y,life:50,c});}
function updFx(mapI){
  for(const s of FX.sparks){s.x+=s.vx;s.y+=s.vy;s.vy+=0.12;s.life--;}FX.sparks=FX.sparks.filter(s=>s.life>0);
  for(const p of FX.pops){p.y-=0.35;p.life--;}FX.pops=FX.pops.filter(p=>p.life>0);
  const amb=MAPS[mapI].amb;
  if(Math.random()<(amb==='gold'?0.2:0.35)){
    if(amb==='spark')FX.amb.push({x:Math.random()*W,y:8+Math.random()*80,vx:0,vy:0.04,life:30+Math.random()*30,t:amb});
    else if(amb==='petal')FX.amb.push({x:-4+Math.random()*W*0.7,y:-4+Math.random()*60,vx:0.35+Math.random()*0.35,vy:0.18+Math.random()*0.2,life:260+Math.random()*120,t:amb});
    else if(amb==='fire')FX.amb.push({x:Math.random()*W,y:40+Math.random()*110,vx:(Math.random()-0.5)*0.3,vy:(Math.random()-0.5)*0.2,life:120+Math.random()*120,t:amb});
    else FX.amb.push({x:Math.random()*W,y:180,vx:(Math.random()-0.5)*0.3,vy:-0.3-Math.random()*0.5,life:160+Math.random()*120,t:amb});
  }
  for(const e of FX.amb){e.x+=e.vx+Math.sin(e.life*0.05)*0.15;e.y+=e.vy;e.life--;}FX.amb=FX.amb.filter(e=>e.life>0&&e.y>-4);if(FX.amb.length>160)FX.amb.splice(0,FX.amb.length-160);
  for(const a of FX.aura){a.y+=a.vy;a.x+=Math.sin(a.life*0.2)*0.2;a.life--;}FX.aura=FX.aura.filter(a=>a.life>0);
  if(FX.fin){FX.fin.t++;if(FX.fin.t>70)FX.fin=null;}
  if(COMFORT.on&&FX.shake>1.2)FX.shake=1.2;if(FX.shake>0)FX.shake*=0.85;if(FX.shake<0.3)FX.shake=0;if(FX.flash>0)FX.flash--;
}
function auraTick(m){for(const f of m.f){if(CH[f.ch].tier!==3||f.st==='ko')continue;if(Math.random()<0.45){const h=CH[f.ch].h;
  FX.aura.push({x:f.x+(Math.random()*2-1)*(CH[f.ch].w*GEO/2+5),y:f.y-Math.random()*h*GEO,vy:-0.35-Math.random()*0.4,life:26+Math.random()*16});}}}
function drawAura(){for(const a of FX.aura){G.globalAlpha=Math.min(1,a.life/20);px(a.x,a.y,a.life%10<5?'#FFB000':'#FFE08A');}G.globalAlpha=1;}
function drawFinisher(){const F=FX.fin;if(!F)return;const r=F.t*3.2;G.globalAlpha=Math.max(0,1-F.t/70);
  for(let a=0;a<6.28;a+=0.05){px(F.x+Math.cos(a)*r,F.y+Math.sin(a)*r*0.55,F.c);if(F.tier===3)px(F.x+Math.cos(a)*r*0.7,F.y+Math.sin(a)*r*0.4,'#FFE08A');}
  G.globalAlpha=1;if(F.t<60)txt(F.tier===3?'LEGENDARY FINISH':'FINISH!',160,146,F.tier===3?9:10,F.tier===3?'#FFD86A':'#F3E9E4','#1A0506');}
function drawAmb(mapI){
  for(const e of FX.amb){if(e.t!==MAPS[mapI].amb)continue;const a=Math.min(1,e.life/60);G.globalAlpha=a;
    const c=e.t==='spark'?(['#FFD27A','#FF5A4E','#BFFFF8','#FFFFFF'][Math.floor(e.x)%4]):e.t==='petal'?(e.life%20<10?'#FFB7D0':'#FF8FB8'):e.t==='fire'?(e.life%30<15?'#D8FF6A':'#6BD88A'):e.t==='wisp'?(e.life%40<20?'#2EC4B6':'#BFFFF8'):e.t==='gold'?'#FFB000':(e.life%40<20?'#FF6A00':'#FFB000');px(e.x,e.y,c);}
  G.globalAlpha=1;
  if(MAPS[mapI].id==='colosseum')for(let i=0;i<3;i++)if(Math.random()<0.5)px(Math.random()*W,34+Math.random()*90,'#FFFFFF');
}
function txt(s,x,y,size,fill,stroke,align){
  G.font=size+'px '+FONT;G.textAlign=align||'center';G.textBaseline='middle';
  if(stroke){G.fillStyle=stroke;const o=Math.max(1,Math.round(size/8));for(const [dx,dy] of [[-o,0],[o,0],[0,-o],[0,o],[-o,-o],[o,o],[-o,o],[o,-o],[0,o+1]])G.fillText(s,x+dx,y+dy);}
  G.fillStyle=fill;G.fillText(s,x,y);
}
const usd=c=>'$'+((c%100)?(c/100).toFixed(2):String(c/100));
function hud(m,me){
  const bar=(x,f,col,right)=>{rect(x-1,9,122,9,'#F3E9E4');rect(x,10,120,7,'#1A0506');const w=Math.round(120*Math.max(0,f.hp)/(f.mhp||CH[f.ch].hp));rect(right?x+120-w:x,10,w,7,col);rect(right?x+120-w:x,10,w,2,'rgba(255,255,255,.3)');};
  const P0=PAL[m.f[0].ch][palOf(m,0)],P1=PAL[m.f[1].ch][palOf(m,1)];
  bar(8,m.f[0],P0.main,false);bar(192,m.f[1],P1.main,true);
  for(let i=0;i<2;i++){const g=Math.min(100,m.f[i].guard||0);if(g>0){const w=Math.round(120*g/100);rect(i?312-w:8,18,w,2,g>70?'#FF6A00':'#FFE08A');}}
  const t30=CH[m.f[0].ch].tier===3,t31=CH[m.f[1].ch].tier===3;
  const dia=(dx,dy)=>{px(dx,dy-2,'#FFB000');rect(dx-1,dy-1,3,1,'#FFB000');rect(dx-2,dy,5,1,'#FFE08A');rect(dx-1,dy+1,3,1,'#FFB000');px(dx,dy+2,'#FFB000');};
  G.font='8px '+FONT;const n0=fname(m.f[0].ch,palOf(m,0),m.f[0].skin)+(me===0?' (YOU)':''),n1=(me===1?'(YOU) ':'')+fname(m.f[1].ch,palOf(m,1),m.f[1].skin);
  txt(n0,9,24,8,t30?'#FFC940':P0.name,'#1A0506','left');if(t30)dia(14+G.measureText(n0).width,24);
  txt(n1,311,24,8,t31?'#FFC940':P1.name,'#0A0506','right');if(t31)dia(306-G.measureText(n1).width,24);
  for(let i=0;i<((m.need||2)>5?0:(m.need||2));i++){disc(10+i*9,33,3,'#F3E9E4');disc(10+i*9,33,2,m.wins[0]>i?'#FFB000':'#1A0506');disc(310-i*9,33,3,'#F3E9E4');disc(310-i*9,33,2,m.wins[1]>i?'#FFB000':'#1A0506');}
  rect(146,6,28,20,'#1A0506');rect(147,7,26,18,'#2A0C0D');txt(m.mode==='training'?'--':String(Math.max(0,Math.ceil(m.timer/60))),160,17,10,'#FFB000');
  if(m.stake>0)txt('POT '+usd(m.stake*2),160,33,6,'#FFB000','#1A0506');
  const meter=(x,v,right)=>{rect(x-1,169,62,6,'#F3E9E4');rect(x,170,60,4,'#1A0506');const w=Math.round(60*v/100);rect(right?x+60-w:x,170,w,4,v>=50?'#FF6A00':'#6E0B10');rect(x+30,170,1,4,'#F3E9E4');};
  meter(8,m.f[0].meter,false);meter(252,m.f[1].meter,true);
  const lab=v=>v>=100?'SUPER':'CURSE',lc=v=>v>=100&&frameN%20<12?'#FFE08A':'#FF6A00';
  txt(lab(m.f[0].meter),74,172,6,lc(m.f[0].meter),'#1A0506','left');txt(lab(m.f[1].meter),246,172,6,lc(m.f[1].meter),'#1A0506','right');
}
const PORT={};
function portrait(kit,side,pal){if(pal==null)pal=side;const key=kit+side+'_'+pal;if(PORT[key])return PORT[key];
  const c=document.createElement('canvas');c.width=128;c.height=144;const g=c.getContext('2d');g.imageSmoothingEnabled=false;
  if(typeof hiDrawAny!=='function'){const old=G;G=g;NOSHADOW=true;drawFighter({ch:kit,x:64,y:140,face:side?-1:1,st:'idle',t:0,flash:0,air:false},0,pal,1);NOSHADOW=false;G=old;PORT[key]=c;return c;}
  const f={ch:kit,x:0,y:0,face:side?-1:1,st:'idle',t:0,flash:0,air:false,crouch:false,atk:'punch',skin:kit==='oni'?(pal===2?'kin':pal===3?'kongo':pal===4?'genesis':null):null};
  const buf=hiRender(f,0,pal,null);const dx=kit==='ryu'?(side?-18:18):kit==='saru'?(side?-8:8):0;
  g.drawImage(buf,HAX-64-dx,HAY-138,128,144,0,0,128,144);PORT[key]=c;return c;}
function drawVS(m,t){
  rect(0,0,W,H,'#6E0B10');
  G.fillStyle='#0E1A45';G.beginPath();G.moveTo(W,0);G.lineTo(W,H);G.lineTo(0,H);G.lineTo(W*0.62,0);G.closePath();G.fill();
  G.fillStyle='#FFB000';G.beginPath();G.moveTo(W*0.62,0);G.lineTo(W*0.62+4,0);G.lineTo(4,H);G.lineTo(0,H);G.closePath();G.fill();
  for(let i=0;i<14;i++){const y=(i*29+t*3)%H;rect(0,y,W*0.5-i*6,1,'rgba(255,106,0,.18)');}
  const e=Math.min(1,t/30),sl=Math.round((1-e)*120);G.imageSmoothingEnabled=false;
  const a=portrait(m.f[0].ch,0,palOf(m,0)),b=portrait(m.f[1].ch,1,palOf(m,1));
  G.drawImage(a,8-sl,0,128*1.1,144*1.1);G.drawImage(b,W-8-128*1.1+sl,H-144*1.1+4,128*1.1,144*1.1);
  txt(fname(m.f[0].ch,palOf(m,0)),62-sl,160,11,PAL[m.f[0].ch][palOf(m,0)].name,'#1A0506');txt(fname(m.f[1].ch,palOf(m,1)),W-70+sl,20,11,PAL[m.f[1].ch][palOf(m,1)].name,'#0A1030');
  txt(MAPS[m.map].name.toUpperCase(),160,172,6,'#F3E9E4','#1A0506');
  if(t>30){const k=t<40?1+(40-t)*0.08:1;txt('VS',160,92,Math.round(34*k),'#FFB000','#2A1300');}
}

/* ===================== AUDIO ===================== */
const AU={c:null,m:null,muted:false,musicOn:false,next:0,step:0,timer:null};
function auInit(){if(AU.c)return;try{AU.c=new (window.AudioContext||window.webkitAudioContext)();AU.m=AU.c.createGain();AU.m.gain.value=AU.muted?0:0.9;AU.m.connect(AU.c.destination);}catch(e){AU.c=null;}}
function tone(f,d,type,vol,when,slide){if(!AU.c||mode==='demo')return;const t=AU.c.currentTime+(when||0);const o=AU.c.createOscillator(),g=AU.c.createGain();
  o.type=type||'square';o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,slide),t+d);
  g.gain.setValueAtTime(vol||0.15,t);g.gain.exponentialRampToValueAtTime(0.0008,t+d);o.connect(g);g.connect(AU.m);o.start(t);o.stop(t+d+0.02);}
function noise(d,vol,freq,when){if(!AU.c||mode==='demo')return;const t=AU.c.currentTime+(when||0);const n=Math.floor(AU.c.sampleRate*d);const b=AU.c.createBuffer(1,n,AU.c.sampleRate);const a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=Math.random()*2-1;
  const s=AU.c.createBufferSource();s.buffer=b;const fl=AU.c.createBiquadFilter();fl.type='bandpass';fl.frequency.value=freq||1500;const g=AU.c.createGain();g.gain.setValueAtTime(vol||0.2,t);g.gain.exponentialRampToValueAtTime(0.001,t+d);s.connect(fl);fl.connect(g);g.connect(AU.m);s.start(t);}
const SFX={
  swing(h){if(h)noise(0.12,0.2,900);else{noise(0.1,0.22,3600);tone(2400,0.08,'sine',0.05,0,1200);}},
  hit(h){tone(h?95:130,0.14,'square',0.26,0,40);noise(0.12,0.35,h?600:1100);},
  block(){tone(1480,0.25,'sine',0.14);tone(2210,0.2,'sine',0.08);noise(0.05,0.2,4200);},
  special(kit){if(kit===1){noise(0.25,0.25,2500);tone(300,0.3,'square',0.12,0,1200);tone(1320,0.3,'sine',0.1,0.12);}
    else if(kit===2){tone(90,0.6,'sawtooth',0.26,0,45);noise(0.55,0.3,380);}
    else if(kit===3){tone(600,0.25,'triangle',0.14,0,2400);noise(0.2,0.15,5000);}
    else if(kit===4){noise(0.4,0.3,1200);tone(900,0.4,'sawtooth',0.1,0,200);}
    else if(kit===5){tone(300,0.12,'sine',0.2,0,600);noise(0.15,0.15,1800,0.05);}
    else if(kit===7){tone(55,0.8,'sawtooth',0.3,0,30);noise(0.7,0.35,300);}
    else if(kit===6){tone(440,0.6,'sine',0.12,0,220);tone(452,0.6,'sine',0.12,0,226);}
    else{tone(180,0.45,'sawtooth',0.18,0,60);noise(0.45,0.25,500);}},
  splash(){noise(0.2,0.3,1600);tone(220,0.2,'sine',0.2,0,90);},
  clash(){tone(1320,0.35,'sine',0.16);tone(1980,0.3,'sine',0.1);noise(0.1,0.3,3000);},
  jump(){noise(0.08,0.15,2000);tone(600,0.08,'triangle',0.08,0,1200);},
  taiko(){tone(70,0.35,'sine',0.4,0,45);noise(0.08,0.2,200);},
  fight(){tone(60,0.5,'sawtooth',0.26,0,35);noise(0.35,0.3,300);},
  ko(){tone(98,1.8,'sine',0.35);tone(147,1.4,'sine',0.18);tone(196,1.0,'sine',0.08);noise(0.3,0.3,400);},
  win(){[69,72,76,81,84].forEach((n,i)=>tone(440*Math.pow(2,(n-69)/12),i===4?0.6:0.16,'triangle',0.2,i*0.12));},
  coin(){tone(1320,0.08,'triangle',0.18);tone(1760,0.3,'triangle',0.16,0.08);},
  select(){tone(1320,0.05,'triangle',0.14);}
};
const LEAD=[69,71,72,76,77,76,72,71,69,72,76,81,77,76,72,76,64,69,71,72,71,69,64,65,69,71,72,76,72,71,69,64];
const BASS=[45,45,52,45,41,41,48,41,43,43,50,43,40,40,47,40];
function musicStart(){if(!AU.c||AU.musicOn)return;AU.musicOn=true;AU.next=AU.c.currentTime+0.05;AU.step=0;
  AU.timer=setInterval(()=>{const sp=60/132/4;while(AU.next<AU.c.currentTime+0.12){const w=AU.next-AU.c.currentTime;
    if(AU.step%2===0)tone(440*Math.pow(2,(LEAD[(AU.step>>1)%32]-69)/12),sp*1.7,'square',0.03,w);
    if(AU.step%4===0)tone(440*Math.pow(2,(BASS[(AU.step>>2)%16]-69)/12),sp*3.5,'triangle',0.08,w);
    if(AU.step%8===0||AU.step%16===14)tone(62,0.25,'sine',0.2,w,40);
    if(AU.step%8===4)noise(0.05,0.06,2500,w);
    AU.step++;AU.next+=sp;}},25);}
function musicStop(){AU.musicOn=false;if(AU.timer)clearInterval(AU.timer);AU.timer=null;}
function setMute(v){AU.muted=v;if(AU.m)AU.m.gain.value=v?0:0.9;document.getElementById('mute').textContent=v?'SOUND OFF':'SOUND ON';try{localStorage.setItem('oni-mute',v?'1':'0');}catch(e){}}

/* ===================== INPUT ===================== */
const held=new Set(),pressed=new Set();
const KEYMAP={KeyA:'L',ArrowLeft:'L',KeyD:'R',ArrowRight:'R',KeyW:'U',ArrowUp:'U',Space:'U',KeyS:'D',ArrowDown:'D',KeyJ:'P',KeyK:'K',KeyL:'S',KeyI:'T',KeyZ:'P',KeyX:'K',KeyC:'S',KeyV:'T'};
addEventListener('keydown',e=>{const k=KEYMAP[e.code];if(!k)return;const tag=document.activeElement&&document.activeElement.tagName;if(tag==='INPUT'||tag==='BUTTON'&&document.body.classList.contains('menu'))return;e.preventDefault();auInit();if(!held.has(k))pressed.add(k);held.add(k);});
addEventListener('keyup',e=>{const k=KEYMAP[e.code];if(k)held.delete(k);});
addEventListener('keydown',e=>{if(e.key!=='Escape')return;
  if(!document.body.classList.contains('menu')&&M){e.preventDefault();if(mode==='training'){$('tr-exit').click();}else $('quit').click();return;}
  const open=[...document.querySelectorAll('.panel.on')].map(p=>p.id);
  if(open.length&&!open.includes('p-title')&&!open.includes('p-end')&&mode==='title'){e.preventDefault();show('p-title');}});
addEventListener('blur',()=>held.clear());
const touchHeld=new Map();
document.querySelectorAll('.pb').forEach(el=>{
  const k=el.dataset.k;
  const down=e=>{e.preventDefault();auInit();try{el.setPointerCapture(e.pointerId);}catch(_){}touchHeld.set(e.pointerId+':'+k,k);if(!held.has('t'+k))pressed.add(k);held.add('t'+k);el.classList.add('down');};
  const up=e=>{touchHeld.delete(e.pointerId+':'+k);if(![...touchHeld.values()].includes(k)){held.delete('t'+k);el.classList.remove('down');}};
  el.addEventListener('pointerdown',down);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);el.addEventListener('lostpointercapture',up);
});
if(matchMedia('(pointer:coarse)').matches||('ontouchstart' in window))document.body.classList.add('touch');
const PRESS_COUNT={P:0,K:0,S:0,U:0,T:0,L:0,R:0};
function sampleInput(){
  let b=0;const has=k=>held.has(k)||held.has('t'+k)||pressed.has(k);
  if(has('L'))b|=IN.L;if(has('R'))b|=IN.R;if(has('U'))b|=IN.U;if(has('D'))b|=IN.D;if(has('P'))b|=IN.P;if(has('K'))b|=IN.K;if(has('S'))b|=IN.S;if(has('T'))b|=IN.T;
  for(const k of ['P','K','S','U','T','L','R'])if(pressed.has(k))PRESS_COUNT[k]++;
  pressed.clear();return b;
}

/* ===================== APP STATE + SELECT ===================== */
let mode='title',M=null,cpuMem={hold:0,bits:0,gap:false},level=0,frameN=0,lastEv=0,endShown=false,contT=0,cpuKit='ryu';
const $=id=>document.getElementById(id);
function show(id){if(id==='p-title'&&typeof VIL!=='undefined'&&VIL.active){id=null;mode='village';M=null;const tb=document.getElementById('trbar');if(tb)tb.hidden=true;const q=document.getElementById('quit');if(q)q.hidden=true;}
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('on',p.id===id));document.body.classList.toggle('menu',!!id);document.body.classList.toggle('landing',id==='p-landing');}
function streak(){try{return +localStorage.getItem('oni-streak')||0;}catch(e){return 0;}}
function setStreak(v){try{localStorage.setItem('oni-streak',String(v));}catch(e){}}
function refreshTitle(){const s=streak();const rl=(typeof rankLine==='function')?rankLine():'';$('streak').textContent=(rl?rl+' ':'')+(s>0?`CPU streak: ${s}.`:(rl?'':'Seven fighters, four arenas. Win two rounds to take the match.'));$('quit').hidden=true;}
function toTitle(){mode='title';M=null;const tb=document.getElementById('trbar');if(tb)tb.hidden=true;show('p-title');refreshTitle();musicStop();netLeave();}

const FIGHTERS=[
  {kit:'oni',tag:'Balanced. The fighter everyone starts with.',st:[3,3,3],mv:['Curse Flame','A fireball that crosses the whole arena.']},
  {kit:'saru',tag:'Staff master. The fastest fighter in the roster.',st:[5,2,2],mv:['Staff Strike','The staff shoots out across the arena. Also jumps twice.']},
  {kit:'kappa',tag:'Shell-backed guardian. The hardest to knock out.',st:[2,3,5],mv:['Counter Stance','Get hit during the stance and Genbu strikes back.']},
  {kit:'kitsune',tag:'Fox trickster wrapped in blue foxfire.',st:[5,3,2],mv:['Fox Blink','Teleports behind the opponent in a flash.']},
  {kit:'tengu',tag:'Crow warrior of the mountains.',st:[3,3,4],mv:['Sky Dive','Leaps and dives from the sky. Hold jump to glide.']},
  {kit:'ryu',tag:'Green dragon, guardian of the east. Slow and heavy.',st:[1,5,5],mv:['Dragon Fire','A huge fire blast at short range.']},
  {kit:'onryo',tag:'A vengeful shadow. Hard to catch, easy to break.',st:[4,3,2],mv:['Phase','Turns untouchable and walks through attacks.']}];
const TIER=[{n:'Free',label:'STARTER',c:'#C9A9A2',price:0},{n:'Tier 1',label:'RARE',c:'#C8CCD8',price:2000,perk:'A fighter with a unique move.'},{n:'Tier 2',label:'EPIC',c:'#D08CFF',price:8900,perk:'Unique move plus its own K.O. finisher.'},
  {n:'Tier 3',label:'LEGENDARY',c:'#FFB000',price:20000,perk:'Legendary aura, gold name, badge, legendary finisher and access to the Oni Colosseum.'}];
function tierBadge(t){return `<span class="tbadge t${t}">${TIER[t].label}</span>`;}
const OWN=new Set(['oni']);
const owns=k=>OWN.has(k);const hasT3=()=>[...OWN].some(k=>CH[k].tier===3);
function loadOwned(){try{JSON.parse(localStorage.getItem('oni-owned')||'[]').forEach(k=>{if(CH[k])OWN.add(k);});}catch(e){}}
function saveOwned(){try{localStorage.setItem('oni-owned',JSON.stringify([...OWN]));}catch(e){}
  if(typeof DB!=='undefined'&&DB.db&&DB.me)DB.db.collection('data/users/'+DB.me).doc('inv').set({owned:[...OWN],ts:Date.now()}).catch(()=>{});}
async function syncOwned(){if(!DB.db||!DB.me)return;try{const d=await DB.db.collection('data/users/'+DB.me).doc('inv').get();
  if(d.exists){let add=false;(d.data().owned||[]).forEach(k=>{if(CH[k]&&!OWN.has(k)){OWN.add(k);add=true;}});if(add){try{localStorage.setItem('oni-owned',JSON.stringify([...OWN]));}catch(e){}}}}catch(e){}}
loadOwned();
const SEL={kit:'oni',map:1,ctx:'cpu',fmt:'bo3',opal:0,low:300};
const LOWSTAKES=[[0,'Free','Half season points. Up to 5 airdrop points a day.'],[50,'$0.50','Smallest real stake. Full points.'],[300,'$3','Full points.']];
try{const v=+localStorage.getItem('oni-color');SEL.opal=v===1||v===4?v:0;}catch(e){}
const myPal=k=>k==='oni'?SEL.opal:0;
const FMTS={bo3:{need:2,hpMul:1,label:'Best of 3',desc:'First to win 2 rounds.'},ko:{need:1,hpMul:1,label:'Knockout',desc:'One round. No second chances.'}};
function fdef(k){return FIGHTERS.find(f=>f.kit===k);}
function barsHTML(st){return '<div class="bars">'+['Speed','Power','Health'].map((lb,i)=>`<span>${lb}</span><span class="bar"><i style="width:${st[i]*20}%"></i></span>`).join('')+'</div>';}
/* ---------- live fighter showcase ---------- */
const SHOWS=new Map();
function showcase(cv,kit,map,pal){if(!cv)return;const s=SHOWS.get(cv)||{t:0};if(s.kit!==kit){s.t=0;}s.kit=kit;s.map=map;s.pal=pal==null?myPal(kit):pal;SHOWS.set(cv,s);}
function godLayer(kind,fr,k,w,h,fx,fy,face){const L=document.createElement('canvas');L.width=w;L.height=h;const lg=L.getContext('2d');lg.imageSmoothingEnabled=false;
  lg.setTransform(face||1,0,0,1,fx,fy);drawGodClean(lg,kind,fr,k);lg.setTransform(1,0,0,1,0,0);
  const O=document.createElement('canvas');O.width=w;O.height=h;const og=O.getContext('2d');for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]])og.drawImage(L,dx,dy);
  og.globalCompositeOperation='source-in';og.fillStyle='rgba(8,3,10,.95)';og.fillRect(0,0,w,h);og.globalCompositeOperation='source-over';og.drawImage(L,0,0);return O;}
function godPortrait(kind){const key='god'+kind;if(PORT[key])return PORT[key];const c=document.createElement('canvas');c.width=128;c.height=144;
  c.getContext('2d').drawImage(godLayer(kind,0,1.0,128,144,64,140),0,0);PORT[key]=c;return c;}
function drawShow(cv,s){
  const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.imageSmoothingEnabled=false;const map=s.map|0;
  if(String(s.kit).startsWith('god:')){const kind=s.kit.slice(4);if(BGHI[2])g.drawImage(BGHI[2],-90,-99);g.fillStyle='rgba(20,10,40,.35)';g.fillRect(0,0,cv.width,cv.height);
    g.drawImage(godLayer(kind,s.t,1.45,300,165,150,138,kind==='fujin'?-1:1),0,0);return;}
  if(BGHI[map])g.drawImage(BGHI[map],-90,-99);else g.drawImage(BG[map],0,0,320,180,-90,-99,480,270);
  const kit=s.kit,c=CH[kit],sp=c.special;
  const seq=[['idle',60],['walk',48],['punch',c.punch.s+c.punch.a+c.punch.r+8],['kick',c.kick.s+c.kick.a+c.kick.r+8],['special',Math.max(sp.len||40,56)],['block',34],['win',64]];
  const total=seq.reduce((a,x)=>a+x[1],0);let tt=s.t%total,st='idle',lt=0;for(const [n,d] of seq){if(tt<d){st=n;lt=tt;break;}tt-=d;}
  const f={ch:kit,x:140,y:GROUND,face:1,st,t:lt,flash:0,air:false,phase:0,crouch:false,atk:st==='kick'?'kick':'punch',skin:kit==='oni'?(s.pal===2?'kin':s.pal===3?'kongo':s.pal===4?'genesis':null):null};
  if(st==='walk')f.x=140+(lt<24?lt:48-lt)*0.9;
  if(st==='special'){
    if(sp.type==='dive'){const up=Math.min(lt,sp.at);f.y=GROUND-up*2.6;if(lt>sp.at){f.y=Math.min(GROUND,GROUND-sp.at*2.6+(lt-sp.at)*3.4);f.x=140+(lt-sp.at)*3;}f.air=f.y<GROUND-0.5;if(!f.air&&lt>sp.at)f.st='idle';}
    if(sp.type==='blink'&&lt>=sp.at){f.x=196;f.face=-1;}
    if(sp.type==='phase'&&lt>=sp.at)f.phase=30;
  }
  const buf=hiRender(f,s.t,s.pal|0,RIM[map]||null);
  if(f.phase>0)g.globalAlpha=0.45;g.drawImage(buf,Math.round(f.x*1.5-HAX-90),Math.round(f.y*1.5-HAY-99));g.globalAlpha=1;
  const old=G;G=g;g.setTransform(1.5,0,0,1.5,-90,-99);
  if(st==='special'&&sp.type==='proj'&&lt>=sp.at){const dx=14*GEO+(lt-sp.at)*sp.vx;if(f.x+dx<270)drawProj({x:f.x+dx,y:GROUND-sp.y*GEO,vx:1,owner:0,r:sp.r*GEO,kit},s.t,s.pal|0);}
  if(st==='special'&&sp.type==='blink'&&lt>=sp.at&&lt<sp.at+8)for(let k=0;k<8;k++){px(140+Math.sin(k*2+lt)*8,GROUND-18+Math.cos(k*3)*10,'#7FE7FF');}
  if(CH[kit].tier===3&&s.t%3===0)for(let k=0;k<3;k++)px(f.x+(Math.random()*2-1)*16,f.y-Math.random()*CH[kit].h*GEO,Math.random()<0.5?'#FFB000':'#FFE08A');
  g.setTransform(1,0,0,1,0,0);G=old;
}
function tickShowcases(){for(const [cv,s] of SHOWS){if(!cv.isConnected||cv.offsetParent===null)continue;drawShow(cv,s);s.t++;}}
function fiHTML(kit,opts){
  const fd=fdef(kit),t=CH[kit].tier;
  let h=`${tierBadge(t)}<h3>${esc(CH[kit].name)}</h3><div>${esc(fd.tag)}</div><div><span class="mv">${esc(fd.mv[0])}:</span> ${esc(fd.mv[1])}</div>`+barsHTML(fd.st);
  if(opts&&opts.note)h+=`<div class="own">${opts.note}</div>`;
  return h;
}
function portraitEl2(kit,pal){const c=document.createElement('canvas');c.width=128;c.height=144;c.getContext('2d').drawImage(portrait(kit,0,pal==null?myPal(kit):pal),0,0);return c;}

/* ===================== FIGHTER POSTERS ===================== */
const POSTER={oni:['鬼','#8E1015','#2A0508'],saru:['猿','#C98A2E','#3A2208'],kappa:['亀','#3A8A4A','#0E2A14'],kitsune:['狐','#E07A30','#3A1408'],tengu:['烏','#3A3A5A','#0E0E1C'],ryu:['龍','#1F8A4A','#062A14'],onryo:['霊','#6A5A9A','#120E24'],enma:['閻','#B3161F','#1A0204']};
const POSTERS={};
function posterEl(kit,pal){if(typeof hiDrawAny!=='function')return portraitEl2(kit,pal);const key=kit+'_'+pal;let src=POSTERS[key];
  if(!src){const PW=240,PH=330;src=document.createElement('canvas');src.width=PW;src.height=PH;const g=src.getContext('2d');g.imageSmoothingEnabled=false;const [kj,c1,c2]=POSTER[kit]||POSTER.oni;
    const grd=g.createLinearGradient(0,0,0,PH);grd.addColorStop(0,c1);grd.addColorStop(1,c2);g.fillStyle=grd;g.fillRect(0,0,PW,PH);
    g.save();g.globalAlpha=0.12;g.fillStyle='#FFFFFF';for(let i=0;i<11;i++){g.beginPath();g.moveTo(PW/2,190);const a=-Math.PI/2+(i-5)*0.28;g.lineTo(PW/2+Math.cos(a-0.06)*420,190+Math.sin(a-0.06)*420);g.lineTo(PW/2+Math.cos(a+0.06)*420,190+Math.sin(a+0.06)*420);g.closePath();g.fill();}g.restore();
    g.save();g.globalAlpha=0.18;g.fillStyle='#FFFFFF';g.font='bold 170px serif';g.textAlign='center';g.textBaseline='middle';g.fillText(kj,PW/2,120);g.restore();
    const rg=g.createRadialGradient(PW/2,210,10,PW/2,210,120);rg.addColorStop(0,'rgba(255,240,210,.38)');rg.addColorStop(1,'rgba(255,240,210,0)');g.fillStyle=rg;g.fillRect(0,0,PW,PH);
    const f={ch:kit,x:0,y:0,face:1,st:'idle',t:0,flash:0,air:false,crouch:false,atk:'punch',skin:kit==='oni'?(pal===2?'kin':pal===3?'kongo':pal===4?'genesis':null):null};
    const buf=hiRender(f,0,pal,null);const dx=kit==='ryu'?14:kit==='saru'?6:kit==='enma'?0:0;const big=kit==='enma'||kit==='ryu';
    if(big)g.drawImage(buf,HAX-60-dx,HAY-150,120,150,0,30,240,300);else g.drawImage(buf,HAX-60-dx,HAY-142,120,148,0,26,240,296);
    const sh=g.createLinearGradient(0,PH-80,0,PH);sh.addColorStop(0,'rgba(0,0,0,0)');sh.addColorStop(1,'rgba(0,0,0,.8)');g.fillStyle=sh;g.fillRect(0,PH-80,PW,80);
    g.strokeStyle='rgba(255,224,138,.85)';g.lineWidth=3;g.strokeRect(1.5,1.5,PW-3,PH-3);POSTERS[key]=src;}
  const c=document.createElement('canvas');c.width=src.width;c.height=src.height;c.className='poster';c.getContext('2d').drawImage(src,0,0);return c;}
function buildFighterCards(){
  const row=$('fighters');row.innerHTML='';
  FIGHTERS.forEach(fd=>{
    const locked=!owns(fd.kit),t=CH[fd.kit].tier;
    const b=document.createElement('button');b.className='fc'+(locked?' locked':'');b.type='button';b.setAttribute('aria-pressed',SEL.kit===fd.kit?'true':'false');
    b.setAttribute('aria-label',CH[fd.kit].name+', '+TIER[t].label+(locked?', locked':''));
    const n=document.createElement('div');n.textContent=CH[fd.kit].name;
    const tl=document.createElement('div');tl.className='tl'+(t===3?' t3':'');tl.textContent=locked?'Locked':TIER[t].label;
    b.classList.add('pfc');b.append(posterEl(fd.kit,myPal(fd.kit)),n,tl);
    b.onclick=()=>{if(locked&&SEL.ctx==='online'){openStore(fd.kit);return;}SEL.kit=fd.kit;SFX.select();buildFighterCards();};
    row.appendChild(b);
  });
  const locked=!owns(SEL.kit);
  $('sel-fi').innerHTML=fiHTML(SEL.kit,{note:locked?(SEL.ctx==='cpu'?'Locked. Free to try against the CPU.':'Unlock this fighter in the market to play online.'):''});
  if(SEL.kit==='oni'){const row=document.createElement('div');row.className='colors';row.innerHTML='<span>Color</span>';
    [['Aka, red',0,'#D7262E'],['Ao, blue',1,'#2F6FE0']].concat(isFounder()?[['Genesis',4,'#FF3B30']]:[]).forEach(([lb,v,c])=>{const b=document.createElement('button');b.type='button';b.className='cpick';b.setAttribute('aria-pressed',SEL.opal===v?'true':'false');
      b.innerHTML=`<i style="background:${c}"></i>${lb}`;b.onclick=()=>{SEL.opal=v;try{localStorage.setItem('oni-color',String(v));}catch(e){}SFX.select();buildFighterCards();};row.appendChild(b);});
    $('sel-fi').appendChild(row);}
  showcase($('sel-cv'),SEL.kit,SEL.map);
}
const STORE={sel:'ryu',tab:'fighters',myth:null};
function renderStoreInfo(){
  if(STORE.myth==='raijin'||STORE.myth==='fujin'){const r=STORE.myth==='raijin';const el=$('st-fi');
    el.innerHTML=`<span class="tbadge t6">GOD TIER</span><h3>${r?'Raijin':'Fujin'}</h3><div>${r?'God of thunder. A ring of taiko drums on his back and a diamond helmet with a lightning crest.':'God of wind. The wind bag over his shoulders and a diamond helmet with a crescent crest.'} 45% taller than any fighter.</div>`+
      `<div class="price">$1,199</div><div>Limited supply, coming before launch. To buy one: Samurai rank or higher, 50 ranked matches and an account at least 14 days old.</div><div class="own">Coming soon</div>`;
    showcase($('st-cv'),'god:'+STORE.myth,0,0);return;}
  if(STORE.myth==='boss'){const el=$('st-fi');
    el.innerHTML=`<span class="tbadge t5">PVE FINAL BOSS</span><h3>Shuten-doji</h3><div>The king of all oni. Brutally hard, but beatable.</div><div class="price">$1-2 a try</div>`+
      `<div>Every try fills the Curse Bag. When someone beats him, the whole bag buys $ONI and is locked in liquidity forever, and he comes back 10 levels stronger. The winner gets the Oni Slayer title and a trophy.</div><div class="own">Coming soon</div>`;
    showcase($('st-cv'),'god:raijin',0,0);return;}
  if(STORE.myth==='genesis'){const el=$('st-fi');const no=DB.me?founderNo(DB.me):0;
    el.innerHTML=`<span class="tbadge t5">FOUNDER</span><h3>Genesis Oni</h3><div>The first oni. Obsidian armor split by glowing red cracks, crimson horns and a crimson blade, with embers rising around him.</div>`+
      `<div class="price">Only 200</div><div>Given to the first 200 accounts, each one numbered. Unlike Mythic skins, the Genesis Oni will be tradeable on the marketplace.</div>`+
      `<div class="own">${isFounder()?'You are a Founder'+(no?' #'+no:'')+'. Pick Genesis in the ONI color choice.':foundersLeft()+' of 200 left. Create your account to claim one.'}</div>`;
    const a=document.createElement('div');a.className='acts';if(!isFounder()&&foundersLeft()>0){const b=document.createElement('button');b.className='arc gold';b.type='button';b.textContent='Create account';b.onclick=()=>openProfile();a.appendChild(b);}
    el.appendChild(a);showcase($('st-cv'),'oni',1,4);return;}
  if(STORE.myth){const kin=STORE.myth==='kin';const el=$('st-fi');
    el.innerHTML=`<span class="tbadge t4">MYTHIC</span><h3>${kin?'Kin-Oni':'Kongo-Oni'}</h3>`+
      `<div>${kin?'The gold Oni. Lacquered black armor, a golden mask and a golden blade, wrapped in drifting gold dust.':'The diamond Oni. White crystal armor, a crystal mask and a cyan blade that glitters like diamond.'}</div>`+
      `<div class="price">${kin?'Places 11 to 50':'Top 10'}</div><div>Earned by the best players of every 2-week season. Never sold, never traded, yours forever with the season on it.</div>`+
      `<div class="own">Same Oni, same strength. Pure status.</div>`;
    const a=document.createElement('div');a.className='acts';const b=document.createElement('button');b.className='arc alt';b.type='button';b.textContent='See the season ranking';
    b.onclick=()=>{SFX.select();DB.tab='lords';show('p-board');renderBoard();};a.appendChild(b);el.appendChild(a);
    showcase($('st-cv'),'oni',1,kin?2:3);return;}
  const k=STORE.sel,t=CH[k].tier;const el=$('st-fi');el.innerHTML=fiHTML(k);
  if(t>0)el.insertAdjacentHTML('beforeend',`<div class="price">${usd(TIER[t].price)} <small style="font-size:.5em;color:var(--mute)">in COOK</small></div><div>${esc(TIER[t].perk)}</div>`);
  const a=document.createElement('div');a.className='acts';
  if(owns(k)){a.insertAdjacentHTML('beforeend',`<span class="own">${t?'Owned':'Free for everyone'}</span>`);}
  else{const b=document.createElement('button');b.className='arc gold';b.type='button';b.textContent='Unlock '+CH[k].name;b.onclick=()=>{OWN.add(k);saveOwned();SFX.coin();SFX.win();renderStore();};a.appendChild(b);}
  const tr=document.createElement('button');tr.className='arc alt';tr.type='button';tr.textContent='Try vs CPU';tr.onclick=()=>{SEL.kit=k;openSelect('cpu');};a.appendChild(tr);
  el.appendChild(a);showcase($('st-cv'),k,[1,0,2,3][t]);
}
function renderStore(){
  document.querySelectorAll('#p-store [data-stab]').forEach(x=>x.setAttribute('aria-pressed',x.dataset.stab===STORE.tab?'true':'false'));
  renderStoreInfo();const body=$('store-body');body.innerHTML='';
  if(STORE.tab==='fighters'){
    for(let t=0;t<=3;t++){
      const sec=document.createElement('div');sec.className='mk-tier';
      sec.innerHTML=`<div class="mk-rib"><span>${tierBadge(t)} ${t?TIER[t].n+', '+usd(TIER[t].price):'Starter'}</span><small>${t?esc(TIER[t].perk):'Free for every player.'}</small></div>`;
      const grid=document.createElement('div');grid.className='mk-grid';
      FIGHTERS.filter(fd=>CH[fd.kit].tier===t).forEach(fd=>{
        const b=document.createElement('button');b.type='button';b.className='mk';b.setAttribute('aria-pressed',!STORE.myth&&STORE.sel===fd.kit?'true':'false');
        const info=document.createElement('div');info.innerHTML=`${esc(CH[fd.kit].name)}<small>${esc(fd.mv[0])}</small>`+(owns(fd.kit)?`<span class="o">${t?'Owned':'Free'}</span>`:`<span class="p">${usd(TIER[t].price)}</span>`);
        b.append(portraitEl2(fd.kit),info);b.onclick=()=>{STORE.sel=fd.kit;STORE.myth=null;SFX.select();renderStore();$('p-store').scrollTop=0;};grid.appendChild(b);});
      sec.appendChild(grid);body.appendChild(sec);
    }
    const gs=document.createElement('div');gs.className='mk-tier';
    gs.innerHTML=`<div class="mk-rib"><span><span class="tbadge t6">GOD TIER</span> Coming soon</span><small>45% taller, diamond helmets, limited. $1,199 each.</small></div>`;
    const gg=document.createElement('div');gg.className='mk-grid';
    [['raijin','Raijin','God of thunder'],['fujin','Fujin','God of wind']].forEach(([id,n,d])=>{const b=document.createElement('button');b.type='button';b.className='mk';b.setAttribute('aria-pressed',STORE.myth===id?'true':'false');
      const pc=document.createElement('canvas');pc.width=128;pc.height=144;pc.getContext('2d').drawImage(godPortrait(id),0,0);b.append(pc);
      const i2=document.createElement('div');i2.innerHTML=`${n}<small>${d}</small><span class="p">$1,199, soon</span>`;b.appendChild(i2);b.onclick=()=>{STORE.myth=id;SFX.select();renderStore();$('p-store').scrollTop=0;};gg.appendChild(b);});
    const bb=document.createElement('button');bb.type='button';bb.className='mk';bb.setAttribute('aria-pressed',STORE.myth==='boss'?'true':'false');
    bb.innerHTML=`<div>PvE Final Boss<small>Shuten-doji. $1-2 a try.</small><span class="p">Soon</span></div>`;bb.onclick=()=>{STORE.myth='boss';SFX.select();renderStore();$('p-store').scrollTop=0;};gg.appendChild(bb);
    gs.appendChild(gg);body.appendChild(gs);
    const fs=document.createElement('div');fs.className='mk-tier';
    fs.innerHTML=`<div class="mk-rib"><span><span class="tbadge t5">FOUNDER</span> The first 200 accounts</span><small>Numbered #1 to #200. Tradeable on the marketplace when it opens.</small></div>`;
    const fg=document.createElement('div');fg.className='mk-grid';const fb=document.createElement('button');fb.type='button';fb.className='mk';fb.setAttribute('aria-pressed',STORE.myth==='genesis'?'true':'false');fb.append(portraitEl2('oni',4));
    const fi=document.createElement('div');fi.innerHTML=`Genesis Oni<small>Only 200 will ever exist.</small><span class="p">${isFounder()?'Yours':foundersLeft()+' of 200 left'}</span>`;fb.appendChild(fi);
    fb.onclick=()=>{STORE.myth='genesis';SFX.select();renderStore();$('p-store').scrollTop=0;};fg.appendChild(fb);fs.appendChild(fg);body.appendChild(fs);
    const sec=document.createElement('div');sec.className='mk-tier';
    sec.innerHTML=`<div class="mk-rib"><span><span class="tbadge t4">MYTHIC</span> Earned, never sold</span><small>Awarded when each season ends. Yours forever, with the season on it.</small></div>`;
    const grid=document.createElement('div');grid.className='mk-grid';
    [['Kongo-Oni',3,'Diamond Oni. The top 10 of the season.'],['Kin-Oni',2,'Gold Oni. Places 11 to 50 of the season.']].forEach(([n,pal,d])=>{
      const b=document.createElement('button');b.type='button';b.className='mk';b.append(portraitEl2('oni',pal));
      const info=document.createElement('div');info.innerHTML=`${n}<small>${d}</small><span class="p">Earned, never sold</span>`;b.appendChild(info);
      b.setAttribute('aria-pressed',STORE.myth===(pal===2?'kin':'kongo')?'true':'false');b.onclick=()=>{STORE.myth=pal===2?'kin':'kongo';SFX.select();renderStore();$('p-store').scrollTop=0;};grid.appendChild(b);});
    sec.appendChild(grid);body.appendChild(sec);
  } else {
    const Y='<span class="y">Yes</span>',N='<span class="n">No</span>';
    const rows=[['Fighters','Aka and Ao Oni','Kaze, Genbu','Kira, Hayate','Seiryu, Kage'],['Price','Free',usd(2000),usd(8900),usd(20000)],
      ['Unique special move',Y,Y,Y,Y],['Same strength as every fighter',Y,Y,Y,Y],['Own K.O. finisher',N,N,Y,Y],['Legendary gold aura',N,N,N,Y],
      ['Gold name and badge',N,N,N,Y],['Oni Colosseum, no-limit stakes',N,N,N,Y]];
    let h='<table class="cmp"><thead><tr><th></th>'+[0,1,2,3].map(t=>`<th>${tierBadge(t)}</th>`).join('')+'</tr></thead><tbody>';
    for(const r of rows)h+='<tr>'+r.map(c=>`<td>${c}</td>`).join('')+'</tr>';
    body.innerHTML=h+'</tbody></table><div class="lb-empty">Mythic skins, Kin-Oni and Kongo-Oni, cannot be bought. They go to the top 50 players of every season.</div>';
  }
  const n=[...OWN].length;
  $('st-me').innerHTML=`<span>Your collection: <b>${n} of ${FIGHTERS.length}</b> fighters</span><span>Oni Colosseum: <b>${hasT3()?'unlocked':'needs a Legendary fighter'}</b></span>`;
}
function openStore(focus){STORE.sel=focus||STORE.sel;STORE.myth=null;STORE.tab='fighters';renderStore();show('p-store');$('p-store').scrollTop=0;}
document.querySelectorAll('#p-store [data-stab]').forEach(b=>b.onclick=()=>{STORE.tab=b.dataset.stab;SFX.select();renderStore();});
function stakeCents(){if(SEL.map===0)return SEL.low;const m=MAPS[SEL.map];if(m.stake)return m.stake;let v=Math.round(+$('amt').value||0);v=Math.max(50,Math.min(500,v));return v*100;}
const MAPTHUMB={};
function mapThumb(i){if(MAPTHUMB[i])return MAPTHUMB[i];const c=document.createElement('canvas');c.width=160;c.height=90;const g=c.getContext('2d');g.imageSmoothingEnabled=!!BGHI[i];g.drawImage(BGHI[i]||BG[i],0,0,160,90);MAPTHUMB[i]=c;return c;}
function buildMaps(){
  const row=$('maps');row.innerHTML='';if(SEL.ctx==='online'&&!MAPS[SEL.map].stake&&!hasT3())SEL.map=2;
  MAPS.forEach((mp,i)=>{
    if(mp.tourney)return;
    const vip=!mp.stake,lock=vip&&SEL.ctx==='online'&&!hasT3();
    const b=document.createElement('button');b.type='button';b.className='ar'+(vip?' vip':'')+(lock?' lock':'');b.setAttribute('aria-pressed',SEL.map===i?'true':'false');
    const c=document.createElement('canvas');c.width=160;c.height=90;c.getContext('2d').drawImage(mapThumb(i),0,0);
    const al=document.createElement('div');al.className='al';
    const right=SEL.ctx==='online'?(i===0?'Free to $3':mp.id==='launchpad'?'$100 LAUNCH BONUS':mp.stake?usd(mp.stake):(lock?'Legendary only':'No limit')):(vip?'VIP arena':'Free');
    al.innerHTML=`<span>${esc(mp.name)}</span><b>${right}</b>`;b.append(c,al);
    b.setAttribute('aria-label',mp.name+', '+right);
    b.onclick=()=>{if(lock){$('sel-note').innerHTML='The Oni Colosseum is the no-limit arena for owners of a <strong>Legendary</strong> fighter: Seiryu or Kage.';SFX.block();return;}SEL.map=i;SFX.select();buildMaps();renderMoney();showcase($('sel-cv'),SEL.kit,SEL.map);};
    row.appendChild(b);
  });
  $('nolimit').hidden=!(SEL.ctx==='online'&&!MAPS[SEL.map].stake);
  const ls=$('lowstake');ls.hidden=!(SEL.ctx==='online'&&SEL.map===0);ls.innerHTML='';
  if(!ls.hidden)LOWSTAKES.forEach(([c,l,d])=>{const b=document.createElement('button');b.type='button';b.className='fm';b.setAttribute('aria-pressed',SEL.low===c?'true':'false');
    b.innerHTML=`<b>${l}</b><small>${d}</small>`;b.onclick=()=>{SEL.low=c;SFX.select();buildMaps();renderMoney();};ls.appendChild(b);});
  showcase($('sel-cv'),SEL.kit,SEL.map);
}
function buildFormats(){const row=$('fmts');row.innerHTML='';
  Object.entries(FMTS).forEach(([k,f])=>{const b=document.createElement('button');b.type='button';b.className='fm';b.setAttribute('aria-pressed',SEL.fmt===k?'true':'false');
    b.innerHTML=`${f.label}<small>${f.desc}</small>`;b.onclick=()=>{SEL.fmt=k;SFX.select();buildFormats();renderMoney();};row.appendChild(b);});}
function renderMoney(){
  const el=$('sel-money');$('sel-clock').innerHTML=`${FMTS[SEL.fmt].label}<b>${SEL.ctx==='online'?'Winner takes the pot':'No stake'}</b>`;
  if(SEL.ctx==='cpu'){el.innerHTML=`<div class="m-row"><span>Format</span><b>${FMTS[SEL.fmt].label}</b></div><div class="m-row"><span>Stake</span><b>Free</b></div><div class="m-foot">Practice against the CPU. It picks a random fighter.</div>`;return;}
  const st=stakeCents(),p=payout(st);
  if(MAPS[SEL.map].id==='launchpad'&&SEL.ctx==='online'){el.insertAdjacentHTML('afterbegin','');}
  if(st===0){el.innerHTML=`<div class="m-row"><span>Format</span><b>${FMTS[SEL.fmt].label}</b></div><div class="m-row big"><span>Stake</span><b>Free</b></div><div class="m-foot">Counts for rank. Half season points. 1 airdrop point per opponent a day, up to 5.</div>`;return;}
  el.innerHTML=`<div class="m-row"><span>Format</span><b>${FMTS[SEL.fmt].label}</b></div><div class="m-row"><span>Your stake</span><b>${usd(st)}</b></div><div class="m-row big"><span>Winner takes</span><b>${usd(p.win)}</b></div><div class="m-foot">Pot ${usd(p.pot)}, 5% game fee. Demo: no money moves.</div>`;
}
function selNote(){renderMoney();}
$('amt').addEventListener('input',renderMoney);
function openSelect(ctxName){
  SEL.ctx=ctxName;
  $('sel-kicker').textContent=ctxName==='online'?'ONI online':'ONI practice';
  $('sel-title').textContent=ctxName==='online'?'1v1 Match':'Practice';
  $('arena-ttl').textContent=ctxName==='online'?'Arena and stake':'Arena';
  buildFighterCards();buildFormats();buildMaps();renderMoney();$('sel-note').textContent=NET.avail===false&&ctxName==='online'?'Online play works when this page is opened on claude.ai and shared with your opponent.':'';
  const a=$('sel-actions');a.innerHTML='';
  const btn=(label,cls,fn,parent)=>{const b=document.createElement('button');b.className='arc '+(cls||'');b.type='button';b.textContent=label;b.onclick=fn;(parent||a).appendChild(b);return b;};
  if(ctxName==='cpu'){btn('Fight','gold',startCPU);btn('Arcade mode','',()=>{if(!owns(SEL.kit)){openStore(SEL.kit);return;}startArcade();});btn('Training mode','',startTraining);btn('Tutorial','alt',startTutorial);}
  else{
    const c=btn('Create match','gold',createMatch);c.disabled=!NET.avail;
    const jr=document.createElement('div');jr.className='joinrow';jr.innerHTML='<span class="or">Or join a friend</span>';a.appendChild(jr);
    const inp=document.createElement('input');inp.className='codein';inp.id='codein';inp.maxLength=4;inp.placeholder='CODE';inp.setAttribute('aria-label','Match code to join');inp.autocomplete='off';jr.appendChild(inp);
    const j=btn('Join','',joinMatch,jr);j.disabled=!NET.avail;inp.addEventListener('keydown',e=>{if(e.key==='Enter')joinMatch();});
  }
  show('p-select');$('p-select').scrollTop=0;
}
$('sel-back').onclick=()=>{SFX.select();show('p-title');};
function startCPU(){vilPublish(true,true);auInit();SFX.select();level=Math.min(3,streak());cpuKit=FIGHTERS[Math.floor(Math.random()*3)].kit;mode='cpu';
  M=mkMatch('cpu',0,[SEL.kit,cpuKit],SEL.map,Object.assign({pal:[myPal(SEL.kit),cpuKit==='oni'?1-myPal(SEL.kit):0]},FMTS[SEL.fmt]));cpuMem={hold:0,bits:0,gap:false};lastEv=0;endShown=false;show(null);$('quit').hidden=false;musicStart();}
$('b-cpu').onclick=()=>{auInit();SFX.select();openSelect('cpu');};
$('b-online').onclick=()=>{auInit();SFX.select();openSelect('online');};
$('b-help').onclick=openControls;
$('b-profile').onclick=openProfile;
$('b-tourney').onclick=openTourney;
$('b-boss').onclick=openBoss;
$('bs-back').onclick=()=>{SFX.select();show('p-title');};
$('c-back').onclick=()=>{SFX.select();show('p-title');};
$('b-training').onclick=()=>{auInit();SFX.select();openSelect('cpu');$('sel-note').innerHTML='Pick your fighter and arena, then press <strong>Training mode</strong>.';};
$('tn-back').onclick=()=>{SFX.select();show('p-title');};
$('br-back').onclick=()=>{SFX.select();TN=null;mode='title';openTourney();};
$('pf-back').onclick=()=>{SFX.select();PROFILE.draft=null;show('p-title');};
$('b-cauldron').onclick=()=>{auInit();SFX.select();openCauldrons();};
$('b-store').onclick=()=>{auInit();SFX.select();openStore();};
$('b-back4').onclick=()=>{SFX.select();show('p-title');};
$('b-board').onclick=()=>{auInit();SFX.select();show('p-board');renderBoard();};
$('b-back3').onclick=()=>{SFX.select();show('p-title');};
$('b-back2').onclick=()=>{SFX.select();show(mode==='title'?'p-title':null);};
$('b-cancel').onclick=()=>toTitle();
$('quit').onclick=()=>{if(mode==='tourney'&&M){M.winner=1;M.wins=[0,M.need||2];tourneyEnd();return;}toTitle();};
$('mute').onclick=()=>{auInit();setMute(!AU.muted);};
try{if(localStorage.getItem('oni-mute')==='1')setMute(true);}catch(e){}

function endPanel(){
  endShown=true;const me=mode==='guest'?1:0;const won=M.winner===me;const row=$('end-row');row.innerHTML='';
  bump('games');misProgress('play3');if(won){bump('wins');misProgress('win2');}if(M.perfect&&won){bump('perfect');misProgress('perfect');}
  if(mode==='host'||mode==='guest')misProgress('online');if(mode==='boss')misProgress('enma');
  const btn=(label,cls,fn)=>{const b=document.createElement('button');b.className='arc '+(cls||'');b.textContent=label;b.onclick=fn;row.appendChild(b);return b;};
  const link=(label,href)=>{const a=document.createElement('a');a.className='arc';a.href=href;a.target='_blank';a.rel='noopener';a.textContent=label;row.appendChild(a);};
  const share='https://x.com/intent/post?text='+encodeURIComponent((won?`I just won a 1v1 as ${fname(M.f[me].ch,palOf(M,me))} in ONI`:'I lost a 1v1 in ONI. Rematch soon')+'. The curse you choose. theonicurse.xyz');
  if(mode==='boss'){
    const L=TR.bossL||1;
    if(won){recordBossKill(L);$('end-note').innerHTML=`<strong>Enma falls.</strong> He will rise again at level ${L+1}, for everyone.`;SFX.win();}
    else $('end-note').innerHTML=`Enma wins at level ${L}. His club is longer than yours: get close, block low, and punish.`;
    btn(won?'Face him again':'Try again','gold',startBoss);btn('Enma page','',()=>{mode='title';M=null;musicStop();openBoss();});btn('Menu','alt',toTitle);
  } else if(mode==='tourney'){
    const fin=TN&&TN.cur;$('end-note').textContent=won?'You advance.':'You are out of this round.';
    btn('Back to the bracket','gold',tourneyEnd);
  } else if(mode==='cpu'&&ARC.on){
    if(won){misProgress('arcade');ARC.i++;if(ARC.i>=ARC.list.length){ARC.on=false;bump('arcade');$('end-note').innerHTML='<strong>Arcade cleared!</strong> Every fighter and Enma, beaten.';SFX.win();btn('Menu','gold',toTitle);}
      else{$('end-note').textContent=`Opponent ${ARC.i} of ${ARC.list.length} down. Next: ${CH[ARC.list[ARC.i]].name}.`;btn('Next opponent','gold',arcadeMatch);btn('Quit Arcade','alt',()=>{ARC.on=false;toTitle();});}}
    else{$('end-note').textContent=`Arcade: lost to ${CH[ARC.list[ARC.i]].name} (${ARC.i+1} of ${ARC.list.length}).`;btn('Continue','gold',arcadeMatch);btn('Quit Arcade','alt',()=>{ARC.on=false;toTitle();});}
  } else if(mode==='cpu'){
    if(won){setStreak(streak()+1);recordPractice(streak(),M.f[0].ch);$('end-note').textContent=`Win streak: ${streak()}. The CPU fights harder next match.`;
      btn('Fight again','gold',startCPU);btn('Change fighter','',()=>openSelect('cpu'));btn('Menu','alt',toTitle);link('Post on X',share);}
    else{setStreak(0);contT=600;$('end-note').textContent='Continue?';btn('Continue','gold',startCPU);btn('Change fighter','',()=>openSelect('cpu'));btn('Menu','alt',toTitle);}
  } else if(mode==='host'||mode==='guest'){
    const p=payout(M.stake);
    $('end-note').innerHTML=(M.stake>0?(won?`You won <strong>${usd(p.win)}</strong> (demo).`:`You lost ${usd(M.stake)} (demo).`):(won?'You won the 1v1.':'You lost the 1v1.'))+
      (M.stake>0?`<br>This match added ${usd(p.season)} to the Season Cauldron and ${usd(p.airdrop)} to the Curse Cauldron. You got 1 airdrop point.`:'')+'<span id="rank-delta"></span>';updateDelta();
    if(won)SFX.coin();
    const rb=btn('Rematch, same stake','gold',()=>{NET.ready=true;rb.disabled=true;rb.textContent='Waiting for opponent';});
    btn('Leave','alt',toTitle);link('Post on X',share);
  } else {$('end-note').textContent='Match over.';btn('Leave','alt',toTitle);}
  if(mode!=='boss'&&mode!=='training'){const kb=document.createElement('button');kb.className='arc';kb.textContent='Share K.O. card';kb.onclick=shareKO;row.appendChild(kb);}
  checkAch();show('p-end');
}

/* ===================== ONLINE (room presence) ===================== */
const NET={lobby:null,avail:null,room:null,role:null,code:null,peers:[],pc:{P:0,K:0,S:0,U:0},lastSeq:-1,prev:null,cur:null,curT:0,ready:false,matchId:null,joinTimer:null,stake:0,map:1,kit:'oni'};
async function netInit(){try{if(!window.claude||!window.claude.use){NET.avail=false;return;}const r=await window.claude.use('room');NET.lobby=r;NET.avail=!!r;if(r)r.onPeers(ch=>{VIL.peers=ch.peers;},()=>{});}catch(e){NET.avail=false;}
  if($('p-select').classList.contains('on')&&SEL.ctx==='online')openSelect('online');}
function genCode(){const a='ABCDEFGHJKMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<4;i++)s+=a[Math.floor(Math.random()*a.length)];return s;}
async function netJoin(code,asHost){
  NET.code=code;NET.role=asHost?'host':'pending';NET.lastSeq=-1;NET.cur=null;NET.prev=null;NET.ready=false;
  try{NET.room=await NET.lobby.join('oni-'+code.toLowerCase());}catch(e){$('sel-note').textContent='Could not open the match. Try again in a moment.';return false;}
  NET.room.onPeers(ch=>{NET.peers=ch.peers;onPeers();},()=>netLost('The connection to the match ended.'));
  NET.room.presence(asHost?{r:'h',s:null,sk:NET.stake,mp:NET.map,fm:NET.fmt||'bo3',ck:KITS.indexOf(NET.kit),op:SEL.opal,t3:hasT3()?1:0}:{r:'x'});
  return true;
}
function netLeave(){if(NET.room){try{NET.room.leave();}catch(e){}}NET.room=null;NET.role=null;NET.peers=[];clearTimeout(NET.joinTimer);}
function netLost(msg){toTitle();openSelect('online');$('sel-note').textContent=msg;}
function findPeer(r){return NET.peers.find(p=>!p.isMe&&p.presence&&p.presence.r===r);}
function onPeers(){
  if(NET.role==='pending'){
    const h=findPeer('h');if(!h)return;clearTimeout(NET.joinTimer);
    if(findPeer('g')||findPeer('gp')){NET.role='spec';mode='spectate';NET.room.presence({r:'s'});show(null);$('quit').hidden=false;musicStart();lastEv=0;endShown=false;return;}
    NET.role='review';NET.stake=h.presence.sk|0;NET.map=h.presence.mp|0;NET.fmt=FMTS[h.presence.fm]?h.presence.fm:'bo3';const hk=KITS[h.presence.ck|0]||'oni';
    NET.room.presence({r:'gp',ck:KITS.indexOf(NET.kit),t3:hasT3()?1:0});const p=payout(NET.stake);
    if(!MAPS[NET.map].stake&&!hasT3()){$('stake-note').innerHTML='This match is in the <strong>Oni Colosseum</strong>, the no-limit arena for Legendary fighter owners. Unlock Seiryu or Kage to enter.';$('b-accept').hidden=true;show('p-stake');return;}
    $('b-accept').hidden=false;
    $('stake-note').innerHTML=`Arena: <strong>${MAPS[NET.map].name}</strong>. Format: <strong>${FMTS[NET.fmt].label}</strong>. Your opponent plays ${fname(hk,0)}, you play ${fname(NET.kit,1)}.<br>`+
      (NET.stake>0?`Stake <strong>${usd(NET.stake)}</strong> each. Pot ${usd(p.pot)}. Winner gets <strong>${usd(p.win)}</strong> after the 5% fee.<br>Demo: no money moves in this version.`:'Friendly match, no stake.');
    show('p-stake');return;
  }
  if(NET.role==='host'){
    const g=findPeer('g');
    if(!g&&mode==='hostwait')$('wait-note').textContent=findPeer('gp')?'Your opponent is reviewing the stake.':`${MAPS[NET.map].name}, ${usd(NET.stake)} each. Send this code to your opponent.`;
    if(g&&mode==='hostwait'&&!MAPS[NET.map].stake&&!g.presence.t3)return;
    if(g&&mode==='hostwait'){const gk=KITS[g.presence.ck|0]||'oni';NET.guestBy=g.by||null;NET.guestT3=g.presence.t3?1:0;snapshotBefore();mode='host';NET.gpal=g.presence.op|0;M=mkMatch('online',NET.stake,[NET.kit,gk],NET.map,Object.assign({pal:[myPal(NET.kit),NET.gpal]},FMTS[NET.fmt||'bo3']));
      const c=g.presence.c||[0,0,0,0,0,0,0];NET.pc={P:c[0],K:c[1],S:c[2],U:c[3],T:c[4]|0,L:c[5]|0,R:c[6]|0};lastEv=0;endShown=false;show(null);$('quit').hidden=false;musicStart();}
    if(!g&&mode==='host'){mode='hostwait';M=null;show('p-wait');$('wait-note').textContent='Your opponent left. In the real version, leaving forfeits the pot. Waiting for a new opponent.';musicStop();}
  }
  if((NET.role==='guest'||NET.role==='spec'||NET.role==='review')&&!findPeer('h'))netLost('The host left the match.');
}
$('b-accept').onclick=()=>{SFX.coin();NET.role='guest';mode='guest';NET.room.presence({r:'g',op:SEL.opal,ck:KITS.indexOf(NET.kit),t3:hasT3()?1:0,i:0,c:[0,0,0,0],rd:0});show(null);$('quit').hidden=false;musicStart();lastEv=0;endShown=false;};
$('b-decline').onclick=()=>toTitle();
async function createMatch(codeArg){if(!owns(SEL.kit)){openStore(SEL.kit);return;}if(!MAPS[SEL.map].stake&&!hasT3())return;SFX.select();NET.fmt=SEL.fmt;NET.stake=stakeCents();NET.map=SEL.map;NET.kit=SEL.kit;const code=(typeof codeArg==='string'&&codeArg)?codeArg:genCode();$('mycode').textContent=code;
  $('wait-note').textContent=`${MAPS[NET.map].name}, ${usd(NET.stake)} each. Send this code to your opponent.`;show('p-wait');mode='hostwait';await netJoin(code,true);}
async function joinMatch(){SFX.select();const code=($('codein').value||'').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');
  if(code.length!==4){$('sel-note').textContent='Enter the 4-character code from your opponent.';return;}
  if(!owns(SEL.kit)){openStore(SEL.kit);return;}
  NET.kit=SEL.kit;$('sel-note').textContent='Joining match '+code+'...';
  if(await netJoin(code,false)){NET.joinTimer=setTimeout(()=>{if(NET.role==='pending'){netLeave();$('sel-note').textContent='No match found with code '+code+'. Check the code and that the host is still waiting.';}},6000);}}
function hostTick(){
  const g=findPeer('g');let gb=0;
  if(g&&g.presence){const p=g.presence;const c=p.c||[0,0,0,0,0,0,0];gb=(p.i|0)&(IN.L|IN.R|IN.U|IN.D);
    const keys=['P','K','S','U','T','L','R'],bitsK=[IN.P,IN.K,IN.S,IN.U,IN.T,0,0];
    NET.dq=NET.dq||[];
    keys.forEach((k,ix)=>{const v=c[ix]|0,d=v-(NET.pc[k]|0);if(d>0){if(bitsK[ix])gb|=bitsK[ix];
      if(k==='L'||k==='R'){const bit=k==='L'?IN.L:IN.R;for(let n=0;n<Math.min(d,3);n++)NET.dq.push([bit,1],[bit,1],[bit,0]);}}NET.pc[k]=v;});
    if(NET.dq.length){const [bit,val]=NET.dq.shift();gb=(gb&~bit)|(val?bit:0);}
    if(M.scene==='matchEnd'&&NET.ready&&p.rd===1&&M.sceneT>90){M=mkMatch('online',NET.stake,M.kits,NET.map,Object.assign({pal:[myPal(NET.kit),NET.gpal|0]},FMTS[NET.fmt||'bo3']));snapshotBefore();NET.guestBy=g.by||NET.guestBy;NET.ready=false;lastEv=0;endShown=false;show(null);musicStart();}
  }
  return gb;
}
let pubT=0;
function hostPublish(){const now=performance.now();if(now-pubT<30)return;pubT=now;try{NET.room.presence({r:'h',s:pack(M),sk:NET.stake,mp:NET.map,fm:NET.fmt||'bo3',ck:KITS.indexOf(NET.kit),rd:NET.ready?1:0});}catch(e){}}
function guestTick(bits){
  if(NET.role==='guest'){try{NET.room.presence({r:'g',op:SEL.opal,ck:KITS.indexOf(NET.kit),t3:hasT3()?1:0,i:bits,c:[PRESS_COUNT.P,PRESS_COUNT.K,PRESS_COUNT.S,PRESS_COUNT.U,PRESS_COUNT.T,PRESS_COUNT.L,PRESS_COUNT.R],rd:NET.ready?1:0});}catch(e){}}
  const h=findPeer('h');if(!h||!h.presence||!h.presence.s)return;
  const s=h.presence.s;if(s.q===NET.lastSeq)return;NET.lastSeq=s.q;
  NET.prev=NET.cur;NET.cur=unpack(s);NET.curT=performance.now();
  if(NET.matchId!==NET.cur.id){NET.matchId=NET.cur.id;snapshotBefore();NET.ready=false;endShown=false;lastEv=0;show(null);musicStart();}
  M=withSkins(NET.cur);
}
function interp(){
  if(!NET.cur||!NET.prev)return NET.cur;const k=Math.min(1,(performance.now()-NET.curT)/33);const o=NET.cur;
  return Object.assign({},o,{f:o.f.map((f,i)=>{const p=NET.prev.f[i];if(!p||Math.abs(f.x-p.x)>30)return f;return Object.assign({},f,{x:p.x+(f.x-p.x)*k,y:p.y+(f.y-p.y)*k});})});
}


/* ===================== RANKING + SEASON (db) ===================== */
const SEASON_START=Date.UTC(2026,8,28),SEASON_LEN=14*86400000;
const SEASON=(()=>{const n=Math.max(1,Math.floor((Date.now()-SEASON_START)/SEASON_LEN)+1);return{n,start:SEASON_START+(n-1)*SEASON_LEN,ends:SEASON_START+n*SEASON_LEN};})();
const RANKS=[{n:'Ashigaru',min:0,c:'#A8A8B0',d:[0,975,1025]},{n:'Ronin',min:1050,c:'#6FA3C8',d:[1050,1085,1120]},{n:'Samurai',min:1150,c:'#E23B3B',d:[1150,1200,1250]},
  {n:'Daimyo',min:1300,c:'#B06CE0',d:[1300,1350,1400]},{n:'Shogun',min:1450,c:'#FFB000',d:[1450,1500,1550]},{n:'Oni Lord',min:Infinity,c:'#FF5A3C',lord:true}];
const DIV=['III','II','I'];const LORDS=50;
const TIER_MULT=[1,2,3,4,1,1,1,4,1];
const BRACKETS=[{from:1,to:1,pct:15},{from:2,to:2,pct:10},{from:3,to:3,pct:7},{from:4,to:4,pct:5},{from:5,to:5,pct:4},
  {from:6,to:10,pct:2.5},{from:11,to:25,pct:1.2},{from:26,to:50,pct:0.6},{from:51,to:100,pct:0.27}];
const ELIG={games:5,opps:3};
function sharePct(r){const b=BRACKETS.find(x=>r>=x.from&&r<=x.to);return b?b.pct:0;}
function paidPlaces(eligible){return Math.min(100,eligible,Math.max(3,Math.floor(eligible*0.3)));}
function assignPrizes(board){
  const el=board.list.filter(p=>p.games>=ELIG.games&&Object.keys(p.opp).length>=ELIG.opps);
  const places=paidPlaces(el.length);let sum=0;for(let r=1;r<=places;r++)sum+=sharePct(r);
  board.eligible=el.length;board.places=places;
  for(const p of board.list){p.elig=false;p.prank=0;p.prize=0;}
  el.forEach((p,i)=>{p.elig=true;if(i<places){p.prank=i+1;p.prize=sum?Math.floor(board.pool*sharePct(i+1)/sum):0;}});
}
const DB={db:null,user:null,me:null,matches:[],practice:[],board:null,names:{},asked:new Set(),state:'loading',tab:'season'};
function rankOf(r){let k=RANKS[0];for(const x of RANKS)if(!x.lord&&r>=x.min)k=x;return k;}
function divOf(r){const k=rankOf(r);let d=0;k.d.forEach((t,i)=>{if(r>=t)d=i;});return d;}
function rankName(r,lord){return lord?'Oni Lord':rankOf(r).n+' '+DIV[divOf(r)];}
function nextRank(r){const k=rankOf(r),d=divOf(r);if(d<2)return{n:k.n+' '+DIV[d+1],min:k.d[d+1]};const nx=RANKS[RANKS.indexOf(k)+1];return nx&&!nx.lord?{n:nx.n+' III',min:nx.min}:null;}
/* pixel emblems, drawn once and cached as images */
const EMB={};
function emblem(ti,div,size){const key=ti+'_'+div+'_'+(size||24);if(EMB[key])return EMB[key];
  const c=document.createElement('canvas');c.width=24;c.height=24;const g=c.getContext('2d');const old=G;G=g;const R=RANKS[ti],col=R.c;
  const dark='#1A0B0C';
  // frame: diamond crest
  for(let y=0;y<20;y++){const w=y<10?y+1:20-y;rect(12-w,1+y,w*2,1,dark);}
  for(let y=1;y<19;y++){const w=(y<10?y+1:20-y)-1;if(w>0){rect(12-w,1+y,1,1,col);rect(11+w,1+y,1,1,col);}}
  rect(11,1,2,1,col);rect(11,20,2,1,col);
  // icon per rank
  if(ti===0){rect(7,11,10,2,'#8A8A94');rect(9,9,6,2,'#A8A8B0');rect(11,7,2,2,'#C8C8D0');rect(7,13,10,1,'#5A5A64');}
  else if(ti===1){rect(5,11,14,2,'#C8A060');rect(8,9,8,2,'#D8B070');rect(11,8,2,1,'#E8C888');for(let k=0;k<9;k++)px(7+k,15-Math.floor(k/3),'#DDE3EE');}
  else if(ti===2){rect(8,10,8,5,'#3A3A46');rect(7,13,10,2,'#2A2A34');rect(9,9,6,1,'#5A5A6A');px(8,7,col);px(9,8,col);px(15,7,col);px(14,8,col);rect(11,8,2,2,'#FFB000');}
  else if(ti===3){rect(11,13,2,4,'#6A3A1A');for(let y=0;y<6;y++){const w=6-Math.abs(y-2)*1;rect(12-w,7+y,w*2,1,y%2?col:'#E8D0FF');}}
  else if(ti===4){rect(8,11,8,5,'#C88A00');rect(7,14,10,2,'#8A5A00');rect(9,10,6,1,'#FFD86A');for(const [x,y] of [[6,6],[8,5],[16,5],[18,6]])px(x,y,'#FFD86A');rect(10,6,4,4,'#FFB000');px(11,7,'#FFF2B0');}
  else{for(let k=0;k<6;k++){px(6+k*2,4+(k%2),'#FF6A00');px(7+k*2,3+(k%2),'#FFB000');}
    rect(8,8,8,8,'#C1121F');rect(8,8,8,2,'#FF5A4E');px(8,6,'#EAD9B0');px(8,7,'#EAD9B0');px(15,6,'#EAD9B0');px(15,7,'#EAD9B0');rect(9,11,2,2,'#FFB000');rect(13,11,2,2,'#FFB000');rect(10,14,4,1,'#2A0505');px(10,15,'#FFFFFF');px(13,15,'#FFFFFF');}
  // division pips (III = 1, II = 2, I = 3)
  if(!R.lord){const n=div+1;for(let k=0;k<n;k++)rect(12-n*2+k*4+1,21,2,2,col);}
  G=old;EMB[key]=c.toDataURL();return EMB[key];}

const ACT={perDay:3,step:0.05,days:7,freeTickets:5};
function actMult(p,day){const n=p.ad.filter(d=>d<=day&&d>day-ACT.days).length;return 1+ACT.step*n;}
function computeBoard(matches){
  const P=new Map();const get=id=>{if(!P.has(id))P.set(id,{id,rating:1000,games:0,w:0,l:0,pts:0,streak:0,best:0,kits:{},vs:{},opp:{},pnl:0,vol:0,lord:0,dc:{},ad:[],tk:{},fk:{}});return P.get(id);};
  let pool=0,vol=0,count=0,drop=0;const wk0=lastDrop();const tix={};
  for(const m of matches){
    if(!m||!m.a||!m.b||m.a===m.b||(m.w!==0&&m.w!==1))continue;count++;
    const A=get(m.a),B=get(m.b);const win=m.w===0?A:B,lose=m.w===0?B:A;
    const ew=1/(1+Math.pow(10,(lose.rating-win.rating)/400));
    win.rating+=Math.round((win.games<10?40:24)*(1-ew));lose.rating-=Math.round((lose.games<10?40:24)*(1-ew));
    win.games++;lose.games++;win.w++;lose.l++;win.opp[lose.id]=1;lose.opp[win.id]=1;
    let topId=null,topR=-1;for(const q of P.values())if(q.games>=3&&q.rating>topR){topR=q.rating;topId=q.id;}
    const day=Math.floor((m.ts||0)/86400000);for(const q of [win,lose]){q.dc[day]=(q.dc[day]||0)+1;if(q.dc[day]===ACT.perDay)q.ad.push(day);}
    const free=!(m.stake>0)?0.5:1;
    const mult=TIER_MULT[m.map|0]||1;const n=(win.vs[lose.id]=(win.vs[lose.id]||0)+1);
    win.pts+=Math.round(10*mult*(n===1?1:n===2?0.5:n===3?0.25:0.1)*free*actMult(win,day));lose.pts+=Math.round(mult*free*actMult(lose,day));if(lose.id===topId&&win.id!==topId){win.pts+=25;win.bounties=(win.bounties||0)+1;}
    win.streak++;win.best=Math.max(win.best,win.streak);lose.streak=0;
    A.lg=m.ta?1:0;B.lg=m.tb?1:0;
    const wk=m.w===0?m.ka:m.kb,lk=m.w===0?m.kb:m.ka;win.kits[wk]=(win.kits[wk]||0)+1;lose.kits[lk]=(lose.kits[lk]||0)+1;
    if(m.stake>0){const p=payout(m.stake);pool+=p.season;vol+=p.pot;if(m.ts>=wk0)drop+=p.airdrop;win.pnl+=p.win-m.stake;lose.pnl-=m.stake;win.vol+=m.stake;lose.vol+=m.stake;}
    if(m.ts>=wk0){for(const [q,o] of [[A,B],[B,A]]){const key=day+':'+o.id;if(q.tk[key])continue;
      if(!(m.stake>0)){q.fk[day]=(q.fk[day]||0)+1;if(q.fk[day]>ACT.freeTickets)continue;}q.tk[key]=1;tix[q.id]=(tix[q.id]||0)+1;}}
  }
  const list=[...P.values()].sort((x,y)=>y.pts-x.pts||y.rating-x.rating);
  const today=Math.floor(Date.now()/86400000);for(const p of list){p.act=actMult(p,today);p.actDays=p.ad.filter(d=>d<=today&&d>today-ACT.days).length;}
  list.forEach((p,i)=>p.pos=i+1);
  const lords=[...P.values()].filter(p=>p.games>=ELIG.games).sort((a,b)=>b.rating-a.rating||b.w-a.w).slice(0,LORDS);lords.forEach((p,i)=>p.lord=i+1);
  const board={list,map:P,pool,vol,count,drop,tix,lords};assignPrizes(board);return board;
}
async function dbInit(){
  try{
    if(!window.claude||!window.claude.use){DB.state='off';onBoard();return;}
    const [db,user]=await Promise.all([window.claude.use('db'),window.claude.use('user')]);
    DB.db=db;DB.user=user;if(user){try{DB.me=await user.id();}catch(e){}}
    if(db&&DB.me)syncOwned();
    if(!db){DB.state='off';onBoard();return;}
    db.collection('matches').where('season','==',SEASON.n).orderBy('ts','asc').limit(1000).onSnapshot(s=>{
      DB.matches=s.docs.map(d=>d.data());DB.board=computeBoard(DB.matches);DB.state='ok';onBoard();},e=>{DB.state='err';DB.err=e&&e.code;onBoard();});
    db.collection('profiles').limit(1000).onSnapshot(s=>{const o={};s.docs.forEach(d=>{o[d.id]=d.data();});DB.profiles=o;refreshProfileBtn();onBoard();if(typeof renderLanding==='function'&&$('p-landing').classList.contains('on'))renderLanding();},()=>{});
    db.collection('boss').limit(1000).onSnapshot(s=>{DB.boss=s.docs.map(d=>Object.assign({id:d.id},d.data()));if($('p-boss').classList.contains('on'))renderBoss();},()=>{});
    db.collection('tickets').limit(1000).onSnapshot(s=>{DB.tickets=s.docs.map(d=>Object.assign({id:d.id},d.data()));onBoard();},()=>{});
    db.collection('practice').orderBy('best','desc').limit(50).onSnapshot(s=>{
      DB.practice=s.docs.map(d=>Object.assign({id:d.id},d.data()));onBoard();},()=>{});
  }catch(e){DB.state='off';onBoard();}
}
function nameOf(id){const pp=DB.profiles&&DB.profiles[id];if(pp&&pp.name)return pp.name;const n=DB.names[id];if(n)return n;return id===DB.me?'You':'Player '+String(id).slice(-4);}
async function resolveNames(ids){
  if(!DB.user)return;const need=ids.filter(id=>id&&!DB.asked.has(id));if(!need.length)return;need.forEach(id=>DB.asked.add(id));
  try{const ps=await DB.user.profiles(need);let changed=false;for(const id of need){const n=ps&&ps[id]&&ps[id].name;if(n){DB.names[id]=n;changed=true;}}if(changed)onBoard();}catch(e){}
}
function myEntry(){return DB.board&&DB.me?DB.board.map.get(DB.me):null;}
function daysLeft(){return Math.max(0,Math.ceil((SEASON.ends-Date.now())/86400000));}
function rankChip(r,lord){const k=lord?RANKS[5]:rankOf(r),ti=RANKS.indexOf(k),d=lord?0:divOf(r);return `<span class="rk${lord?' lord':''}" style="--rc:${k.c}"><img class="emb" src="${emblem(ti,d)}" alt="">${lord?'Oni Lord #'+lord:k.n+' '+DIV[d]}</span>`;}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function favKit(p){let best='oni',n=-1;for(const [k,c] of Object.entries(p.kits||{}))if(c>n&&CH[k]){best=k;n=c;}return best;}
function portraitEl(kit,cls){const c=document.createElement('canvas');c.width=128;c.height=144;c.getContext('2d').drawImage(portrait(kit,0),0,0);if(cls)c.className=cls;return c;}
function renderBoard(){
  setTimeout(()=>wirePlayerLinks($('bd-body')),0);
  const b=DB.board;const me=myEntry();$('bd-title').textContent='Season '+SEASON.n;
  $('bd-clock').innerHTML=`Ends in<b>${fmtLeft(SEASON.ends-Date.now())}</b>every season lasts 2 weeks`;
  $('bd-stats').innerHTML=`<div class="lb-stat s"><b>${usd(b?b.pool:0)}</b>Season Cauldron, the top 100 split it</div>`+
    `<div class="lb-stat"><b class="w">${me?'#'+me.pos:'-'}</b>${me?me.pts+' points'+(me.prize?', '+usd(me.prize)+' prize now':''):'Your spot. Win a ranked 1v1 to join.'}</div>`;
  document.querySelectorAll('#p-board [data-tab]').forEach(x=>x.setAttribute('aria-pressed',x.dataset.tab===DB.tab?'true':'false'));
  const body=$('bd-body');body.innerHTML='';$('bd-me').innerHTML='';
  const empty=t=>{body.innerHTML=`<div class="lb-empty">${t}</div>`;};
  if(DB.tab!=='rules'){
    if(DB.state==='off')return empty('The leaderboard works when this page is opened on claude.ai.');
    if(DB.state==='loading')return empty('Loading the season...');
    if(DB.state==='err')return empty('The leaderboard could not load. Reopen the page to retry.');
  }
  const who=p=>`<button type="button" class="plink" data-pid="${esc(p.id)}">${esc(nameOf(p.id))}</button>${founderNo(p.id)?' <span class="tbadge t5 mini">F</span>':''}`;
  const table=(head,rows)=>{const t=document.createElement('table');t.className='lbt clean';t.innerHTML='<thead><tr>'+head.map(([h,c])=>`<th class="${c||''}">${h}</th>`).join('')+'</tr></thead>';
    const tb=document.createElement('tbody');rows.forEach(r=>tb.appendChild(r));t.appendChild(tb);const w=document.createElement('div');w.className='lbwrap';w.appendChild(t);return w;};
  if(DB.tab==='season'){
    if(!b||!b.list.length)return empty('No ranked matches yet this season.<br>Win a 1v1 to take the first spot.');
    const top=b.list.slice(0,100);resolveNames(top.map(p=>p.id));
    const pod=document.createElement('div');pod.className='podium';
    [1,0,2].forEach(ix=>{const p=top[ix];const d=document.createElement('div');d.className='pod p'+(ix+1);
      if(p){d.appendChild(portraitEl(favKit(p)));d.insertAdjacentHTML('beforeend',`<div class="nm">${who(p)}</div><div class="blk"><span class="n">#${ix+1}</span><span>${p.pts} pts</span>${p.prize?`<span class="pz">${usd(p.prize)}</span>`:''}</div>`);}
      else d.insertAdjacentHTML('beforeend',`<div class="blk"><span class="n">#${ix+1}</span><span>Open</span></div>`);pod.appendChild(d);});
    body.appendChild(pod);
    const rows=top.slice(3).map((p,i)=>{const tr=document.createElement('tr');if(p.id===DB.me)tr.className='me';
      tr.innerHTML=`<td class="pos">${i+4}</td>`;const td=document.createElement('td');td.className='hide-s';td.appendChild(portraitEl2(favKit(p)));tr.appendChild(td);
      tr.insertAdjacentHTML('beforeend',`<td class="who">${who(p)}</td><td class="hide-m">${rankChip(p.rating,p.lord)}</td><td class="num">${p.pts}</td><td class="num pz">${p.prize?usd(p.prize):'-'}</td>`);return tr;});
    if(rows.length)body.appendChild(table([['#'],['','hide-s'],['Player'],['Rank','hide-m'],['Points','num'],['Prize','num']],rows));
  }else if(DB.tab==='clans'){
    const cl=clanBoard();setTimeout(()=>{const x=document.getElementById('bd-clanpage');if(x)x.onclick=openClans;},0);if(!cl.length)return empty('No clans yet. <button type="button" class="arc" id="bd-clanpage">Open the Clans page</button>');
    const rows=cl.map((c,i)=>{const tr=document.createElement('tr');tr.innerHTML=`<td class="pos">${i+1}</td><td class="who">[${esc(c.tag)}]</td><td class="num">${c.members}</td><td class="num">${c.pts}</td><td class="hide-s">${c.top?who(c.top):''}</td>`;return tr;});
    body.appendChild(table([['#'],['Clan'],['Members','num'],['Points','num'],['Best player','hide-s']],rows));
  }else if(DB.tab==='lords'){
    const lords=b?b.list.filter(p=>p.lord).sort((x,y)=>y.rating-x.rating):[];
    if(!lords.length)return empty(`No Oni Lords yet. The top 50 by rating, with ${ELIG.games}+ matches, become Oni Lords.`);
    resolveNames(lords.map(p=>p.id));
    const rows=lords.map((p,i)=>{const tr=document.createElement('tr');if(p.id===DB.me)tr.className='me';
      tr.innerHTML=`<td class="pos">${i+1}</td>`;const td=document.createElement('td');td.className='hide-s';td.appendChild(portraitEl2(favKit(p)));tr.appendChild(td);
      tr.insertAdjacentHTML('beforeend',`<td class="who">${who(p)}</td><td class="num">${p.rating}</td><td class="num">${p.w}-${p.l}</td><td class="num hide-s">${i<10?'<span class="tbadge t4 mini">KONGO</span>':'<span class="tbadge t3 mini">KIN</span>'}</td>`);return tr;});
    body.appendChild(table([['#'],['','hide-s'],['Player'],['Rating','num'],['W-L','num'],['Skin at season end','num hide-s']],rows));
  }else{
    let h='<div class="ladder compact">'+RANKS.map((r,i)=>`<div class="rung" style="--rc:${r.c}"><img class="embl" src="${emblem(i,2)}" alt=""><b>${r.n}</b>${r.lord?'Top 50':r.min}</div>`).join('')+'</div>';
    h+='<div class="rsteps">'+[
      ['1','Climb','Win ranked 1v1s to raise your rating. Each rank has 3 divisions. The top 50 are Oni Lords.'],
      ['2','Score','A win gives 10 points times the arena tier, 1 to 4. Play 3 matches a day for up to x1.35.'],
      ['3','Get paid','Every 2 weeks the top 100 split the Season Cauldron. Qualify with 5 matches against 3 players.'],
      ['4','Earn Mythic','Top 10 get the diamond Kongo-Oni, places 11 to 50 the gold Kin-Oni. Never sold.']]
      .map(([n,t,d])=>`<div class="rstep"><span class="rn">${n}</span><b>${t}</b>${d}</div>`).join('')+'</div>';
    h+='<div class="rsplit"><b>Payout</b>'+BRACKETS.map(x=>`<span>${x.from===x.to?'#'+x.from:'#'+x.from+'-'+x.to} <i>${x.pct}%${x.from===x.to?'':' each'}</i></span>`).join('')+'</div>';
    body.innerHTML=h;
  }
}
function renderMe(){}
function rankLine(){
  const me=myEntry();
  if(!me)return DB.state==='ok'?'You have no ranked matches yet. Win a 1v1 to get a rank.':'';
  const nx=nextRank(me.rating);
  return `${rankName(me.rating,me.lord)}, rating ${me.rating}. Season ${SEASON.n}: #${me.pos} with ${me.pts} points.`+(me.lord?'':nx?` ${nx.min-me.rating} rating to ${nx.n}.`:' Reach the top 50 to become an Oni Lord.');
}
function onBoard(){
  if($('p-board').classList.contains('on'))renderBoard();
  if($('p-cauldron').classList.contains('on'))renderCauldronInfo();
  if($('p-profile').classList.contains('on')&&!PROFILE.draft)renderProfile();
  if(mode==='title'){refreshTitle();refreshProfileBtn();}
  if(endShown&&(mode==='host'||mode==='guest'))updateDelta();
}
function updateDelta(){
  const el=$('rank-delta');if(!el||!NET.before)return;const me=myEntry();
  if(NET.unranked){el.textContent=NET.unranked;return;}
  if(!me||me.games<=NET.before.games){el.textContent='Saving the result...';return;}
  const dr=me.rating-NET.before.rating,dp=me.pts-NET.before.pts;const n0=rankName(NET.before.rating),n1=rankName(me.rating,me.lord);const up=me.rating>NET.before.rating;
  el.textContent=`Rating ${NET.before.rating} to ${me.rating} (${dr>=0?'+':''}${dr}). Season points +${dp}.`+(n0!==n1?(up?` Rank up: ${n1}!`:` Rank down: ${n1}.`):'');
}
async function recordMatch(m){
  if(!DB.db||!DB.me){NET.unranked='Unranked: the leaderboard is not available here.';updateDelta();return;}
  if(!NET.guestBy){NET.unranked='Unranked: your opponent could not be identified.';updateDelta();return;}
  if(NET.guestBy===DB.me){NET.unranked='Unranked: both sides are the same account.';updateDelta();return;}
  try{await DB.db.collection('matches').doc(String(m.id)).set({season:SEASON.n,ta:hasT3()?1:0,tb:NET.guestT3|0,fm:NET.fmt||'bo3',a:DB.me,b:NET.guestBy,ka:m.kits[0],kb:m.kits[1],map:m.map,stake:m.stake,w:m.winner,rounds:m.wins,ts:Date.now()});}
  catch(e){NET.unranked='Unranked: the result could not be saved.';updateDelta();}
}
async function recordPractice(best,kit){
  if(!DB.db||!DB.me)return;const mine=DB.practice.find(p=>p.id===DB.me);if(mine&&mine.best>=best)return;
  try{await DB.db.collection('practice').doc(DB.me).set({best,kit,ts:Date.now()});}catch(e){}
}
function snapshotBefore(){const me=myEntry();NET.before=me?{rating:me.rating,pts:me.pts,games:me.games}:{rating:1000,pts:0,games:0};NET.unranked=null;}
document.querySelectorAll('#p-board [data-tab]').forEach(b=>b.onclick=()=>{DB.tab=b.dataset.tab;SFX.select();renderBoard();$('p-board').scrollTop=0;});


/* ===================== CAULDRONS ===================== */
const DROP_WINNERS=20,DROP_SPLIT=Array(20).fill(5);
function lastDrop(now){now=now||Date.now();const d=new Date(now);const day=d.getUTCDay();
  let t=Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate(),20,0,0)-day*86400000;if(t>now)t-=7*86400000;return t;}
function nextDrop(){return lastDrop()+7*86400000;}
function todayKey(){return new Date().toISOString().slice(0,10);}
DB.tickets=[];
function freeTickets(doc){if(!doc||!Array.isArray(doc.days))return 0;const since=lastDrop();return doc.days.filter(d=>Date.parse(d+'T00:00:00Z')+86400000>since).length;}
function ticketState(){
  const b=DB.board;const matchT=b&&b.tix?b.tix:{};const tot={};
  for(const [id,n] of Object.entries(matchT))tot[id]=(tot[id]||0)+n;
  for(const t of DB.tickets){tot[t.id]=(tot[t.id]||0)+freeTickets(t);}
  const all=Object.values(tot).reduce((a,c)=>a+c,0);const mine=DB.me?(tot[DB.me]||0):0;
  const myDoc=DB.tickets.find(t=>t.id===DB.me);const claimed=!!(myDoc&&Array.isArray(myDoc.days)&&myDoc.days.includes(todayKey()));
  return{all,mine,claimed,players:Object.keys(tot).length};
}
async function claimTicket(){
  if(!DB.db||!DB.me)return;const myDoc=DB.tickets.find(t=>t.id===DB.me);const since=lastDrop();
  const days=((myDoc&&myDoc.days)||[]).filter(d=>Date.parse(d+'T00:00:00Z')+86400000>since);if(days.includes(todayKey()))return;
  days.push(todayKey());try{await DB.db.collection('tickets').doc(DB.me).set({days,ts:Date.now()});SFX.coin();}catch(e){$('c-actions').insertAdjacentHTML('beforeend','<div class="note">Could not save your airdrop point. Try again.</div>');}
}
function fmtLeft(ms){ms=Math.max(0,ms);const d=Math.floor(ms/86400000),h=Math.floor(ms%86400000/3600000),mi=Math.floor(ms%3600000/60000);return (d?d+'d ':'')+h+'h '+mi+'m';}
function renderCauldronInfo(){
  const b=DB.board;const pool=b?b.pool:0,drop=b?b.drop:0;const me=myEntry();const ts=ticketState();
  $('c-season').innerHTML=`<h3>Season Cauldron</h3><span class="amt">${usd(pool)}</span>The top 100 split it in ${fmtLeft(SEASON.ends-Date.now())}.`+(me&&me.prize?` <strong>Your share now: ${usd(me.prize)}</strong>`:'');
  $('c-drop').innerHTML=`<h3>Curse Cauldron</h3><span class="amt">${usd(drop)}</span>Airdrop to 20 players on Sunday, in ${fmtLeft(nextDrop()-Date.now())}. <strong>You have ${ts.mine} airdrop point${ts.mine===1?'':'s'}.</strong>`;
  const a=$('c-actions');a.innerHTML='';
  const btn=(label,cls,fn,dis)=>{const x=document.createElement('button');x.className='arc '+(cls||'');x.type='button';x.textContent=label;x.onclick=fn;x.disabled=!!dis;a.appendChild(x);return x;};
  if(DB.state==='ok'&&DB.me)btn(ts.claimed?'Daily point claimed':'Claim daily airdrop point','gold',claimTicket,ts.claimed);
  btn('Season ranking','',()=>{DB.tab='season';show('p-board');renderBoard();});
  $('c-clock').innerHTML=`Next airdrop in<b>${fmtLeft(nextDrop()-Date.now())}</b>Sundays 20:00 UTC`;
  $('c-rules').innerHTML=`<div class="rsplit"><b>How they fill</b><span>2% of every staked pot: 1.5% Season, 0.5% Curse</span><span>1 airdrop point per ranked match, plus 1 free a day</span><span>On-chain and verifiable at launch</span></div>`;
  if(DB.state!=='ok'){a.insertAdjacentHTML('afterbegin','<div class="note">Demo money.</div>');}
}
const ccv=document.getElementById('ccv');const cctx=ccv?ccv.getContext('2d'):null;const CB=[];
function drawCauldron(cx,fill,liq,liqL,glow,label,amount,fr,kind){
  const top=58,rx=52,ry=10,bodyH=58;
  // fire
  for(let i=0;i<9;i++){const fx=cx-32+i*8,h=15+Math.round(5*Math.sin(fr*0.25+i*1.7))+(i%2)*3;
    for(let r=0;r<h;r++){const t=r/h,w=Math.max(1,Math.round(4*(1-t)+(r<2?1:0)));const c=t<0.35?'#C1121F':t<0.7?'#FF6A00':'#FFB000';rect(fx-w+Math.round(Math.sin(fr*0.3+r*0.5+i)*(t*1.5)),141-r,w*2,1,c);}
    px(fx,141-h,'#FFF2A8');}
  rect(cx-44,140,88,6,'#1A0A08');
  // legs
  rect(cx-40,128,6,12,'#141414');rect(cx+34,128,6,12,'#141414');
  // glow behind
  G.fillStyle=glow;G.beginPath();G.ellipse(cx,top,rx+14,40,0,0,Math.PI*2);G.fill();
  // body
  for(let y=0;y<bodyH;y++){const t=y/bodyH;const w=Math.round(rx*Math.sqrt(Math.max(0.08,1-Math.pow(Math.max(0,t-0.15)/0.95,2))));rect(cx-w,top+y,w*2,1,y%6===0?'#1E1E24':'#26262E');rect(cx-w,top+y,3,1,'#3A3A46');rect(cx+w-4,top+y,4,1,'#15151A');}
  // rim + liquid
  ell(cx,top,rx+4,ry+2,'#3A3A46');ell(cx,top,rx,ry,'#101014');
  const lvl=Math.round((1-fill)*6);ell(cx,top+lvl,rx-4,ry-3,liq);
  for(let i=0;i<5;i++)rect(cx-30+i*13,top+lvl-1+((fr>>2)+i)%2,6,1,liqL);
  // bubbles
  for(const b of CB){if(b.k!==kind)continue;const y=top+lvl-b.h;G.globalAlpha=Math.min(1,b.life/12);disc(cx+b.x,y,b.r,liqL);G.globalAlpha=1;}
  if(kind==='s'){for(let i=0;i<3;i++){const a=fr*0.03+i*2.1;const x=cx+Math.cos(a)*26,y=top+lvl-2+Math.sin(a*1.7)*2;disc(x,y,3,'#8A5A00');disc(x,y,2,'#FFB000');px(x-1,y-1,'#FFF2A8');}}
  else{for(let i=0;i<3;i++){const a=fr*0.02+i*2.1;const x=cx+Math.cos(a)*24,y=top+lvl-8-((fr+i*30)%40)/3;G.globalAlpha=0.7;disc(x,y,2,'#BFFFF8');px(x,y-3,'#2EC4B6');G.globalAlpha=1;}}
  // handles
  rect(cx-rx-8,top+8,6,3,'#3A3A46');rect(cx+rx+2,top+8,6,3,'#3A3A46');
  txt(label,cx,top-30,7,kind==='s'?'#FFB000':'#2EC4B6','#0A0506');
  txt(amount,cx,top+30,11,'#F3E9E4','#0A0506');
}
let cfr=0;
function renderCauldrons(){
  if(!cctx)return;cfr++;cctx.imageSmoothingEnabled=false;const g=cctx;
  const sky=['#0A0612','#0E0818','#130A1E','#1A0C22','#220E24','#2C1024','#381422','#46181E','#521C1A','#5E2016'];
  sky.forEach((c,i)=>{g.fillStyle=c;g.fillRect(0,i*27,480,27);});
  for(let i=0;i<40;i++){g.fillStyle=i%5?'#8A7A9A':'#FFD8A0';g.fillRect((i*97+Math.floor(cfr*0.05))%480,(i*53)%120,1,1);}
  g.fillStyle='#1E1412';g.fillRect(0,214,480,56);g.fillStyle='#2A1E1C';for(let x=0;x<480;x+=24)g.fillRect(x,222+(x/24%2)*8,22,5);
  const b=DB.board;const pool=b?b.pool:0,drop=b?b.drop:0;const f=v=>0.2+0.8*(1-Math.exp(-v/50000));
  if(typeof cauldHi==='function'){cauldHi(g,130,190,'season',f(pool),cfr,usd(pool));cauldHi(g,350,190,'curse',f(drop*3),cfr,usd(drop));}
}
function openCauldrons(){renderCauldronInfo();show('p-cauldron');}



/* ===================== FOUNDERS: GENESIS ONI ===================== */
const FOUNDER_CAP=200;
function founderList(){return Object.entries(DB.profiles||{}).filter(([id,p])=>p&&p.created).sort((a,b)=>a[1].created-b[1].created||(a[0]<b[0]?-1:1)).slice(0,FOUNDER_CAP).map(x=>x[0]);}
function founderNo(id){if(!id)return 0;const i=founderList().indexOf(id);return i>=0?i+1:0;}
function isFounder(){return DB.me?founderNo(DB.me)>0:!!(PROFILE.local&&PROFILE.local.founder);}
function foundersLeft(){return Math.max(0,FOUNDER_CAP-founderList().length);}

/* ===================== WALLET + PROFILE ===================== */
DB.profiles={};
const PROFILE={draft:null};
function myProfile(){return (DB.me&&DB.profiles[DB.me])||PROFILE.local||null;}
try{PROFILE.local=JSON.parse(localStorage.getItem('oni-profile')||'null');}catch(e){}
function shortW(w){return w?w.slice(0,4)+'...'+w.slice(-4):'';}
function demoWallet(){const a='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';let s='';for(let i=0;i<44;i++)s+=a[Math.floor(Math.random()*a.length)];return s;}
function validName(n){return /^[A-Za-z0-9_]{3,16}$/.test(n);}
function nameTaken(n){const l=n.toLowerCase();return Object.entries(DB.profiles).some(([id,p])=>id!==DB.me&&p&&p.name&&p.name.toLowerCase()===l);}
function bestTier(){let t=0;for(const k of OWN)t=Math.max(t,CH[k].tier);return t;}
function statsOf(id){
  const rows=[];let pnl=0,staked=0,w=0,l=0;
  if(id)for(const mt of DB.matches){if(mt.a!==id&&mt.b!==id)continue;const side=mt.a===id?0:1;const won=mt.w===side;
    const d=mt.stake>0?(won?payout(mt.stake).win-mt.stake:-mt.stake):0;pnl+=d;staked+=mt.stake||0;won?w++:l++;
    rows.push({ts:mt.ts,won,d,stake:mt.stake||0,map:mt.map|0,opp:side?mt.a:mt.b,kit:side?mt.kb:mt.ka,okit:side?mt.ka:mt.kb});}
  rows.sort((a,b)=>b.ts-a.ts);return{rows,pnl,staked,w,l,games:w+l};
}
function myStats(){return statsOf(DB.me);}
const signed=c=>(c>0?'+':c<0?'-':'')+usd(Math.abs(c));
function avatarEl(pr,kit,size){
  if(pr&&pr.av&&/^data:image\/(png|jpeg|webp);base64,/.test(pr.av)){const im=document.createElement('img');im.src=pr.av;im.alt='';im.className='avatar';im.width=size;im.height=size;return im;}
  const c=portraitEl2(kit||'oni');c.className='avatar';return c;
}
const safeX=h=>/^[A-Za-z0-9_]{1,15}$/.test(h||'')?h:'';
let PROFILE_VIEW=null,PF_TAB='overview';
function isOnline(id){return !!(id&&VIL.peers.some(p=>p.by===id&&p.presence&&p.presence.v));}
function myFriends(){const p=myProfile();return p&&Array.isArray(p.friends)?p.friends:[];}
function renderProfile(){
  const viewId=PROFILE_VIEW&&PROFILE_VIEW!==DB.me?PROFILE_VIEW:null;const own=!viewId;
  const pr=own?myProfile():(DB.profiles[viewId]||{name:nameOf(viewId)});const body=$('pf-body');body.innerHTML='';
  if(own&&!pr){return renderConnect();}
  const id=own?DB.me:viewId;const e=DB.board&&id?DB.board.map.get(id):null;const st=statsOf(id);
  const main=pr.main&&CH[pr.main]?pr.main:(e?favKit(e):'oni');const clan=safeClan(pr.clan);const fno=founderNo(id);const xh=safeX(pr.x);
  $('pf-title').textContent=pr.name||'Player';$('pf-clock').innerHTML=own?`Your profile<b>${clan?'['+clan+']':'ONI'}</b>${pr.wallet?esc(shortW(pr.wallet)):''}`:`Player<b>${clan?'['+clan+']':'ONI'}</b>${isOnline(id)?'Online now':'Offline'}`;
  // banner
  const hero=document.createElement('div');hero.className='pf2-hero';
  const art=document.createElement('div');art.className='pf2-art';const cv=document.createElement('canvas');cv.width=300;cv.height=165;art.appendChild(cv);
  const idb=document.createElement('div');idb.className='pf2-id';const av=avatarEl(pr,main,96);av.classList.add('big');idb.appendChild(av);
  const on=isOnline(id)||own;const wr=st.games?Math.round(st.w/st.games*100):0;
  idb.insertAdjacentHTML('beforeend',`<div class="pf2-name"><span class="dot ${on?'on':''}"></span>${clan?`<span class="ctag">[${clan}]</span> `:''}${esc(pr.name||'Player')}</div>
    <div class="badges">${rankChip(e?e.rating:1000,e&&e.lord)}<span>${e?e.rating:1000} rating</span>${fno?`<span class="tbadge t5">FOUNDER #${fno}</span>`:''}${e?`<span>Season #${e.pos}</span>`:''}${xh?`<a class="xlink" href="https://x.com/${xh}" target="_blank" rel="noopener noreferrer">@${xh}</a>`:''}</div>
    <div class="pf2-quick"><div><b>${st.w}-${st.l}</b>W-L</div><div><b>${wr}%</b>Win rate</div><div><b>${e?e.pts:0}</b>Points</div><div><b class="${st.pnl>0?'up':st.pnl<0?'dn':''}">${signed(st.pnl)}</b>PnL</div></div>`);
  const acts=document.createElement('div');acts.className='acts';
  const ab=(t,c,fn,dis)=>{const b=document.createElement('button');b.className='arc '+(c||'');b.type='button';b.textContent=t;b.onclick=fn;b.disabled=!!dis;acts.appendChild(b);};
  if(own){ab('Edit profile','',()=>{PROFILE.draft=Object.assign({},pr);renderConnect(true);});ab('Disconnect','alt',disconnectWallet);}
  else{const fr=myFriends().includes(id);if(myProfile())ab(fr?'Friends ✓':'Add friend',fr?'alt':'gold',async()=>{await patchProfile({friends:fr?myFriends().filter(x=>x!==id):myFriends().concat([id])});toast(fr?'Removed from friends':'Added to friends');renderProfile();});
    const peer=VIL.peers.find(p=>p.by===id&&p.presence&&p.presence.v);ab(peer?'Challenge':'Offline','',()=>{if(peer){vilChallenge(peer);}},!peer);ab('Back to my profile','alt',()=>{PROFILE_VIEW=null;PF_TAB='overview';renderProfile();});}
  idb.appendChild(acts);hero.append(art,idb);body.appendChild(hero);
  showcase(cv,main,[1,0,2,3][CH[main].tier],main==='oni'&&own?SEL.opal:0);
  // tabs
  const tabs=[['overview','Overview'],['matches','Matches']].concat(own?[['ach','Achievements'],['friends','Friends'],['aff','Affiliate']]:[]);if(!tabs.find(t=>t[0]===PF_TAB))PF_TAB='overview';
  const tb=document.createElement('div');tb.className='lb-tabs pf2-tabs';tabs.forEach(([k,l])=>{const b=document.createElement('button');b.className='lb-tab';b.type='button';b.textContent=l+(k==='friends'?` (${myFriends().length})`:'');b.setAttribute('aria-pressed',PF_TAB===k?'true':'false');b.onclick=()=>{PF_TAB=k;renderProfile();};tb.appendChild(b);});
  body.appendChild(tb);const sec=document.createElement('div');sec.className='pf2-sec';body.appendChild(sec);
  if(PF_TAB==='overview'){
    const form=st.rows.slice(0,10).reverse();const kits={};for(const r of st.rows){const k=CH[r.kit]?r.kit:'oni';const o=kits[k]||(kits[k]={w:0,l:0});r.won?o.w++:o.l++;}
    let h=`<div class="pf2-grid"><div class="card"><h4>Last 10</h4><div class="form">${form.length?form.map(r=>`<span class="${r.won?'w':'l'}">${r.won?'W':'L'}</span>`).join(''):'<small>No ranked matches yet.</small>'}</div></div>`+
      `<div class="card"><h4>Season</h4><div class="kv"><span>Points</span><b>${e?e.pts:0}</b><span>Prize now</span><b>${e&&e.prize?usd(e.prize):'-'}</b><span>Activity</span><b>x${(e&&e.act?e.act:1).toFixed(2)}</b><span>Best streak</span><b>${e?e.best:0}</b><span>Bounties</span><b>${e&&e.bounties?e.bounties:0}</b></div></div>`+
      (own?`<div class="card"><h4>Wallet</h4><div class="kv"><span>Staked</span><b>${usd(st.staked)}</b><span>PnL</span><b>${signed(st.pnl)}</b><span>Airdrop points</span><b>${typeof ticketState==='function'?ticketState().mine:0}</b><span>Balance</span><b>-</b></div><small>Balance shows once a real wallet is connected.</small></div>`:'')+'</div>';
    const kl=Object.entries(kits).sort((a,b)=>(b[1].w+b[1].l)-(a[1].w+a[1].l));
    h+=`<h4 class="pf2-h">By fighter</h4><div class="pf2-kits">${kl.length?kl.map(([k,o])=>`<div class="kit"><span data-k="${k}" data-p="0"></span><div><b>${esc(CH[k].name)}</b><small>${o.w}-${o.l}, ${Math.round(o.w/(o.w+o.l)*100)}%</small><i style="width:${Math.round(o.w/(o.w+o.l)*100)}%"></i></div></div>`).join(''):'<small>Play ranked matches to see stats for each fighter.</small>'}</div>`;
    sec.innerHTML=h;fillPortraits(sec);
  }else if(PF_TAB==='matches'){
    if(!st.rows.length){sec.innerHTML='<div class="lb-empty">No ranked matches this season yet.</div>';}
    else{resolveNames(st.rows.slice(0,30).map(r=>r.opp));const t=document.createElement('table');t.className='lbt clean';t.innerHTML='<thead><tr><th>Result</th><th></th><th>Opponent</th><th class="hide-s">Arena</th><th class="num">Stake</th><th class="num">PnL</th><th class="num hide-s">When</th></tr></thead>';
      const tbody=document.createElement('tbody');for(const r of st.rows.slice(0,30)){const tr=document.createElement('tr');tr.innerHTML=`<td class="${r.won?'win':'loss'}">${r.won?'Win':'Loss'}</td>`;const td=document.createElement('td');td.appendChild(portraitEl2(CH[r.kit]?r.kit:'oni'));tr.appendChild(td);
        tr.insertAdjacentHTML('beforeend',`<td class="who"><button type="button" class="plink" data-pid="${esc(r.opp)}">${esc(nameOf(r.opp))}</button></td><td class="hide-s">${esc(MAPS[r.map].name)}</td><td class="num">${r.stake?usd(r.stake):'Free'}</td><td class="num ${r.d>0?'win':r.d<0?'loss':''}">${r.stake?signed(r.d):'-'}</td><td class="num hide-s">${new Date(r.ts).toISOString().slice(5,16).replace('T',' ')}</td>`);tbody.appendChild(tr);}
      t.appendChild(tbody);const w=document.createElement('div');w.className='lbwrap';w.appendChild(t);sec.appendChild(w);}
  }else if(PF_TAB==='ach'){const got=checkAch();sec.innerHTML=`<div class="achs2">`+ACH.map(([aid,n,d])=>`<div class="ach${got.includes(aid)?' got':''}"><span class="ic">${got.includes(aid)?'&#10003;':'&#9679;'}</span><div><b>${n}</b><small>${d}</small></div></div>`).join('')+'</div>';}
  else if(PF_TAB==='friends'){renderFriends(sec);}
  else if(PF_TAB==='aff'){renderAffiliate(sec);}
  wirePlayerLinks(body);
}
function renderFriends(sec){
  sec.innerHTML=`<div class="fr-search"><input class="nmin" id="fr-q" placeholder="Find a player by name" autocomplete="off" aria-label="Find a player"><div id="fr-res"></div></div><h4 class="pf2-h">Your friends</h4><div id="fr-list"></div>`;
  const row=(fid,extra)=>{const p=DB.profiles[fid]||{name:nameOf(fid)};const e=DB.board?DB.board.map.get(fid):null;const on=isOnline(fid);const mutual=Array.isArray(p.friends)&&p.friends.includes(DB.me);
    const d=document.createElement('div');d.className='fr-row';d.appendChild(avatarEl(p,p.main&&CH[p.main]?p.main:'oni',40));
    d.insertAdjacentHTML('beforeend',`<div class="fr-who"><b><span class="dot ${on?'on':''}"></span>${safeClan(p.clan)?'['+safeClan(p.clan)+'] ':''}${esc(p.name||nameOf(fid))}</b><small>${rankChip(e?e.rating:1000,e&&e.lord)} ${on?'Online in the village':'Offline'}${mutual?' · Mutual':''}</small></div>`);
    const acts=document.createElement('div');acts.className='fr-acts';const b=(t,c,fn,dis)=>{const x=document.createElement('button');x.type='button';x.className='arc '+(c||'');x.textContent=t;x.onclick=fn;x.disabled=!!dis;acts.appendChild(x);};
    extra(b,on);d.appendChild(acts);return d;};
  const list=$('fr-list');const fr=myFriends();
  if(!fr.length)list.innerHTML='<div class="lb-empty">No friends yet. Find players above, or from the leaderboard.</div>';
  else [...fr].sort((a,b)=>isOnline(b)-isOnline(a)).forEach(fid=>list.appendChild(row(fid,(b,on)=>{const peer=VIL.peers.find(p=>p.by===fid&&p.presence&&p.presence.v);
    b('Challenge','gold',()=>{if(peer)vilChallenge(peer);},!peer);b('Profile','',()=>openPlayer(fid));b('Remove','alt',async()=>{await patchProfile({friends:myFriends().filter(x=>x!==fid)});renderProfile();});})));
  const q=$('fr-q'),res=$('fr-res');
  q.oninput=()=>{const v=q.value.trim().toLowerCase();res.innerHTML='';if(v.length<2)return;
    const hits=Object.entries(DB.profiles||{}).filter(([fid,p])=>fid!==DB.me&&p&&p.name&&p.name.toLowerCase().includes(v)).slice(0,6);
    if(!hits.length){res.innerHTML='<small>No players found.</small>';return;}
    hits.forEach(([fid])=>res.appendChild(row(fid,(b)=>{const has=myFriends().includes(fid);b(has?'Friends ✓':'Add friend',has?'alt':'gold',async()=>{if(has)return;await patchProfile({friends:myFriends().concat([fid])});toast('Added to friends');renderProfile();},has);b('Profile','',()=>openPlayer(fid));})));};
}
function openPlayer(id){if(!id)return;auInit();SFX.select();PROFILE.draft=null;PF_TAB='overview';PROFILE_VIEW=id===DB.me?null:id;renderProfile();show('p-profile');$('p-profile').scrollTop=0;}
function wirePlayerLinks(root){root.querySelectorAll('[data-pid]').forEach(b=>{b.onclick=ev=>{ev.stopPropagation();openPlayer(b.dataset.pid);};});}
function renderConnect(edit){
  const body=$('pf-body');body.innerHTML='';const d=PROFILE.draft=PROFILE.draft||{name:'',wallet:'',walletApp:'',main:'oni'};
  $('pf-title').textContent=edit?'Edit profile':'Connect wallet';$('pf-clock').innerHTML='Solana<b>Demo</b>no real wallet here';
  const cn=document.createElement('div');cn.className='cn';
  const s1=document.createElement('div');s1.className='step';
  s1.innerHTML=`<h3>1. Wallet</h3>Stakes, prizes and fighters live in your wallet. In the real version your wallet signs a message to prove it is yours. Here it creates a demo address.`;
  const wl=document.createElement('div');wl.className='wallets';
  ['Phantom','Solflare','Backpack'].forEach(n=>{const b=document.createElement('button');b.type='button';b.className='wbtn';b.textContent=n;b.setAttribute('aria-pressed',d.walletApp===n?'true':'false');
    b.onclick=()=>{d.walletApp=n;if(!d.wallet)d.wallet=demoWallet();SFX.coin();renderConnect(edit);};wl.appendChild(b);});
  s1.appendChild(wl);if(d.wallet)s1.insertAdjacentHTML('beforeend',`<div class="ok" style="margin-top:10px">Connected: ${esc(shortW(d.wallet))}</div>`);
  const fl=foundersLeft();if(!edit&&fl>0)cn.insertAdjacentHTML('beforeend',`<div class="step" style="border-color:#FF3B30"><h3 style="color:#FF6A5A">Founder reward</h3>Create your account now and you get the <b style="color:#FF8A7A">Genesis Oni</b>, numbered, only for the first 200 players. ${fl} of 200 left. It will be tradeable on the marketplace.</div>`);
  const s2=document.createElement('div');s2.className='step';
  s2.innerHTML=`<h3>2. Player name</h3>This is how everyone sees you on the leaderboard and in matches. 3 to 16 letters, numbers or _.`;
  const inp=document.createElement('input');inp.className='nmin';inp.maxLength=16;inp.value=d.name||'';inp.placeholder='YourName';inp.setAttribute('aria-label','Player name');inp.autocomplete='off';
  const msg=document.createElement('div');msg.style.marginTop='8px';
  const check=()=>{d.name=inp.value.trim();if(!d.name){msg.className='';msg.textContent='';return false;}
    if(!validName(d.name)){msg.className='err';msg.textContent='Use 3 to 16 letters, numbers or _.';return false;}
    if(nameTaken(d.name)){msg.className='err';msg.textContent='That name is taken.';return false;}
    msg.className='ok';msg.textContent='Available.';return true;};
  inp.addEventListener('input',check);s2.append(inp,msg);
  const sp=document.createElement('div');sp.className='step';sp.innerHTML='<h3>Profile photo</h3>Upload a photo, or keep your main fighter. Photos are shown to other players.';
  const prev=document.createElement('div');prev.className='pf-top';prev.appendChild(avatarEl(d,d.main||'oni',72));sp.appendChild(prev);
  const fin=document.createElement('input');fin.type='file';fin.accept='image/png,image/jpeg,image/webp';fin.hidden=true;
  const up=document.createElement('button');up.type='button';up.className='arc';up.textContent='Upload photo';up.onclick=()=>fin.click();
  const pix=document.createElement('button');pix.type='button';pix.className='arc alt';pix.textContent=d.pix?'Pixel style: on':'Pixel style: off';
  const rm=document.createElement('button');rm.type='button';rm.className='arc alt';rm.textContent='Use my fighter';rm.onclick=()=>{d.av=null;d.src=null;renderConnect(edit);};
  const bake=(img)=>{const S=96,c=document.createElement('canvas');c.width=S;c.height=S;const g=c.getContext('2d');const s=Math.min(img.width,img.height);
    if(d.pix){const t=document.createElement('canvas');t.width=32;t.height=32;const tg=t.getContext('2d');tg.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,32,32);g.imageSmoothingEnabled=false;g.drawImage(t,0,0,S,S);}
    else{g.imageSmoothingEnabled=true;g.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,S,S);}
    d.av=c.toDataURL('image/jpeg',0.85);renderConnect(edit);};
  pix.onclick=()=>{d.pix=!d.pix;if(d.src){const im=new Image();im.onload=()=>bake(im);im.src=d.src;}else renderConnect(edit);};
  fin.onchange=()=>{const f=fin.files&&fin.files[0];if(!f)return;if(f.size>8e6){alert('Please pick an image under 8 MB.');return;}
    const rd=new FileReader();rd.onload=()=>{d.src=rd.result;const im=new Image();im.onload=()=>bake(im);im.src=rd.result;};rd.readAsDataURL(f);};
  const pr2=document.createElement('div');pr2.className='row';pr2.style.justifyContent='flex-start';pr2.append(up,pix,rm,fin);sp.appendChild(pr2);
  const sx=document.createElement('div');sx.className='step';sx.innerHTML='<h3>X (Twitter)</h3>Optional. Shown as a link on your profile. Verified linking comes with the full launch.';
  const xin=document.createElement('input');xin.className='nmin';xin.maxLength=16;xin.placeholder='handle, without @';xin.value=d.x||'';xin.setAttribute('aria-label','X handle');xin.autocomplete='off';
  const xm=document.createElement('div');xm.style.marginTop='8px';
  xin.addEventListener('input',()=>{const v=xin.value.trim().replace(/^@/,'');d.x=v;xm.className=v&&!safeX(v)?'err':'';xm.textContent=v&&!safeX(v)?'Letters, numbers or _, up to 15.':'';});sx.append(xin,xm);
  const sc=document.createElement('div');sc.className='step';sc.innerHTML='<h3>Clan</h3>Optional. 2 to 5 letters or numbers. Players with the same tag form a clan and climb the clan ranking together.';
  const cin=document.createElement('input');cin.className='nmin';cin.maxLength=5;cin.placeholder='e.g. COOK';cin.value=d.clan||'';cin.setAttribute('aria-label','Clan tag');cin.autocomplete='off';
  cin.addEventListener('input',()=>{cin.value=cin.value.toUpperCase().replace(/[^A-Z0-9]/g,'');d.clan=cin.value;});sc.appendChild(cin);
  const s3=document.createElement('div');s3.className='step';s3.innerHTML='<h3>3. Main fighter</h3>Shown on your profile and next to your name.';
  const mains=document.createElement('div');mains.className='mains';
  FIGHTERS.filter(fd=>owns(fd.kit)).forEach(fd=>{const b=document.createElement('button');b.type='button';b.className='fc';b.setAttribute('aria-pressed',d.main===fd.kit?'true':'false');
    const n=document.createElement('div');n.textContent=CH[fd.kit].name;b.append(portraitEl2(fd.kit),n);b.onclick=()=>{d.main=fd.kit;SFX.select();renderConnect(edit);};mains.appendChild(b);});
  s3.appendChild(mains);
  const save=document.createElement('button');save.className='arc gold';save.type='button';save.textContent=edit?'Save profile':'Create profile';
  const err=document.createElement('div');err.className='err';
  save.onclick=async()=>{if(!d.wallet){err.textContent='Connect a wallet first.';return;}if(!check()){err.textContent='Pick a valid, free name.';return;}await saveProfile(d);};
  const back=document.createElement('button');back.className='arc alt';back.type='button';back.textContent='Cancel';back.onclick=()=>{PROFILE.draft=null;myProfile()?renderProfile():show('p-title');};
  const row=document.createElement('div');row.className='row';row.style.justifyContent='flex-start';row.append(save,back);
  cn.append(s1,s2,sp,sx,sc,s3,row,err);body.appendChild(cn);check();
}
async function saveProfile(d){
  const prev=myProfile();const doc={name:d.name,wallet:d.wallet,walletApp:d.walletApp||'',main:d.main||'oni',ts:Date.now(),created:(prev&&prev.created)||Date.now(),av:d.av||null,x:safeX(d.x)||null,friends:(prev&&Array.isArray(prev.friends)?prev.friends:[]).slice(0,200),clan:safeClan(d.clan)||null,ref:(prev&&prev.ref)||((LS.get('oni-ref',null)&&LS.get('oni-ref',null)!==DB.me)?LS.get('oni-ref',null):null)};
  if(!DB.db&&foundersLeft()>0)doc.founder=1;
  PROFILE.local=doc;try{localStorage.setItem('oni-profile',JSON.stringify(doc));}catch(e){}
  if(DB.db&&DB.me){try{await DB.db.collection('profiles').doc(DB.me).set(doc);DB.profiles[DB.me]=doc;}catch(e){}}
  PROFILE.draft=null;SFX.win();refreshProfileBtn();renderProfile();
}
async function patchProfile(patch){const prev=myProfile();if(!prev)return false;const doc=Object.assign({},prev,patch,{ts:Date.now()});
  PROFILE.local=doc;if(DB.me)DB.profiles[DB.me]=doc;try{localStorage.setItem('oni-profile',JSON.stringify(doc));}catch(e){}
  if(DB.db&&DB.me){try{await DB.db.collection('profiles').doc(DB.me).set(doc);}catch(e){toast('Could not save. Try again.');return false;}}refreshProfileBtn();return true;}
async function disconnectWallet(){
  PROFILE.local=null;try{localStorage.removeItem('oni-profile');}catch(e){}
  if(DB.db&&DB.me){try{await DB.db.collection('profiles').doc(DB.me).delete();}catch(e){}delete DB.profiles[DB.me];}
  refreshProfileBtn();show('p-title');
}
function refreshProfileBtn(){const pr=myProfile();const vb=document.getElementById('vb-profile');if(vb)vb.textContent=pr?pr.name:'Connect wallet';const b=$('b-profile');if(!b)return;if(!pr){b.textContent='Connect wallet';return;}const me=typeof myEntry==='function'?myEntry():null;b.innerHTML=`<span>${esc(pr.name)}</span>${rankChip(me?me.rating:1000,me&&me.lord)}`;}
function openProfile(){auInit();SFX.select();PROFILE.draft=null;PROFILE_VIEW=null;PF_TAB='overview';renderProfile();show('p-profile');$('p-profile').scrollTop=0;}


/* ===================== TENKA TOURNAMENTS ===================== */
const CUPS=[
  {id:'ronin',name:'Ronin Cup',entry:500,size:8,map:4,lvl:[0,1,2]},
  {id:'daimyo',name:'Daimyo Cup',entry:2500,size:16,map:5,lvl:[1,1,2,3]},
  {id:'shogun',name:'Shogun Cup',entry:10000,size:16,map:6,lvl:[1,2,3,3]},
  {id:'tenno',name:'Tenno Cup',entry:17500,size:16,map:8,lvl:[2,2,3,3]},
  {id:'weekly',name:'Weekly Free Cup',entry:0,size:16,map:4,lvl:[0,1,2,3],prize:'50,000 $ONI'}];
const TSPLIT={first:55,second:17.5,third:17.5,oni:5,season:3,weekly:2};
const T_FMT_EARLY={need:2,hpMul:0.7},T_FMT_TOP4={need:3,hpMul:0.7};
const RONIN_NAMES=['Kurokage','Yamabushi','Hayate','Tsubame','Akane','Genji','Raiden','Shiro','Kaede','Musashi','Oboro','Jinbei','Sakon','Hotaru','Isamu','Kagerou','Tatsuya','Yukimura','Sora','Benkei','Arashi','Mikazuki','Hanzo','Kiri'];
function cupPayout(c){const pot=c.entry*c.size;const f=k=>Math.floor(pot*TSPLIT[k]/100);const o={pot,first:f('first'),second:f('second'),third:f('third'),oni:f('oni'),season:f('season'),weekly:f('weekly')};o.prizes=o.first+o.second+o.third;return o;}
function roundName(n,size){const left=size/Math.pow(2,n);return left===2?'Final':left===4?'Semifinals':left===8?'Quarterfinals':'Round of '+left;}
function seedOrder(n){let o=[1];while(o.length<n){const m=o.length*2+1;o=o.flatMap(s=>[s,m-s]);}return o;}
let TN=null;
function drawTrophy(g,t){
  const old=G;G=g;g.clearRect(0,0,64,72);
  const gold=['#8A5A00','#C88A00','#FFB000','#FFD86A','#FFF2B0'];
  // base
  rect(14,62,36,8,'#1A0B0C');rect(14,62,36,2,'#C88A00');rect(18,56,28,6,'#2A1410');rect(18,56,28,1,'#FFB000');
  // stem
  rect(28,44,8,12,gold[1]);rect(30,44,2,12,gold[3]);rect(24,52,16,4,gold[2]);
  // bowl
  for(let y=0;y<30;y++){const w=Math.round(20-Math.pow(y/30,2)*12);rect(32-w,14+y,w*2,1,y<3?gold[3]:gold[2]);rect(32-w,14+y,3,1,gold[1]);rect(32+w-3,14+y,3,1,gold[0]);}
  rect(12,12,40,4,gold[3]);rect(12,12,40,1,gold[4]);
  // handles
  for(const s of [-1,1]){const x=s<0?8:52;rect(x-(s<0?0:3),18,4,3,gold[2]);rect(s<0?6:54,20,4,12,gold[2]);rect(x-(s<0?0:3),30,4,3,gold[2]);}
  // oni emblem
  rect(26,22,12,10,'#C1121F');rect(26,22,12,2,'#FF5A4E');px(28,20,'#EAD9B0');px(35,20,'#EAD9B0');rect(28,25,2,2,'#FFB000');rect(34,25,2,2,'#FFB000');rect(28,29,8,1,'#2A0505');
  // moving shine
  const sx=((t*0.6)%90)-20;for(let y=12;y<44;y++){const x=Math.round(sx+(y-12)*0.35);if(x>12&&x<52)rect(x,y,2,1,'rgba(255,255,255,.55)');}
  G=old;
}
let trophyT=0;
function tickTrophy(){const c=$('trophy');if(!c||c.offsetParent===null)return;trophyT++;if(trophyT%2)drawTrophy(c.getContext('2d'),trophyT/2);}
function renderCups(){
  const box=$('cups');box.innerHTML='';
  CUPS.forEach((c,ci)=>{const p=cupPayout(c);const d=document.createElement('div');d.className='cup c'+(ci+1);
    const art=document.createElement('div');art.className='art';const cv=document.createElement('canvas');cv.width=160;cv.height=90;cv.getContext('2d').drawImage(mapThumb(c.map),0,0);
    art.appendChild(cv);art.insertAdjacentHTML('beforeend',`<span>${esc(MAPS[c.map].name)}</span>`);d.appendChild(art);
    const b=document.createElement('div');b.className='cb';
    b.innerHTML=`<h3>${c.name}</h3><div class="win"><span>CHAMPION WINS</span><b>${c.prize||usd(p.first)}</b></div>`+
      `<div class="facts"><div><b>${c.entry?usd(c.entry):'Free'}</b>Entry</div><div><b>${c.size}</b>Players</div><div><b>${c.prize?'Top 3':usd(p.second)}</b>${c.prize?'Paid in $ONI':'2nd and 3rd'}</div></div>`+
      `<div>${c.prize?'Every week. Prize from the ONI treasury.':'Prize pool '+usd(p.prizes)+', 90% of all entries.'}</div>`;
    const go=document.createElement('button');go.className='arc gold';go.type='button';go.textContent=c.entry?'Enter for '+usd(c.entry):'Enter for free';go.onclick=()=>enterCup(c);b.appendChild(go);
    d.appendChild(b);box.appendChild(d);});
  const R=[
    ['How it works','Pay the entry and take a seat in the bracket. Win and you move on, lose and you are out. The two semifinal losers fight once more for 3rd place.'],
    ['Format','Rounds are 30% faster than a normal 1v1. Early rounds are best of 3. The semifinals, the final and the match for 3rd place are best of 5.'],
    ['Prizes','90% of all entries goes to the top three. The champion takes 55% of the pot, 2nd and 3rd take 17.5% each. Prizes go to your wallet when the final ends.'],
    ['Fees','10% of entries: a 5% game fee, 3% to the Season Cauldron and 2% to the weekly pot. The cauldrons are paid back to players.'],
    ['Seeding','Players are seeded by rating, so the strongest meet as late as possible. The top seed plays the lowest seed first.'],
    ['Fair play','You have 60 seconds to press Ready or you forfeit the match. Leaving or disconnecting loses the match. Every fighter has the same strength.']];
  $('tn-rules').innerHTML='<h3>Rules</h3><div class="rcards">'+R.map(([h,t])=>`<div class="rcard"><h3>${h}</h3>${t}</div>`).join('')+'</div>';
}
function openTourney(){auInit();SFX.select();renderCups();show('p-tourney');$('p-tourney').scrollTop=0;const c=$('trophy');if(c)drawTrophy(c.getContext('2d'),0);}
function myRating(){const me=typeof myEntry==='function'?myEntry():null;return me?me.rating:1000;}
function makeCupPlayers(c){
  const pr=myProfile();const names=[...RONIN_NAMES].sort(()=>Math.random()-0.5);const me=myEntry();
  const you={id:'you',name:pr?pr.name:'You',kit:SEL.kit&&owns(SEL.kit)?SEL.kit:'oni',pal:myPal(SEL.kit),rating:myRating(),w:me?me.w:0,l:me?me.l:0,you:true};
  const list=[you];
  for(let i=1;i<c.size;i++){const k=KITS.filter(x=>x!=='enma')[Math.floor(Math.random()*7)];const rating=Math.round(900+Math.random()*450);
    const games=20+Math.floor(Math.random()*70);const wr=Math.max(0.2,Math.min(0.8,0.35+(rating-900)/1000));const w=Math.round(games*wr);
    list.push({id:'c'+i,name:names[i%names.length]+(i>=names.length?i:''),kit:k,pal:Math.random()<0.5?0:1,rating,w,l:games-w});}
  return list;
}
const LOBBY={t:null};
function seatHTML(q,isNew){if(!q)return '<div class="seat empty">Waiting for a player...</div>';
  return `<div class="seat${q.you?' you':''}${isNew?' new':''}"><span data-k="${q.kit}" data-p="${q.pal}"></span><div><b>${esc(q.name)}${q.you&&q.name!=='You'?' (you)':''}</b>${rankChip(q.rating)}<br>Rating ${q.rating}, ${q.w}-${q.l}</div></div>`;}
function renderLobby(newIdx){
  const L=LOBBY,c=L.cup,n=L.shown;
  $('lo-title').textContent=c.name;$('lo-clock').innerHTML=`Entry ${c.entry?usd(c.entry):'Free'}<b>Champion wins ${c.prize||usd(cupPayout(c).first)}</b>${MAPS[c.map].name}`;
  $('lo-n').textContent=`${n} / ${c.size}`;$('lo-bar').style.width=(n/c.size*100)+'%';
  $('lo-state').textContent=n>=c.size?'Full. The bracket starts now.':`Waiting for ${c.size-n} more player${c.size-n===1?'':'s'}. Starts as soon as it is full.`;
  const seats=$('lo-seats');seats.innerHTML=Array.from({length:c.size},(_,i)=>seatHTML(i<n?L.players[i]:null,i===newIdx)).join('');fillPortraits(seats);
  $('lo-note').textContent='Live lobbies fill with real players once the ONI game server is running. In this demo, CPU players take the empty seats. Demo money.';
}
function enterCup(c){
  SFX.coin();clearTimeout(LOBBY.t);LOBBY.cup=c;LOBBY.players=makeCupPlayers(c);LOBBY.shown=Math.min(c.size-1,1+Math.floor(Math.random()*3));
  renderLobby(-1);show('p-lobby');$('p-lobby').scrollTop=0;
  const tick=()=>{if(!$('p-lobby').classList.contains('on'))return;
    if(LOBBY.shown<c.size){LOBBY.shown++;SFX.select();renderLobby(LOBBY.shown-1);LOBBY.t=setTimeout(tick,350+Math.random()*900);}
    else{LOBBY.t=setTimeout(()=>{if($('p-lobby').classList.contains('on'))startCup(c,LOBBY.players);},1400);}};
  LOBBY.t=setTimeout(tick,700);
}
$('lo-back').onclick=()=>{clearTimeout(LOBBY.t);SFX.select();openTourney();};
function startCup(c,players){
  SFX.fight();players=[...players].sort((a,b)=>b.rating-a.rating);players.forEach((q,i)=>q.seed=i+1);const order=seedOrder(c.size);
  const r0=[];for(let i=0;i<c.size;i+=2)r0.push({a:players[order[i]-1],b:players[order[i+1]-1],w:null,sc:[0,0]});
  TN={cup:c,players,rounds:[r0],third:null,done:false,out:false,place:0,round:0};
  renderBracket();show('p-bracket');$('p-bracket').scrollTop=0;
}
function simBot(a,b,fmt,lv){
  const m=mkMatch('sim',0,[a.kit,b.kit],TN.cup.map,Object.assign({pal:[a.pal,b.pal]},fmt));const mem=[{hold:0,bits:0,gap:false},{hold:0,bits:0,gap:false}];
  let g=0;while(m.scene!=='matchEnd'&&g<60*60*20){step(m,[cpuInput(m,0,mem[0],lv),cpuInput(m,1,mem[1],lv)]);if(m.slow>0)m.slow--;g++;}
  if(m.scene!=='matchEnd'){m.winner=Math.random()<0.5?0:1;m.wins[m.winner]=fmt.need;}
  return{w:m.winner,sc:m.wins.slice()};
}
function fmtFor(ri){const rounds=Math.log2(TN.cup.size);return ri>=rounds-2?T_FMT_TOP4:T_FMT_EARLY;}
function yourMatch(){if(TN.done)return null;const r=TN.rounds[TN.round];const m=r&&r.find(x=>x.w===null&&(x.a.you||x.b.you));if(m)return{m,third:false};
  if(TN.third&&TN.third.w===null&&(TN.third.a.you||TN.third.b.you))return{m:TN.third,third:true};return null;}
function settleRound(){
  const r=TN.rounds[TN.round];const fmt=fmtFor(TN.round);const lv=TN.cup.lvl[Math.min(TN.round,TN.cup.lvl.length-1)];
  for(const x of r)if(x.w===null&&!x.a.you&&!x.b.you){const res=simBot(x.a,x.b,fmt,lv);x.w=res.w;x.sc=res.sc;}
  if(TN.third&&TN.third.w===null&&!TN.third.a.you&&!TN.third.b.you){const res=simBot(TN.third.a,TN.third.b,T_FMT_TOP4,lv);TN.third.w=res.w;TN.third.sc=res.sc;}
  if(r.some(x=>x.w===null)||(TN.third&&TN.third.w===null))return;
  const rounds=Math.log2(TN.cup.size);
  if(TN.round===rounds-1){finishCup();return;}
  const win=x=>x.w===0?x.a:x.b,lose=x=>x.w===0?x.b:x.a;
  const next=[];for(let i=0;i<r.length;i+=2)next.push({a:win(r[i]),b:win(r[i+1]),w:null,sc:[0,0]});
  if(TN.round===rounds-2)TN.third={a:lose(r[0]),b:lose(r[1]),w:null,sc:[0,0]};
  TN.rounds.push(next);TN.round++;
  if(!yourMatch())settleRound();
}
function finishCup(){
  TN.done=true;const f=TN.rounds[TN.rounds.length-1][0];const win=x=>x.w===0?x.a:x.b,lose=x=>x.w===0?x.b:x.a;
  TN.podium=[win(f),lose(f),TN.third?win(TN.third):null];
  const i=TN.podium.findIndex(p=>p&&p.you);TN.place=i>=0?i+1:0;
  if(TN.place===1){bump('tenka');checkAch();}
  if(TN.place===1){try{const t=JSON.parse(localStorage.getItem('oni-titles')||'{}');t[TN.cup.id]=(t[TN.cup.id]||0)+1;localStorage.setItem('oni-titles',JSON.stringify(t));}catch(e){}}
}
function playYourMatch(){
  const y=yourMatch();if(!y)return;const x=y.m;const youA=x.a.you;const you=youA?x.a:x.b,opp=youA?x.b:x.a;
  const fmt=y.third?T_FMT_TOP4:fmtFor(TN.round);TN.cur={x,youA};
  level=TN.cup.lvl[Math.min(TN.round,TN.cup.lvl.length-1)];cpuMem={hold:0,bits:0,gap:false};
  mode='tourney';M=mkMatch('tourney',0,[you.kit,opp.kit],TN.cup.map,Object.assign({pal:[you.pal,opp.pal]},fmt));
  lastEv=0;endShown=false;show(null);$('quit').hidden=false;auInit();musicStart();
}
function tourneyEnd(){
  const x=TN.cur.x;const youWon=M.winner===0;const wi=TN.cur.youA?(youWon?0:1):(youWon?1:0);
  x.w=wi;x.sc=TN.cur.youA?M.wins.slice():[M.wins[1],M.wins[0]];
  if(!youWon&&!(TN.third&&x===TN.third))TN.out=!(TN.round===Math.log2(TN.cup.size)-2);
  mode='bracket';M=null;musicStop();settleRound();
  if(!TN.done&&!yourMatch()){while(!TN.done)settleRound();}
  renderBracket();show('p-bracket');
}
function bmHTML(x,live){
  const row=(p,i)=>{if(!p)return `<div class="pl"><span class="nm">TBD</span></div>`;const w=x.w===i;
    return `<div class="pl${w?' w':''}${p.you?' you':''}"><span data-k="${p.kit}" data-p="${p.pal}"></span><span class="nm">${p.seed?p.seed+'. ':''}${esc(p.name)}<span class="rt">${p.rating}</span></span><span class="sc">${x.w===null?'':x.sc[i]}</span></div>`;};
  return `<div class="bm${live?' live':''}">${row(x.a,0)}${row(x.b,1)}</div>`;
}
function fillPortraits(root){root.querySelectorAll('span[data-k]').forEach(s=>{const c=portraitEl2(s.dataset.k,+s.dataset.p);s.replaceWith(c);});}
function renderBracket(){
  const c=TN.cup,p=cupPayout(c),rounds=Math.log2(c.size);
  $('br-title').textContent=c.name;$('br-kicker').textContent='Tenka, '+usd(c.entry)+' entry';
  $('br-clock').innerHTML=TN.cup.prize?`Champion wins<b>${TN.cup.prize}</b>Weekly Free Cup`:`Champion wins<b>${usd(p.first)}</b>2nd and 3rd ${usd(p.second)}`;
  const y=yourMatch();const nx=$('br-next');nx.innerHTML='';
  if(TN.done){
    const pl=TN.place;const prize=pl===1?p.first:pl===2?p.second:pl===3?p.third:0;
    nx.innerHTML=`<div><b>${pl===1?'Champion of the '+esc(c.name)+'!':pl?'You finished '+(pl===2?'2nd':'3rd')+'.':'Tournament over.'}</b><br>`+
      (prize?`You won <b style="color:var(--gold)">${usd(prize)}</b> (demo).`:'The bracket is complete. Enter again to take another shot.')+`</div>`;
    const again=document.createElement('button');again.className='arc gold';again.type='button';again.textContent='Enter again';again.onclick=()=>enterCup(c);
    const back=document.createElement('button');back.className='arc alt';back.type='button';back.textContent='All cups';back.onclick=openTourney;
    const r=document.createElement('div');r.className='row';r.append(again,back);nx.appendChild(r);
    if(pl===1)SFX.win();
  } else if(y){
    const x=y.m,you=x.a.you?x.a:x.b,opp=x.a.you?x.b:x.a;const fmt=y.third?T_FMT_TOP4:fmtFor(TN.round);
    const stage=y.third?'Match for 3rd place':roundName(TN.round,c.size);
    const v=document.createElement('div');v.className='vs';v.append(portraitEl2(you.kit,you.pal));
    v.insertAdjacentHTML('beforeend',`<div><b>${stage}</b><br>You vs ${esc(opp.name)} (${esc(fname(opp.kit,opp.pal))}), rating ${opp.rating}.<br>${fmt.need===3?'Best of 5':'Best of 3'}, rounds 30% faster.</div>`);
    v.appendChild(portraitEl2(opp.kit,opp.pal));nx.appendChild(v);
    const go=document.createElement('button');go.className='arc gold';go.type='button';go.textContent='Fight';go.onclick=playYourMatch;nx.appendChild(go);
  } else {nx.innerHTML='<div>Waiting for the other matches...</div>';}
  const br=$('bracket');let h='';
  for(let ri=0;ri<rounds;ri++){const r=TN.rounds[ri];const count=c.size/Math.pow(2,ri+1);
    h+=`<div class="bcol"><h4>${roundName(ri,c.size)}${ri>=rounds-2?', Bo5':''}</h4><div class="bms">`;
    for(let k=0;k<count;k++){const x=r&&r[k];h+=x?bmHTML(x,y&&y.m===x):bmHTML({a:null,b:null,w:null,sc:[0,0]},false);}
    h+='</div></div>';}
  br.innerHTML=h;
  const th=$('br-third');th.innerHTML='';
  if(TN.third){th.innerHTML=`<div><h4>Match for 3rd place, Bo5</h4>${bmHTML(TN.third,y&&y.m===TN.third)}</div>`;}
  if(TN.done&&TN.podium){const pod=document.createElement('div');pod.className='podium small';
    [1,0,2].forEach(ix=>{const q=TN.podium[ix];const d=document.createElement('div');d.className='pod p'+(ix+1);
      if(q){d.appendChild(portraitEl2(q.kit,q.pal));d.insertAdjacentHTML('beforeend',`<div class="nm">${esc(q.name)}</div><div class="blk"><span class="n">#${ix+1}</span><span class="pz">${usd([p.first,p.second,p.third][ix])}</span></div>`);}
      pod.appendChild(d);});th.appendChild(pod);}
  fillPortraits(br);fillPortraits(th);
  const alive=new Set();const last=TN.rounds[TN.rounds.length-1];for(const x of last){if(x.w===null){alive.add(x.a&&x.a.id);alive.add(x.b&&x.b.id);}else alive.add((x.w===0?x.a:x.b).id);}
  const ps=$('br-players');if(ps&&TN.players){const t=document.createElement('table');t.className='lbt';
    t.innerHTML='<thead><tr><th>Seed</th><th></th><th>Player</th><th class="hide-m">Rank</th><th class="num">Rating</th><th class="num hide-s">W-L</th><th class="num">Status</th></tr></thead>';
    const tb=document.createElement('tbody');for(const q of TN.players){const tr=document.createElement('tr');tr.className=q.you?'me':'';tr.innerHTML=`<td class="pos">${q.seed}</td>`;
      const td=document.createElement('td');td.appendChild(portraitEl2(q.kit,q.pal));tr.appendChild(td);
      const st=TN.done?(TN.podium&&TN.podium.indexOf(q)>=0?['1st','2nd','3rd'][TN.podium.indexOf(q)]:'Out'):(alive.has(q.id)?'In':'Out');
      tr.insertAdjacentHTML('beforeend',`<td class="who">${esc(q.name)}</td><td class="hide-m">${rankChip(q.rating)}</td><td class="num">${q.rating}</td><td class="num hide-s">${q.w}-${q.l}</td><td class="num ${st==='Out'?'loss':'win'}">${st}</td>`);tb.appendChild(tr);}
    t.appendChild(tb);ps.innerHTML='<h3>Players</h3>';const wrap=document.createElement('div');wrap.className='lbwrap';wrap.appendChild(t);ps.appendChild(wrap);}
}


/* ===================== TRAINING MODE ===================== */
const TR={skin:null,dummy:'stand',hb:true,meter:true,kit:'oni',last:null,hist:[],lastBits:-1,dmg:0,shownDmg:0,idle:0,prevSt:'idle'};
function trainingDummyKits(){return FIGHTERS.map(f=>f.kit);}
function startTraining(){
  auInit();SFX.select();mode='training';
  M=mkMatch('training',0,[SEL.kit,TR.kit],SEL.map,{need:99,pal:[myPal(SEL.kit),TR.kit==='oni'?1-myPal(SEL.kit):0],skins:[SEL.kit==='oni'?TR.skin:null,null]});M.scene='fight';M.sceneT=0;M.f.forEach((f,i)=>{f.skin=M.skins[i];});
  cpuMem={hold:0,bits:0,gap:false};lastEv=0;endShown=false;TR.last=null;TR.hist=[];TR.dmg=0;TR.shownDmg=0;TR.idle=0;
  show(null);$('quit').hidden=false;$('trbar').hidden=false;renderTrBar();musicStop();
}
function renderTrBar(){
  document.querySelectorAll('#trbar [data-dm]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.dm===TR.dummy?'true':'false'));
  $('tr-kit').textContent='Dummy: '+CH[TR.kit].name;$('tr-skin').hidden=SEL.kit!=='oni';$('tr-skin').textContent='Skin: '+({null:'standard',kin:'Kin-Oni',kongo:'Kongo-Oni'})[TR.skin];$('tr-hb').textContent='Hitboxes '+(TR.hb?'on':'off');$('tr-mt').textContent='Meter '+(TR.meter?'full':'normal');
  $('tr-hb').setAttribute('aria-pressed',TR.hb?'true':'false');$('tr-mt').setAttribute('aria-pressed',TR.meter?'true':'false');
}
document.querySelectorAll('#trbar [data-dm]').forEach(b=>b.onclick=()=>{TR.dummy=b.dataset.dm;cpuMem={hold:0,bits:0,gap:false};SFX.select();renderTrBar();b.blur();});
$('tr-kit').onclick=()=>{const ks=trainingDummyKits();TR.kit=ks[(ks.indexOf(TR.kit)+1)%ks.length];startTraining();};
$('tr-skin').onclick=()=>{const o=[null,'kin','kongo'];TR.skin=o[(o.indexOf(TR.skin)+1)%3];startTraining();};
$('tr-hb').onclick=()=>{TR.hb=!TR.hb;renderTrBar();$('tr-hb').blur();};
$('tr-mt').onclick=()=>{TR.meter=!TR.meter;renderTrBar();$('tr-mt').blur();};
$('tr-reset').onclick=()=>{if(!M)return;const k=M.kits;M.f=[mkFighter(k[0],96,1),mkFighter(k[1],224,-1)];M.proj=[];TR.dmg=0;TR.shownDmg=0;$('tr-reset').blur();};
$('tr-exit').onclick=()=>{$('trbar').hidden=true;toTitle();};
function dummyInput(){
  const d=M.f[1],p=M.f[0];const away=p.x<d.x?IN.R:IN.L;
  switch(TR.dummy){
    case 'crouch':return IN.D;
    case 'block':{const low=p.st==='kick'&&p.atk==='sweep';const over=p.air&&(p.st==='punch'||p.st==='kick');return away|(low&&!over?IN.D:0);}
    case 'jump':return frameN%50<3?IN.U:0;
    case 'poke':{if(Math.abs(p.x-d.x)>40)return p.x<d.x?IN.L:IN.R;return frameN%55<2?IN.P:0;}
    case 'cpu':return cpuInput(M,1,cpuMem,1);
    default:return 0;
  }
}
function moveInfo(f){
  const c=CH[f.ch];
  if(f.st==='punch'||f.st==='kick'){const a=c[f.atk]||c[f.st];const names={punch:'Attack',kick:'Kick',cpunch:'Crouch attack',sweep:'Sweep'};
    return{n:names[f.atk]||f.st,s:a.s+1,a:a.a,r:a.r,adv:(BLOCKSTUN[f.atk]||7)-(a.a-1+a.r),p:a.low?'low':f.over?'overhead':'mid'};}
  if(f.st==='special'){const sp=c.special;const fd=fdef(f.ch);return{n:fd.mv[0],s:(sp.at||sp.from||1)+1,a:sp.act||(sp.type==='proj'?'proj':'-'),r:sp.len-(sp.at||0),adv:null,p:sp.type};}
  if(f.st==='super')return{n:'Oni Wrath (super)',s:SUPER.startup+1,a:SUPER.active,r:SUPER.len-SUPER.startup-SUPER.active,adv:BLOCKSTUN.super-(SUPER.active-1+SUPER.len-SUPER.startup-SUPER.active),p:'invulnerable start'};
  if(f.st==='throw')return{n:'Throw',s:THROW.s+1,a:THROW.a,r:THROW.r,adv:null,p:'beats block'};
  return null;
}
function trainingTick(mine){tutTick();
  const p=M.f[0],d=M.f[1];
  if(TR.meter){p.meter=100;}
  if(p.st!==TR.prevSt&&['punch','kick','special','super','throw'].includes(p.st))TR.last=moveInfo(p);
  TR.prevSt=p.st;
  if(mine!==TR.lastBits){TR.lastBits=mine;if(mine){const fw=p.face>0?IN.R:IN.L,bk=p.face>0?IN.L:IN.R;let s='';
    if(mine&IN.U)s+='U';if(mine&IN.D)s+='D';if(mine&fw)s+='F';if(mine&bk)s+='B';
    const btn=[[IN.P,'A'],[IN.K,'K'],[IN.S,'C'],[IN.T,'T']].filter(([b])=>mine&b).map(x=>x[1]).join('+');
    TR.hist.unshift((s||'')+(s&&btn?' ':'')+btn);if(TR.hist.length>10)TR.hist.pop();}}
  if(d.stun>0||d.st==='hurt'||d.st==='grabbed'){TR.idle=0;TR.dmg=d.mhp-d.hp;TR.shownDmg=TR.dmg;}
  else{TR.idle++;if(TR.idle>50&&d.hp<d.mhp){d.hp=d.mhp;TR.dmg=0;}}
  if(p.stun===0&&p.hp<p.mhp*0.5&&TR.idle>50)p.hp=p.mhp;
}
function hitboxOf(f){
  const c=CH[f.ch];
  if((f.st==='punch'||f.st==='kick')){const a=c[f.atk]||c[f.st];if(f.t>a.s&&f.t<=a.s+a.a){const R=a.reach*GEO;return{x1:Math.min(f.x+f.face*4*GEO,f.x+f.face*R),x2:Math.max(f.x+f.face*4*GEO,f.x+f.face*R),y1:f.y-(a.y+a.h)*GEO,y2:f.y-a.y*GEO};}}
  if(f.st==='super'&&f.t>SUPER.startup&&f.t<=SUPER.startup+SUPER.active){const R=SUPER.reach*GEO;return{x1:Math.min(f.x-f.face*6,f.x+f.face*R),x2:Math.max(f.x-f.face*6,f.x+f.face*R),y1:f.y-(SUPER.y+SUPER.h)*GEO,y2:f.y-SUPER.y*GEO};}
  if(f.st==='throw'&&f.t>THROW.s&&f.t<=THROW.s+THROW.a){const R=((c.w+18)/2)*GEO+THROW.range;return{x1:Math.min(f.x,f.x+f.face*R),x2:Math.max(f.x,f.x+f.face*R),y1:f.y-c.h*GEO*0.7,y2:f.y-c.h*GEO*0.2};}
  const sp=c.special;if(f.st==='special'&&sp.type==='staff'&&f.t>sp.at&&f.t<=sp.at+sp.act)return{x1:Math.min(f.x+f.face*6*GEO,f.x+f.face*sp.reach*GEO),x2:Math.max(f.x+f.face*6*GEO,f.x+f.face*sp.reach*GEO),y1:f.y-(sp.y+sp.h)*GEO,y2:f.y-sp.y*GEO};
  return null;
}
function drawTraining(m){if(TUT.on)return;
  if(TR.hb){for(const f of m.f){const b=box(f);ctx.strokeStyle='rgba(80,160,255,.9)';ctx.lineWidth=1/3;ctx.strokeRect(Math.round(b.x1)+0.5,Math.round(b.y1)+0.5,Math.round(b.x2-b.x1),Math.round(b.y2-b.y1));
      const h=hitboxOf(f);if(h){ctx.fillStyle='rgba(255,60,60,.35)';ctx.fillRect(h.x1,h.y1,h.x2-h.x1,h.y2-h.y1);ctx.strokeStyle='rgba(255,60,60,.95)';ctx.strokeRect(Math.round(h.x1)+0.5,Math.round(h.y1)+0.5,Math.round(h.x2-h.x1),Math.round(h.y2-h.y1));}}
    for(const p of m.proj){ctx.strokeStyle='rgba(255,60,60,.95)';ctx.strokeRect(Math.round(p.x-p.r)+0.5,Math.round(p.y-p.r)+0.5,Math.round(p.r*2),Math.round(p.r*2));}}
  rect(98,40,124,38,'rgba(10,5,6,.78)');
  txt('TRAINING',160,46,6,'#FFB000',null);
  const L=TR.last;
  if(L){txt(L.n.toUpperCase(),160,55,6,'#F3E9E4',null);
    txt(`START ${L.s}  ACTIVE ${L.a}  REC ${L.r}`,160,64,5,'#C9A9A2',null);
    txt((L.adv==null?'':(L.adv>=0?'ON BLOCK +'+L.adv:'ON BLOCK '+L.adv)+'  ')+String(L.p).toUpperCase(),160,72,5,L.adv!=null&&L.adv<0?'#FF8A80':'#2EC4B6',null);}
  else txt('USE A MOVE TO SEE ITS FRAMES',160,62,5,'#C9A9A2',null);
  if(TR.shownDmg>0){txt('COMBO DAMAGE',270,50,5,'#C9A9A2',null);txt(String(TR.shownDmg),270,62,12,'#FFB000','#1A0506');}
  rect(4,44,34,6+TR.hist.length*9,'rgba(10,5,6,.6)');
  TR.hist.forEach((h,i)=>txt(h,8,50+i*9,5,i===0?'#FFE08A':'#C9A9A2',null,'left'));
}


/* ===================== CONTROLS PAGE ===================== */
let CTAB='kb';
function K(...ks){return ks.map(k=>k==='/'?'<span>or</span>':k==='+'?'<span>+</span>':k==='then'?'<span>then</span>':`<kbd${k.length>3?' class="w"':''}>${k}</kbd>`).join('');}
function renderControls(){
  document.querySelectorAll('#help [data-ctab]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.ctab===CTAB?'true':'false'));
  const body=$('ctl-body');
  const row=(keys,title,desc,tag)=>`<div class="crow"><div class="keys">${keys}</div><div class="cdo"><b>${title}${tag||''}</b><span>${desc}</span></div></div>`;
  const tag=(c,t)=>`<span class="tg ${c}">${t}</span>`;
  if(CTAB==='kb'){
    body.innerHTML=`<div class="cgroups">
      <div class="cgroup"><h3>MOVE</h3>
        ${row(K('A','D','/','←','→'),'Walk','Toward or away from your opponent.')}
        ${row(K('W','/','↑','/','Space'),'Jump','Kaze can jump again in the air. Hayate glides while you hold jump.')}
        ${row(K('S','/','↓'),'Crouch','Ducks under high attacks.')}
        ${row(K('D','D','/','A','A'),'Dash','Tap forward or back twice, quickly.')}
      </div>
      <div class="cgroup"><h3>ATTACK</h3>
        ${row(K('J'),'Attack','Fast, reaches mid height.')}
        ${row(K('K'),'Kick','Slower and harder.')}
        ${row(K('S','+','K'),'Sweep','Knocks the opponent down.',tag('low','LOW'))}
        ${row(K('W','then','J','/','K'),'Jump-in','Any attack in the air.',tag('over','OVERHEAD'))}
        ${row(K('L'),'Curse','The special move of your fighter. Costs half the meter.')}
      </div>
      <div class="cgroup"><h3>DEFEND</h3>
        ${row(K('Hold back'),'Block','Stops high and mid attacks. There is no guard button.')}
        ${row(K('S','+','back'),'Crouch block','Stops lows. Overheads still hit you.')}
        ${row(K('I','/','J','+','K'),'Throw','Grabs an opponent who is blocking.',tag('beat','BEATS BLOCK'))}
        ${row(K('I'),'Escape a throw','Press throw right after you are grabbed.')}
      </div>
      <div class="cgroup"><h3>SUPER</h3>
        ${row(K('S','+','L'),'Oni Wrath','Needs a full meter. The meter reads SUPER when it is ready. Invulnerable at the start, 26 damage.')}
        ${row(K('Z','X','C','V'),'Other keys','Attack, kick, curse and throw, if you prefer the left hand.')}
        ${row(K('Esc'),'Quit or go back','Leaves a match, or closes a menu page.')}
      </div>
    </div>
    <div class="cgroup cspec"><h3>CURSE MOVES BY FIGHTER</h3><div class="specs" id="ctl-specs"></div></div>`;
  } else {
    body.innerHTML=`<div class="phone">
      <div class="pdiag" aria-hidden="true">
        <div class="dp"><span></span><div class="k">▲</div><span></span><div class="k">◀</div><div class="k">▼</div><div class="k">▶</div></div>
        <div class="bt"><div class="k" style="background:rgba(193,18,31,.6)">ATTACK</div><div class="k" style="background:rgba(47,111,224,.5)">KICK</div><div class="k" style="background:rgba(46,196,182,.35)">THROW</div><div class="k" style="background:rgba(255,106,0,.5)">CURSE</div></div>
      </div>
      <div class="cgroup"><h3>ON YOUR PHONE</h3>
        ${row(K('◀','▶'),'Walk, and block','Hold away from your opponent to block.')}
        ${row(K('▲'),'Jump','Attack in the air for an overhead.')}
        ${row(K('▼'),'Crouch','Hold ▼ and away to block lows.')}
        ${row(K('▼','+','KICK'),'Sweep',tag('low','LOW'))}
        ${row(K('THROW'),'Throw','Beats block. Tap it right after you are grabbed to escape.')}
        ${row(K('▼','+','CURSE'),'Super','With a full meter.')}
        ${row(K('◀','◀','/','▶','▶'),'Dash','Double tap.')}
      </div>
    </div>`;
  }
  const sp=$('ctl-specs');if(sp){FIGHTERS.forEach(fd=>{const d=document.createElement('div');d.className='spec';d.appendChild(portraitEl2(fd.kit));
    d.insertAdjacentHTML('beforeend',`<div><b>${esc(CH[fd.kit].name)}</b><i>${esc(fd.mv[0])}</i>. ${esc(fd.mv[1])}</div>`);sp.appendChild(d);});}
}
document.querySelectorAll('#help [data-ctab]').forEach(b=>b.onclick=()=>{CTAB=b.dataset.ctab;SFX.select();renderControls();});
function openControls(){auInit();SFX.select();CTAB=document.body.classList.contains('touch')?'ph':'kb';renderControls();show('help');$('help').scrollTop=0;}


/* ===================== BOSS: ENMA ===================== */
DB.boss=[];
function bossLocal(){try{return JSON.parse(localStorage.getItem('oni-boss')||'{"kills":0,"best":0}');}catch(e){return{kills:0,best:0};}}
function bossTotal(){const n=DB.boss.reduce((a,d)=>a+(d.kills|0),0);return DB.state==='ok'?n:bossLocal().kills;}
function bossLevel(){return Math.min(50,1+bossTotal());}
function bossMods(L){return{hp:Math.min(2.2,1+0.03*(L-1)),dmg:Math.min(1.6,1+0.015*(L-1))};}
function bossAI(L){return Math.min(3.4,1+(L-1)*0.08);}
function myBossKills(){const d=DB.me&&DB.boss.find(x=>x.id===DB.me);return d?d.kills|0:bossLocal().kills;}
async function recordBossKill(L){
  const loc=bossLocal();loc.kills++;loc.best=Math.max(loc.best,L);try{localStorage.setItem('oni-boss',JSON.stringify(loc));}catch(e){}
  if(DB.db&&DB.me){const d=DB.boss.find(x=>x.id===DB.me)||{kills:0,best:0};try{await DB.db.collection('boss').doc(DB.me).set({kills:(d.kills|0)+1,best:Math.max(d.best|0,L),ts:Date.now()});}catch(e){}}
}
function renderBoss(){
  const L=bossLevel(),md=bossMods(L);
  $('bs-clock').innerHTML=`Level<b>${L}</b>stronger after every defeat`;
  $('bs-fi').innerHTML=`<span class="tbadge t3" style="background:linear-gradient(#FF6A3C,#8E1015);color:#FFF2E0;border-color:#FF6A00">BOSS</span><h3>Enma, King of Hell</h3>`+
    `<div>Judge of the dead. Every time a player defeats him, anywhere, he returns one level stronger for everyone.</div><div class="lvl">LEVEL ${L}</div>`+
    `<div><span class="mv">Hellfire:</span> a huge fireball. His iron club outreaches every fighter.</div>`;
  const a=document.createElement('div');a.className='acts';
  const go=document.createElement('button');go.className='arc boss';go.type='button';go.textContent='Challenge Enma as '+CH[owns(SEL.kit)?SEL.kit:'oni'].name;go.onclick=startBoss;
  const pick=document.createElement('button');pick.className='arc alt';pick.type='button';pick.textContent='Change fighter';pick.onclick=()=>{openSelect('cpu');$('sel-note').innerHTML='Pick your fighter, then go back to <strong>Challenge Enma</strong>.';};
  a.append(go,pick);$('bs-fi').appendChild(a);
  showcase($('bs-cv'),'enma',2,0);
  $('bs-stats').innerHTML=`<div class="lb-stat"><b class="w">x${md.hp.toFixed(2)}</b>Health</div><div class="lb-stat"><b class="w">x${md.dmg.toFixed(2)}</b>Damage</div>`+
    `<div class="lb-stat s"><b>${bossTotal()}</b>Defeats by the community</div><div class="lb-stat d"><b>${myBossKills()}</b>Your defeats of Enma</div>`;
  const sec=$('bs-slayers');const list=DB.boss.filter(d=>d.kills>0).sort((a,b)=>b.best-a.best||b.kills-a.kills).slice(0,20);
  if(!list.length){sec.innerHTML='<h3>Enma Slayers</h3><div class="lb-empty">Nobody has defeated Enma yet. Be the first name on this wall.</div>';return;}
  resolveNames(list.map(d=>d.id));
  sec.innerHTML='<h3>Enma Slayers</h3><div class="lbwrap"><table class="lbt"><thead><tr><th>#</th><th>Player</th><th class="num">Highest level beaten</th><th class="num">Defeats</th></tr></thead><tbody>'+
    list.map((d,i)=>`<tr class="${d.id===DB.me?'me':''}"><td class="pos">${i+1}</td><td class="who">${esc(nameOf(d.id))}</td><td class="num">${d.best|0}</td><td class="num">${d.kills|0}</td></tr>`).join('')+'</tbody></table></div>';
}
function openBoss(){auInit();SFX.select();renderBoss();show('p-boss');$('p-boss').scrollTop=0;}
function startBoss(){
  auInit();SFX.fight();const L=bossLevel();const kit=owns(SEL.kit)?SEL.kit:'oni';
  level=bossAI(L);cpuMem={hold:0,bits:0,gap:false};mode='boss';TR.bossL=L;
  M=mkMatch('boss',0,[kit,'enma'],2,{need:2,pal:[myPal(kit),0],mods:[{hp:1,dmg:1},bossMods(L)]});
  lastEv=0;endShown=false;show(null);$('quit').hidden=false;musicStart();
}


/* ===================== LANDING PAGE ===================== */
const DEMO={i:0,mem:{hold:0,bits:0,gap:false},pairs:[['aka','ao'],['kin','kongo'],['ao','kin'],['kongo','aka']]};
function startDemo(){
  const pr=DEMO.pairs[DEMO.i%DEMO.pairs.length];DEMO.i++;
  mode='demo';cpuMem={hold:0,bits:0,gap:false};DEMO.mem={hold:0,bits:0,gap:false};
  M=mkMatch('demo',0,['oni','oni'],1,{pal:[0,1],skins:pr});M.scene='intro';M.sceneT=0;M.f.forEach((f,i)=>{f.skin=pr[i];});lastEv=0;
}
function demoTick(){if(mode==='demo'&&M&&M.scene==='matchEnd'&&M.sceneT>150)startDemo();}
function leaveLanding(){auInit();SFX.select();enterVillage();}
function renderLanding(){
  const ev=document.getElementById('ld-event');if(ev){ev.hidden=!EVENT;if(EVENT)ev.innerHTML=`<b>YOKAI NIGHT</b> October event: ghost fire in the village and double fun. Ends ${new Date(EVENT.until).toISOString().slice(0,10)}.`;}
  const fb=document.getElementById('ld-founders');if(fb)fb.innerHTML=`<b>FOUNDERS</b> The first 200 accounts get the numbered <b>Genesis Oni</b>. ${foundersLeft()} of 200 left.`;
  const F=[['⚔','1v1 for the pot','Same stake, winner takes the pot minus a 5% fee. 2v2, 3v3 and new modes are coming.'],
    ['🏆','Tenka tournaments','8 and 16 player brackets. The champion takes 55% of the pot. The last four play best of 5.'],
    ['👹','Enma, the community boss','Every time any player beats him, he comes back one level stronger for everyone.'],
    ['🔥','Two cauldrons','Every match fills them. The top 100 of each 2-week season split the Season Cauldron, and the Curse Cauldron is airdropped to 20 players every week.'],
    ['💎','Seasons and Mythic skins','2-week seasons. Climb from Ashigaru to Oni Lord. The top 50 earn gold or diamond Oni skins that can never be bought.'],
    ['⚖','Skill, not wallets','Every fighter has the same strength, tested over thousands of fights. You buy style, never power.'],
    ['⚡','Coming soon','God tier Raijin and Fujin, and the PvE Final Boss: $1-2 a try, every defeat locks the Curse Bag into $ONI liquidity.']];
  $('ld-feats').innerHTML=F.map(([i,b,t])=>`<div class="ld-feat"><i aria-hidden="true">${i}</i><b>${b}</b>${t}</div>`).join('');
  const r=$('ld-roster');r.innerHTML='';
  FIGHTERS.forEach(fd=>{const d=document.createElement('div');d.className='ld-f';d.appendChild(portraitEl2(fd.kit));
    d.insertAdjacentHTML('beforeend',`<span>${esc(CH[fd.kit].name)}</span><small>${esc(fd.mv[0])}</small>`);r.appendChild(d);});
}
$('ld-play').onclick=leaveLanding;$('ld-play2').onclick=leaveLanding;
/* ===================== HOW TO PLAY ===================== */
let HOW_BACK='p-title';
function openHow(from){auInit();SFX.select();HOW_BACK=from||'p-title';renderHow();show('p-how');$('p-how').scrollTop=0;}
function renderHow(){
  const S=[];const sec=(id,t,html)=>S.push({id,t,html});
  const tab=(head,rows)=>`<table class="htab"><thead><tr>${head.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  sec('goal','The goal',`<p>Two fighters, one arena. Knock your opponent out to win a round. A normal match is <b>best of 3</b>: the first to win <b>2 rounds</b> wins. Each round lasts <b>60 seconds</b>. If time runs out, the fighter with more health left, in percent, wins the round.</p>
    <p><b>Knockout</b> is one round, no second chances. In tournaments, rounds are <b>30% faster</b> and the last four play <b>best of 5</b>.</p>`);
  sec('keys','Buttons',tab(['Action','Keyboard','Phone'],[
    ['Walk','A / D or arrows','◀ ▶'],['Jump','W, ↑ or Space','▲'],['Crouch','S or ↓','▼'],['Attack','J','ATTACK'],['Kick','K','KICK'],['Curse (special)','L','CURSE'],
    ['Throw','I, or J and K together','THROW'],['Block','Hold back','Hold ◀ or ▶ away'],['Crouch block','S + back','▼ + away'],['Sweep','S + K','▼ + KICK'],
    ['Dash','Tap forward or back twice','Double tap ◀ or ▶'],['Super','S + L with a full meter','▼ + CURSE'],['Other keys','Z attack, X kick, C curse, V throw','']]));
  sec('attacks','Attacks and heights',`<p>Every attack hits at a height. Reading heights is how you break a defense.</p>`+tab(['Move','Height','How to block it'],[
    ['Attack (J)','High','Stand block. <b>Crouching dodges it completely.</b>'],['Kick (K)','Mid','Stand or crouch block'],['Crouch attack (S+J)','Mid','Stand or crouch block'],
    ['Sweep (S+K)','Low, knocks down','Only a crouch block'],['Any attack in the air','Overhead','Only a stand block'],['Curse moves','Mostly mid','See each fighter'],['Throw','Unblockable','Escape it, see Defense'],['Super','Mid','Stand or crouch block, heavy chip']]));
  sec('defense','Defense',`<p><b>Block</b> by holding away from your opponent while they attack. There is no guard button. Hold down and away to block low.</p>
    <p><b>Chip damage:</b> a blocked hit still does 25% of its damage, 30% for supers.</p>
    <p><b>Guard Break:</b> a thin line under your health shows your guard. Every block fills it. Block too much in a row, about five kicks, and your guard breaks: you are stunned and open. The line empties again after a short break from blocking.</p>
    <p><b>Throws</b> beat blocking. You cannot be thrown while you are being hit, in the air, or already stunned. When you are grabbed, press throw right away to <b>escape</b>. If both players throw at the same moment, nobody gets thrown.</p>`);
  sec('meter','Meter, curses and super',`<p>The CURSE meter fills when you land hits, a little when you are hit, and a little when your attacks are blocked.</p>
    <p><b>Curse</b> is your fighter's special move and costs <b>half</b> the meter. At full meter the label changes to SUPER.</p>
    <p><b>Oni Wrath</b> is the super for every fighter: down and curse with a full meter. It is invulnerable at the start, lunges forward and does <b>26 damage</b>.</p>`+
    tab(['Fighter','Curse move'],FIGHTERS.map(fd=>[esc(CH[fd.kit].name),`<b>${esc(fd.mv[0])}</b>. ${esc(fd.mv[1])}`])));
  sec('modes','Modes',tab(['Mode','What it is'],[
    ['Practice','Fight the CPU for free. Best of 3 or Knockout.'],['Training','Hitboxes, frame data, input history and a dummy you control.'],['Play 1v1','Real stakes against another player. Create a match or join with a code.'],
    ['Tenka','Tournaments: Ronin Cup, Daimyo Cup and Shogun Cup, each on its own arena.'],['Enma','The community boss. Every win anywhere makes him one level stronger.'],['Coming soon','PvE Final Boss ($1-2 a try), God tier fighters, 2v2, 3v3 and new seasonal modes.']]));
  sec('stakes','Stakes and fees',`<p>Both players put in the same stake. The winner takes the pot minus a <b>5% game fee</b>. Part of that fee fills the cauldrons: <b>1.5%</b> of every pot goes to the Season Cauldron and <b>0.5%</b> to the Curse Cauldron.</p>
    `+tab(['Arena','Stake per player'],MAPS.filter(mp=>!mp.tourney).map((mp,i)=>[esc(mp.name),i===0?'Free, $0.50 or $3':mp.id==='launchpad'?'$100, Launch Bonus Mode for the first weeks after launch':mp.stake?usd(mp.stake):'No limit, $50 to $500, Legendary fighter owners only']))+
    `<p>Leaving a match or disconnecting counts as a loss.</p>`);
  sec('tourney','Tournaments',`<p>Pay the entry, get seeded by rating so the strongest meet late, and win every match. The two semifinal losers play once more for 3rd place.</p>`+
    tab(['Cup','Entry','Players','Champion'],CUPS.map(c=>[c.name,usd(c.entry),String(c.size),usd(cupPayout(c).first)]))+
    `<p>Prizes are 90% of all entries: <b>55%</b> to the champion, <b>17.5%</b> each to 2nd and 3rd. The other 10% is a 5% game fee, 3% to the Season Cauldron and 2% to the weekly pot.</p>`);
  sec('ranked','Ranks and rating',`<p>Everyone starts at a rating of <b>1000</b>. Beating a stronger player moves you more, and your first 10 matches move faster. Each rank has three divisions, III to I.</p>`+
    tab(['Rank','From rating'],RANKS.map(r=>[r.n,r.lord?'The top 50 rated players of the season':String(r.min)])));
  sec('season','Seasons and prizes',`<p><b>Season points</b> decide the prizes. A win gives 10 points times the arena tier: Summit 1, Temple 2, Yomi 3, Colosseum and Launchpad 4. A loss gives the tier once. Free matches give half. Beating the same opponent again counts less: full, half, a quarter, then a tenth.</p><p><b>Activity bonus:</b> 3 ranked matches in a day makes it an active day. Each active day in the last 7 adds 5% to all your season points, up to <b>x1.35</b> if you play every day.</p>
    <p>Seasons last <b>2 weeks</b>. To qualify, play <b>5 ranked matches against 3 different opponents</b>. The <b>top 100</b> split the Season Cauldron when the season ends.</p>`+
    tab(['Place','Share'],BRACKETS.map(x=>[x.from===x.to?'#'+x.from:'#'+x.from+' to #'+x.to,x.pct+'% each']))+
    `<p><b>Mythic skins:</b> when the season ends, the top 10 Oni Lords get the diamond <b>Kongo-Oni</b>, places 11 to 50 get the gold <b>Kin-Oni</b>. They can never be bought.</p>`);
  sec('cauldrons','The Curse Cauldron airdrop',`<p>Every <b>Sunday at 20:00 UTC</b> the Curse Cauldron is airdropped to <b>20 players</b>, 5% each. You earn <b>airdrop points</b> from ranked matches, one per opponent per day (up to 5 a day from free matches), plus <b>one free point a day</b>. No purchase is needed.</p>`);
  sec('fighters','Fighters and tiers',`<p><b>Every fighter has the same strength</b>, tested over thousands of fights. Buying a fighter gets you a new way to play and style, never an advantage.</p>`+
    tab(['Tier','Price','What you get'],[['Starter','Free','Aka or Ao Oni'],['Rare','$20','A fighter with a unique move'],['Epic','$89','Plus its own K.O. finisher'],['Legendary','$200','Plus gold aura, badge and access to the Oni Colosseum'],['Mythic','Earned','Kin-Oni and Kongo-Oni, top 50 of a season']]));
  sec('enma','Enma',`<p>Enma is the King of Hell. Each time any player defeats him, he returns <b>one level stronger for everyone</b>: more health, more damage and a sharper mind. The Enma Slayers wall shows who beat him at the highest level.</p>`);
  sec('fair','Fair play',`<p>Results are decided by the game server, not by either player's device. Leaving or disconnecting loses the match. In tournaments you have 60 seconds to press Ready. Collusion and multiple accounts to farm points are against the rules, and repeated wins against the same opponent earn fewer points.</p>
    <p>This is a demo: no real money moves yet.</p>`);
  $('how-toc').innerHTML=S.map(s=>`<a href="#how-${s.id}">${s.t}</a>`).join('');
  $('how-body').innerHTML=S.map(s=>`<section id="how-${s.id}"><h3 class="hs">${s.t}</h3>${s.html}</section>`).join('');
  document.querySelectorAll('#how-toc a').forEach(a=>a.onclick=e=>{e.preventDefault();const el=document.getElementById(a.getAttribute('href').slice(1));if(el)el.scrollIntoView({behavior:'smooth',block:'start'});});
}
$('ld-how').onclick=()=>openHow('p-landing');
$('b-how').onclick=()=>openHow('p-title');
$('hw-back').onclick=()=>{SFX.select();show(HOW_BACK);};


/* ===================== ONI VILLAGE (playable) ===================== */
const VIL={active:false,x:560,y:460,dir:'up',step:0,walk:0,t:0,cam:[0,0],bg:null,peers:[],rp:{},emote:null,et:0,prev:0,pubT:0,last:'',incoming:null,dismissed:{},prompt:null,myPeer:null,chal:null};
const EMOTES=['GG!','BOW','FIGHT ME!','NICE!'];
const NPCST=[];
function npcInit(){if(NPCST.length||typeof NPCS==='undefined')return;for(const n of NPCS)NPCST.push(Object.assign({},n,{x:n.hx,y:n.hy,tx:n.hx,ty:n.hy,wait:Math.random()*200,dir:1,walk:0,say:null,sayT:0,li:0,next:300+Math.random()*600}));}
function npcTick(){for(const n of NPCST){
  if(n.wait>0){n.wait--;n.walk=0;}else{const dx=n.tx-n.x,dy=n.ty-n.y,d=Math.hypot(dx,dy);
    if(d<1){n.wait=90+Math.random()*240;const a=Math.random()*6.28,r=Math.random()*n.r;n.tx=n.hx+Math.cos(a)*r;n.ty=n.hy+Math.sin(a)*r*0.6;}
    else{const sp=0.45;const nx=n.x+dx/d*sp,ny=n.y+dy/d*sp;if(!vilBlocked(nx,ny)){n.x=nx;n.y=ny;n.walk=1;n.dir=dx<0?-1:1;}else{n.tx=n.hx;n.ty=n.hy;}}}
  if(n.sayT>0)n.sayT--;else if(--n.next<=0){n.say=n.lines[Math.floor(Math.random()*n.lines.length)];n.sayT=200;n.next=600+Math.random()*900;}}}
function myLook(){const pr=myProfile();const k=pr&&pr.main&&CH[pr.main]?pr.main:SEL.kit;return k==='oni'?(SEL.opal===4?'genesis':SEL.opal?'ao':'aka'):k;}
function peerName(p){return p.isMe?(myProfile()?myProfile().name:'You'):p.by?nameOf(p.by):'Guest';}
function peerRank(by){const e=DB.board&&by?DB.board.map.get(by):null;const r=e?e.rating:1000;return{t:rankName(r,e&&e.lord).toUpperCase(),c:(e&&e.lord?RANKS[5]:rankOf(r)).c};}
function enterVillage(){
  if(!VIL.bg&&typeof buildVillageBG==='function')VIL.bg=buildVillageBG();
  auInit();VIL.active=true;mode='village';M=null;musicStop();
  const tb=document.getElementById('trbar');if(tb)tb.hidden=true;$('quit').hidden=true;
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('on'));document.body.classList.remove('menu','landing');
  $('vil-menu').hidden=false;refreshProfileBtn();
}
function classicMenu(){VIL.active=false;$('vil-menu').hidden=true;vilPublish(true);mode='title';M=null;show('p-title');refreshTitle();}
function vilOpen(id){
  SFX.select();
  const go={dojo:()=>{openSelect('cpu');$('sel-note').innerHTML='Fight the CPU, or press <strong>Training mode</strong>.';},gate:openBoss,lords:()=>{DB.tab='season';show('p-board');renderBoard();$('p-board').scrollTop=0;},
    market:()=>openStore(),shrine:openTourney,home:openProfile,arena:()=>openSelect('online'),cauldrons:openCauldrons,
    champs:()=>{DB.tab='season';show('p-board');renderBoard();},cell:()=>{openStore();STORE.myth='boss';renderStore();}}[id];
  if(go)go();
}
function vilNearPeer(){let best=null,bd=34;for(const p of VIL.peers){if(p.isMe||!p.presence||!p.presence.v)continue;const r=VIL.rp[p.peer];if(!r)continue;const d=Math.hypot(r.x-VIL.x,(r.y-VIL.y)*1.4);if(d<bd){bd=d;best=p;}}return best;}
async function vilChallenge(p){
  if(!NET.avail){VIL.toast='Challenges work when the game is opened on claude.ai.';VIL.toastT=180;return;}
  const code=genCode();VIL.chal={to:p.peer,code,t:Date.now()};vilPublish(true);
  SEL.ctx='online';SEL.map=0;SEL.low=0;SEL.fmt='bo3';if(!owns(SEL.kit))SEL.kit='oni';
  await createMatch(code);
}
async function vilAccept(){
  const inc=VIL.incoming;if(!inc)return;VIL.dismissed[inc.code]=1;VIL.incoming=null;SFX.coin();
  SEL.ctx='online';if(!owns(SEL.kit))SEL.kit='oni';NET.kit=SEL.kit;vilPublish(true,true);
  if(await netJoin(inc.code,false)){NET.joinTimer=setTimeout(()=>{if(NET.role==='pending'){netLeave();enterVillage();VIL.toast='That challenge is no longer open.';VIL.toastT=180;}},6000);}
}
function vilPublish(force,away){
  if(!NET.lobby)return;const now=performance.now();
  const v=(!VIL.active||away||mode!=='village')?null:{x:Math.round(VIL.x),y:Math.round(VIL.y),d:VIL.dir,l:myLook(),e:VIL.emote,et:VIL.et,w:VIL.walk>0?1:0,ch:VIL.chal&&Date.now()-VIL.chal.t<30000?{to:VIL.chal.to,code:VIL.chal.code}:null};
  const s=JSON.stringify(v);if(!force&&(s===VIL.last||now-VIL.pubT<60))return;VIL.last=s;VIL.pubT=now;try{NET.lobby.presence({v});}catch(e){}
}
function vilInput(bits){
  const edge=bits&~VIL.prev;VIL.prev=bits;
  let dx=((bits&IN.R)?1:0)-((bits&IN.L)?1:0),dy=((bits&IN.D)?1:0)-((bits&IN.U)?1:0);
  if(dx||dy){const len=Math.hypot(dx,dy);const sp=1.7;const nx=VIL.x+dx/len*sp,ny=VIL.y+dy/len*sp;
    if(!vilBlocked(nx,VIL.y))VIL.x=nx;if(!vilBlocked(VIL.x,ny))VIL.y=ny;
    VIL.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'left':'right'):(dy<0?'up':'down');VIL.walk++;}else VIL.walk=0;
  VIL.step=Math.floor(VIL.walk/8)%2;
  if((edge&IN.P)||VIL.wantE){VIL.wantE=false;vilAct();}
  if(edge&IN.K){vilEmote((EMOTES.indexOf(VIL.emote)+1)%EMOTES.length);}
  if(edge&IN.S){classicMenu();}
}
function vilEmote(i){misProgress('emote');VIL.emote=EMOTES[i];VIL.et=Date.now();SFX.select();vilPublish(true);}
function vilAct(){const pr=VIL.prompt;if(!pr)return;if(pr.kind==='npc'){const n=pr.npc;n.li=(n.li+1)%n.lines.length;n.say=n.lines[n.li];n.sayT=260;n.next=900;SFX.select();return;}if(pr.kind==='accept')vilAccept();else if(pr.kind==='zone')vilOpen(pr.id);else if(pr.kind==='peer')vilChallenge(pr.peer);}
function vilTick(bits){
  VIL.t++;vilInput(bits);
  if(VIL.emote&&Date.now()-VIL.et>3500)VIL.emote=null;
  for(const p of VIL.peers){const v=p.presence&&p.presence.v;if(p.isMe||!v)continue;const r=VIL.rp[p.peer]||(VIL.rp[p.peer]={x:v.x,y:v.y});r.x+=(v.x-r.x)*0.25;r.y+=(v.y-r.y)*0.25;}
  const me=VIL.peers.find(p=>p.isMe&&p.sameTab);VIL.myPeer=me?me.peer:null;
  VIL.incoming=null;
  for(const p of VIL.peers){const v=p.presence&&p.presence.v;if(p.isMe||!v||!v.ch||v.ch.to!==VIL.myPeer||VIL.dismissed[v.ch.code])continue;VIL.incoming={from:p,code:v.ch.code};}
  let pr=null;
  if(VIL.incoming)pr={kind:'accept',text:'Accept '+peerName(VIL.incoming.from)+"'s challenge"};
  else{const np=vilNearPeer();if(np)pr={kind:'peer',peer:np,text:'Challenge '+peerName(np)};
    else{let nn=null,nd=22;for(const n of NPCST){const d=Math.hypot(n.x-VIL.x,(n.y-VIL.y)*1.3);if(d<nd){nd=d;nn=n;}}
      if(nn)pr={kind:'npc',npc:nn,text:'Talk to '+nn.name};
      else for(const z of VZ){if(Math.hypot(z.x-VIL.x,(z.y-VIL.y)*1.3)<24){pr={kind:'zone',id:z.id,text:z.label};break;}}}}
  VIL.prompt=pr;
  const cx=Math.max(0,Math.min(VW-480,VIL.x-240)),cy=Math.max(110,Math.min(VH-270,VIL.y-195));VIL.cam=[cx,cy];
  vilPublish(false);
  if(VIL.toastT>0)VIL.toastT--;
}
function renderVillage(){
  const g=ctx;g.setTransform(2,0,0,2,0,0);g.imageSmoothingEnabled=false;const [cx,cy]=VIL.cam;
  if(VIL.bg)g.drawImage(VIL.bg,-Math.round(cx),-Math.round(cy));
  const b=DB.board;vilCauldron(g,328+VOX-cx,276+VOY-cy,'season',VIL.t,usd(b?b.pool:0));vilCauldron(g,392+VOX-cx,276+VOY-cy,'curse',VIL.t,usd(b?b.drop:0));
  const ents=[{x:VIL.x,y:VIL.y,d:VIL.dir,l:myLook(),s:VIL.step,me:true,name:myProfile()?myProfile().name:'You',by:DB.me,e:VIL.emote}];
  for(const p of VIL.peers){const v=p.presence&&p.presence.v;if(p.isMe||!v)continue;const r=VIL.rp[p.peer]||v;ents.push({x:r.x,y:r.y,d:v.d||'down',l:v.l||'aka',s:v.w?Math.floor(VIL.t/8)%2:0,name:peerName(p),by:p.by,e:v.e&&Date.now()-(v.et||0)<3500?v.e:null});}
  const online=VIL.peers.filter(p=>p.presence&&p.presence.v).length+(VIL.peers.some(p=>p.isMe&&p.sameTab&&p.presence&&p.presence.v)?0:1);
  vilSignboard(g,Math.round(318+VOX-cx),Math.round(420+VOY-cy),online);
  const b2=DB.board;const champs=b2&&b2.list?b2.list.slice(0,5).map(p=>nameOf(p.id)):[];
  if(typeof vilChampsBig==='function'){vilChampsBig(g,-cx,-cy,champs,SEASON.n);vilPrison(g,-cx,-cy,usd(0),VIL.t);vilSitters(g,VOX-cx,VOY-cy,VIL.t);}
  const all=ents.concat(NPCST.map(n=>({npc:n,x:n.x,y:n.y})));all.sort((a,b)=>a.y-b.y);
  for(const e of all){if(e.npc)npcDraw(g,e.npc,Math.round(e.x-cx),Math.round(e.y-cy),VIL.t);else chibiDraw(g,Math.round(e.x-cx),Math.round(e.y-cy),e.d,e.l,e.s,VIL.t);}
  g.textAlign='center';g.textBaseline='middle';
  for(const n of NPCST){if(n.sayT<=0||!n.say)continue;const x=Math.round(n.x-cx),y=Math.round(n.y-cy);g.font='7px "Press Start 2P"';
    const bw=Math.max(g.measureText(n.say).width,g.measureText(n.name).width)+12;g.fillStyle='rgba(243,233,228,.96)';g.fillRect(x-bw/2,y-50,bw,24);g.fillRect(x-2,y-26,4,3);
    g.fillStyle='#8A5A00';g.fillText(n.name,x,y-44);g.fillStyle='#1A0506';g.fillText(n.say,x,y-34);}
  g.textAlign='center';g.textBaseline='middle';
  for(const e of ents){const x=Math.round(e.x-cx),y=Math.round(e.y-cy);const rk=peerRank(e.by);
    g.font='7px "Press Start 2P"';const w=Math.max(g.measureText(e.name).width,g.measureText(rk.t).width)+10;
    g.fillStyle='rgba(10,5,6,.82)';g.fillRect(x-w/2,y-58,w,21);g.fillStyle=e.me?'#2EC4B6':'#F3E9E4';g.fillText((clanOf(e.by)?'['+clanOf(e.by)+'] ':'')+e.name,x,y-52);g.fillStyle=rk.c;g.fillText(rk.t,x,y-43);
    if(e.e){g.font='8px "Press Start 2P"';const bw=g.measureText(e.e).width+12;g.fillStyle='#F3E9E4';g.fillRect(x-bw/2,y-78,bw,15);g.fillRect(x-2,y-63,4,3);g.fillStyle='#1A0506';g.fillText(e.e,x,y-70);}}
  if(EVENT&&EVENT.id==='yokai'){g.fillStyle='rgba(40,0,70,.16)';g.fillRect(0,0,480,270);
    for(let k=0;k<16;k++){const wx=(k*173)%VW,wy=240+(k*97)%420;const sx=wx-cx,sy=wy-cy+Math.sin((VIL.t+k*30)*0.05)*3;if(sx<-10||sx>490||sy<-10||sy>280)continue;
      g.fillStyle='rgba(120,200,255,.25)';g.beginPath();g.arc(sx,sy,6,0,6.28);g.fill();g.fillStyle=k%2?'#9BD8FF':'#C49BFF';g.fillRect(Math.round(sx)-2,Math.round(sy)-3,4,5);g.fillStyle='#FFFFFF';g.fillRect(Math.round(sx)-1,Math.round(sy)-2,2,2);}
    g.font='7px "Press Start 2P"';g.textAlign='center';g.fillStyle='rgba(10,5,6,.85)';g.fillRect(170,6,140,14);g.fillStyle='#C49BFF';g.fillText('YOKAI NIGHT EVENT',240,14);}
  // top-left: village and players online
  g.fillStyle='rgba(10,5,6,.85)';g.fillRect(6,6,104,26);g.textAlign='left';g.font='8px "Press Start 2P"';g.fillStyle='#2EC4B6';g.fillText('ONI VILLAGE',12,14);g.font='7px "Press Start 2P"';g.fillStyle='#C9A9A2';g.fillText(online+' online',12,25);
  // minimap
  const mmx=(VIL.x-cx)>240?6:376,mmy=mmx===6?40:22;
  if(VIL.bg){g.fillStyle='rgba(10,5,6,.88)';g.fillRect(mmx,mmy,98,66);g.drawImage(VIL.bg,0,0,VW,VH,mmx+2,mmy+2,94,62);
    const mx=x=>mmx+2+x/VW*94,my=y=>mmy+2+y/VH*62;for(const e of ents){g.fillStyle=e.me?'#2EC4B6':'#F3E9E4';g.fillRect(Math.round(mx(e.x))-1,Math.round(my(e.y))-1,3,3);}
    g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1;g.strokeRect(mx(cx)+0.5,my(cy)+0.5,480/VW*94,270/VH*62);}
  // prompt
  const pr=VIL.prompt;const touch=document.body.classList.contains('touch');
  if(pr){g.font='8px "Press Start 2P"';const key=touch?'ATK':'E';const tw=g.measureText(pr.text).width;const kw=g.measureText(key).width+8;const w=tw+kw+22;const x0=240-w/2,y0=236;
    g.fillStyle='rgba(10,5,6,.92)';g.fillRect(x0,y0,w,22);g.fillStyle=pr.kind==='accept'?'#FF6A3C':'#FFB000';g.fillRect(x0,y0,w,2);
    g.fillStyle='#F3E9E4';g.fillRect(x0+6,y0+5,kw,13);g.fillStyle='#1A0506';g.textAlign='center';g.fillText(key,x0+6+kw/2,y0+12);g.fillStyle='#F3E9E4';g.textAlign='left';g.fillText(pr.text,x0+kw+14,y0+12);}
  if(VIL.incoming){g.font='8px "Press Start 2P"';const t=peerName(VIL.incoming.from)+' challenges you to a free 1v1!';const w=g.measureText(t).width+20;g.fillStyle='rgba(90,10,14,.92)';g.fillRect(240-w/2,40,w,20);g.fillStyle='#FFE08A';g.textAlign='center';g.fillText(t,240,50);}
  if(VIL.toastT>0&&VIL.toast){g.font='7px "Press Start 2P"';const w=g.measureText(VIL.toast).width+16;g.fillStyle='rgba(10,5,6,.9)';g.fillRect(240-w/2,210,w,16);g.fillStyle='#F3E9E4';g.textAlign='center';g.fillText(VIL.toast,240,218);}
  // help line
  g.font='7px "Press Start 2P"';g.textAlign='right';g.fillStyle='rgba(243,233,228,.75)';
  g.fillText(touch?'PAD: walk   ATTACK: enter   KICK: emote':'WASD: walk   E: enter   1-4: emotes   M: menu',474,264);
  g.setTransform(3,0,0,3,0,0);
}
window.addEventListener('keydown',e=>{if(mode!=='village')return;
  if(e.code==='KeyE'){VIL.wantE=true;e.preventDefault();}
  else if(/^Digit[1-4]$/.test(e.code)){vilEmote(+e.code.slice(5)-1);}
  else if(e.code==='KeyM'||e.code==='Escape'){classicMenu();}});
$('vil-menu').onclick=classicMenu;
function gfxLabel(){const b=document.getElementById('b-gfx');if(b)b.textContent='Graphics: '+(GFX.hd?'HD':'Classic');}
$('b-comfort').onclick=()=>{COMFORT.on=!COMFORT.on;try{localStorage.setItem('oni-comfort',COMFORT.on?'on':'off');}catch(e){}$('b-comfort').textContent='Comfort: '+(COMFORT.on?'On':'Off');SFX.select();};
$('b-comfort').textContent='Comfort: '+(COMFORT.on?'On':'Off');
$('b-gfx').onclick=()=>{GFX.hd=!GFX.hd;try{localStorage.setItem('oni-gfx',GFX.hd?'hd':'classic');}catch(e){}gfxLabel();SFX.select();};gfxLabel();
$('b-tut').onclick=startTutorial;$('b-arcade').onclick=()=>{if(!owns(SEL.kit))SEL.kit='oni';startArcade();};$('b-missions').onclick=openMissions;
$('mis-back').onclick=()=>{SFX.select();show('p-title');};$('cl-back').onclick=()=>{SFX.select();show('p-title');};$('b-clans').onclick=openClans;$('ko-back').onclick=()=>{SFX.select();show('p-end');};
$('how-tut').onclick=startTutorial;
$('quit').addEventListener('click',()=>{TUT.on=false;tutShow();ARC.on=false;});
document.querySelectorAll('#vbar [data-go]').forEach(b=>b.onclick=()=>{b.blur();auInit();const k=b.dataset.go;
  ({online:()=>{SFX.select();openSelect('online');},tourney:openTourney,boss:openBoss,cpu:()=>{SFX.select();openSelect('cpu');},
    board:()=>{SFX.select();DB.tab='season';show('p-board');renderBoard();$('p-board').scrollTop=0;},store:()=>{SFX.select();openStore();},
    cauldrons:openCauldrons,profile:openProfile,how:()=>openHow('p-title'),missions:openMissions,clans:openClans})[k]();});
$('b-village').onclick=enterVillage;


/* ===================== WAVE 1: TUTORIAL, ARCADE, MISSIONS, ACHIEVEMENTS, CLANS, REFERRALS, EVENTS ===================== */
const LS={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}};
const STATS=LS.get('oni-stats',{wins:0,games:0,perfect:0,arcade:0,tenka:0,tut:0,emotes:0});
function bump(k,n){STATS[k]=(STATS[k]||0)+(n||1);LS.set('oni-stats',STATS);}
/* ---- event: Yokai Night runs through October ---- */
const EVENT=(()=>{const d=new Date();return d.getUTCMonth()===9?{id:'yokai',name:'Yokai Night',until:Date.UTC(d.getUTCFullYear(),10,1)}:null;})();
/* ---- interactive tutorial ---- */
const TUT={on:false,i:0,x0:0,hold:0};
const TUT_STEPS=[
 ['Walk forward','D or →','▶',f=>f.x>TUT.x0+28],
 ['Jump','W or ↑','▲',f=>f.air],
 ['Crouch','S or ↓','▼',f=>f.crouch&&!f.air],
 ['Attack (high)','J','ATTACK',f=>f.st==='punch'&&f.atk==='punch'],
 ['Kick (mid)','K','KICK',f=>f.st==='kick'&&f.atk==='kick'],
 ['Sweep (low): hold down and kick','S + K','▼ + KICK',f=>f.st==='kick'&&f.atk==='sweep'],
 ['Block: hold back while the dummy attacks','hold A or ←','hold ◀',(f,d)=>f.st==='block'],
 ['Throw: get close and grab','I, or J + K','THROW',f=>f.st==='throw'],
 ['Curse, your special move','L','CURSE',f=>f.st==='special'],
 ['Super: meter is full. Down and curse','S + L','▼ + CURSE',f=>f.st==='super']];
function startTutorial(){auInit();SFX.select();SEL.kit='oni';TR.dummy='stand';VIL.active=false;startTraining();TUT.on=true;TUT.i=0;TUT.hold=0;TUT.x0=M.f[0].x;tutShow();}
function tutShow(){const el=$('tut');if(!TUT.on){el.hidden=true;return;}el.hidden=false;const s=TUT_STEPS[TUT.i];const touch=document.body.classList.contains('touch');
  el.innerHTML=TUT.i>=TUT_STEPS.length?`<b>Tutorial complete!</b><span>You know every move. Try Arcade mode or a ranked 1v1.</span><button type="button" class="arc gold" id="tut-done">Finish</button>`:
    `<small>Step ${TUT.i+1} of ${TUT_STEPS.length}</small><b>${s[0]}</b><span>${touch?s[2]:s[1]}</span><i style="width:${TUT.i/TUT_STEPS.length*100}%"></i>`;
  const d=document.getElementById('tut-done');if(d)d.onclick=()=>{TUT.on=false;tutShow();toTitle();};}
function tutTick(){if(!TUT.on||!M||TUT.i>=TUT_STEPS.length)return;const f=M.f[0],d=M.f[1];const s=TUT_STEPS[TUT.i];
  TR.dummy=TUT.i===6?'poke':'stand';if(TUT.i===7&&Math.abs(f.x-d.x)>34)d.x=f.x+(d.x>f.x?30:-30);if(TUT.i===9)f.meter=100;if(TUT.i===8)f.meter=Math.max(f.meter,50);
  if(s[3](f,d)){TUT.hold++;if(TUT.hold>2){TUT.i++;TUT.hold=0;TUT.x0=f.x;SFX.coin();if(TUT.i>=TUT_STEPS.length){bump('tut');checkAch();}tutShow();}}else TUT.hold=0;}
/* ---- arcade mode: every fighter, then Enma ---- */
const ARC={on:false,i:0,list:[]};
function startArcade(){auInit();SFX.select();ARC.on=true;ARC.i=0;ARC.list=FIGHTERS.map(f=>f.kit).filter(k=>k!==SEL.kit).sort(()=>Math.random()-0.5).slice(0,6).concat(['enma']);arcadeMatch();}
function arcadeMatch(){const opp=ARC.list[ARC.i];vilPublish(true,true);mode='cpu';level=Math.min(3,Math.floor(ARC.i/2)+(opp==='enma'?1:0));cpuKit=opp;
  M=mkMatch('cpu',0,[SEL.kit,opp],[0,1,2,4,5,6,8][ARC.i%7],Object.assign({pal:[myPal(SEL.kit),opp==='oni'?1-myPal(SEL.kit):0]},FMTS.bo3));cpuMem={hold:0,bits:0,gap:false};lastEv=0;endShown=false;show(null);$('quit').hidden=false;musicStart();}
/* ---- daily missions (+1 airdrop point each) ---- */
const MIS_POOL=[['win2','Win 2 matches',2],['play3','Play 3 matches',3],['perfect','Win a round without taking a hit',1],['online','Play an online 1v1',1],['enma','Fight Enma',1],['emote','Use an emote in the village',1],['arcade','Beat 3 opponents in Arcade',3]];
function dayKeyNow(){return new Date().toISOString().slice(0,10);}
function todaysMissions(){const d=dayKeyNow();let h=0;for(const c of d)h=(h*31+c.charCodeAt(0))>>>0;const pool=[...MIS_POOL];const out=[];for(let i=0;i<3;i++){out.push(pool.splice(h%pool.length,1)[0]);h=(h*1103515245+12345)>>>0;}return out;}
function misState(){const s=LS.get('oni-mis',{});if(s.day!==dayKeyNow())return{day:dayKeyNow(),prog:{},done:[]};return s;}
function misProgress(id,n){const s=misState();const list=todaysMissions();const m=list.find(x=>x[0]===id);if(!m||s.done.includes(id))return;s.prog[id]=(s.prog[id]||0)+(n||1);
  if(s.prog[id]>=m[2]){s.done.push(id);SFX.coin();misReward(id);}LS.set('oni-mis',s);}
async function misReward(id){if(!DB.db||!DB.me)return;const doc=DB.tickets.find(t=>t.id===DB.me)||{};const mis=Object.assign({},doc.mis||{});const d=dayKeyNow();mis[d]=(mis[d]||[]).concat([id]);
  try{await DB.db.collection('tickets').doc(DB.me).set({days:doc.days||[],mis,ts:Date.now()});}catch(e){}}
const _freeTickets=freeTickets;
freeTickets=function(doc){const base=_freeTickets(doc);if(!doc||!doc.mis)return base;const since=lastDrop();let n=0;for(const [d,ids] of Object.entries(doc.mis))if(Date.parse(d+'T00:00:00Z')+86400000>since)n+=Math.min(3,(ids||[]).length);return base+n;};
/* ---- achievements ---- */
const ACH=[['first','First Blood','Win your first match',()=>STATS.wins>=1],['ten','Rising Oni','Win 10 matches',()=>STATS.wins>=10],['hundred','Demon','Win 100 matches',()=>STATS.wins>=100],
 ['student','Student','Finish the tutorial',()=>STATS.tut>=1],['flawless','Flawless','Win a round without taking a hit',()=>STATS.perfect>=1],['arcade','Arcade Legend','Beat Arcade mode',()=>STATS.arcade>=1],
 ['slayer','Enma Slayer','Beat Enma',()=>{const b=DB.boss&&DB.me&&DB.boss.find?DB.boss.find(x=>x.id===DB.me):null;return !!(b&&b.kills>0);}],['champ','Champion','Win a TENKA tournament',()=>STATS.tenka>=1],
 ['clan','Brotherhood','Join a clan',()=>!!(myProfile()&&myProfile().clan)],['founder','Founder','Be one of the first 200 accounts',()=>isFounder()],['lord','Oni Lord','Reach the top 50',()=>{const e=myEntry();return !!(e&&e.lord);}]];
function checkAch(){const got=LS.get('oni-ach',[]);let changed=false;for(const [id,n] of ACH.map(a=>[a[0],a[1]]))if(!got.includes(id)&&ACH.find(a=>a[0]===id)[3]()){got.push(id);changed=true;toast('Achievement unlocked: '+n);}if(changed)LS.set('oni-ach',got);return got;}
function toast(t){const el=$('toast');el.textContent=t;el.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>{el.hidden=true;},2600);}
/* ---- clans and referrals ---- */
const safeClan=t=>/^[A-Z0-9]{2,5}$/.test(t||'')?t:'';
function clanOf(id){const p=id&&DB.profiles[id];return p?safeClan(p.clan):'';}
function clanBoard(){const b=DB.board;const out={};if(!b)return[];for(const p of b.list){const c=clanOf(p.id);if(!c)continue;const o=out[c]||(out[c]={tag:c,pts:0,members:0,top:null});o.pts+=p.pts;o.members++;if(!o.top||p.pts>o.top.pts)o.top=p;}
  return Object.values(out).sort((a,b)=>b.pts-a.pts);}
function referralsOf(id){return Object.values(DB.profiles||{}).filter(p=>p&&p.ref===id).length;}
const REF0=(()=>{try{const q=new URLSearchParams(location.search);const r=q.get('ref');if(r&&/^[A-Za-z0-9_-]{4,64}$/.test(r))LS.set('oni-ref',r);return q;}catch(e){return null;}})();
function inviteBase(){return /claude\.ai|claudeusercontent|claude\.site/.test(location.hostname)||location.protocol==='file:'?'https://theonicurse.xyz/':location.origin+'/';}
/* ---- missions and achievements page ---- */
function openMissions(){auInit();SFX.select();renderMissions();show('p-missions');$('p-missions').scrollTop=0;}
function renderMissions(){const s=misState();const got=checkAch();
  const left=(()=>{const t=new Date();const n=Date.UTC(t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()+1);return fmtLeft(n-Date.now());})();
  let h=`<div class="mis-head"><h3>Today</h3><small>New missions in ${left}</small></div><div class="mis2">`+todaysMissions().map(([id,t,n])=>{const p=Math.min(n,s.prog[id]||0);const done=s.done.includes(id);
    return `<div class="mrow${done?' done':''}"><b>${t}</b><div class="mbar"><i style="width:${p/n*100}%"></i><span>${p} / ${n}</span></div><span class="rw">${done?'Done':'+1 point'}</span></div>`;}).join('')+'</div>';
  h+=`<div class="mis-head"><h3>Achievements</h3><small>${got.length} of ${ACH.length}</small></div><div class="achs2">`+
    ACH.map(([id,n,d])=>`<div class="ach${got.includes(id)?' got':''}" title="${d}"><span class="ic">${got.includes(id)?'&#10003;':'&#9679;'}</span><div><b>${n}</b><small>${d}</small></div></div>`).join('')+'</div>';
  const ref=DB.me?inviteBase()+'?ref='+encodeURIComponent(DB.me):'';
  h+=`<div class="mis-head"><h3>Invite friends</h3><small>+1 point per friend</small></div><div class="invite"><span>Friends invited <b>${DB.me?referralsOf(DB.me):0}</b></span>${ref?`<button type="button" class="arc" id="copy-ref">Copy invite link</button>`:'<span>Create an account to get your invite link.</span>'}</div>`;
  $('mis-body').innerHTML=h;const cr=document.getElementById('copy-ref');if(cr)cr.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(ref).then(()=>toast('Invite link copied'),()=>toast(ref));};}
/* ---- K.O. card: a shareable image of the finish ---- */
function koCard(){const me=mode==='guest'?1:0;const won=M&&M.winner===me;const c=document.createElement('canvas');c.width=960;c.height=540;const g=c.getContext('2d');g.drawImage($('cv'),0,0,960,540);
  g.fillStyle='rgba(10,5,6,.55)';g.fillRect(0,420,960,120);g.font='28px "Press Start 2P", monospace';g.textAlign='left';g.fillStyle=won?'#FFB000':'#F3E9E4';
  g.fillText(won?'K.O. VICTORY':'GOOD FIGHT',30,470);g.font='14px "Press Start 2P", monospace';g.fillStyle='#F3E9E4';g.fillText(fname(M.f[me].ch,palOf(M,me),M.f[me].skin)+' vs '+fname(M.f[1-me].ch,palOf(M,1-me),M.f[1-me].skin),30,505);
  g.textAlign='right';g.fillStyle='#D7262E';g.font='34px "Press Start 2P", monospace';g.fillText('ONI',930,475);g.font='11px "Press Start 2P", monospace';g.fillStyle='#C9A9A2';g.fillText('theonicurse.xyz',930,505);return c;}
function shareKO(){const c=koCard();const url=c.toDataURL('image/png');$('ko-img').src=url;show('p-ko');
  $('ko-native').hidden=!(navigator.canShare);$('ko-native').onclick=()=>{c.toBlob(b=>{const file=new File([b],'oni-ko.png',{type:'image/png'});if(navigator.canShare&&navigator.canShare({files:[file]}))navigator.share({files:[file],text:'ONI: The Curse You Choose. theonicurse.xyz'}).catch(()=>{});});};
  $('ko-copy').onclick=()=>{c.toBlob(b=>{try{navigator.clipboard.write([new ClipboardItem({'image/png':b})]).then(()=>toast('Image copied. Paste it in your post.'),()=>toast('Long-press or right-click the image to save it.'));}catch(e){toast('Long-press or right-click the image to save it.');}});};}



/* ===================== AFFILIATE ===================== */
const AFF={rate:0.01,rateHigh:0.015,highAt:100,months:6};
function affiliateStats(id){
  const refs=Object.entries(DB.profiles||{}).filter(([pid,p])=>p&&p.ref===id).map(([pid,p])=>({id:pid,p,since:p.created||0}));
  const n=refs.length,rate=n>=AFF.highAt?AFF.rateHigh:AFF.rate;const win=AFF.months*30*86400000;const by={};let vol=0,earn=0;
  for(const r of refs)by[r.id]={vol:0,earn:0,games:0};
  for(const mt of DB.matches){if(!(mt.stake>0))continue;for(const pid of [mt.a,mt.b]){const r=by[pid];if(!r)continue;const ref=refs.find(x=>x.id===pid);if((mt.ts||0)>ref.since+win)continue;
    r.vol+=mt.stake;r.games++;const e=mt.stake*2*rate;r.earn+=e;vol+=mt.stake;earn+=e;}}
  return{refs,by,n,rate,vol,earn,active:refs.filter(r=>by[r.id].games>0).length};
}
function renderAffiliate(sec){
  if(!DB.me){sec.innerHTML='<div class="lb-empty">Create an account to get your affiliate link.</div>';return;}
  const s=affiliateStats(DB.me);const link=inviteBase()+'?ref='+encodeURIComponent(DB.me);
  let h=`<div class="pf2-quick aff"><div><b>${s.n}</b>Players you brought</div><div><b>${s.active}</b>Active</div><div><b>${usd(s.vol)}</b>Their volume</div><div><b class="up">${usd(Math.round(s.earn))}</b>Your earnings (demo)</div></div>`;
  h+=`<div class="invite"><span>Your link: <b style="font-size:1em">${esc(link)}</b></span><button type="button" class="arc gold" id="aff-copy">Copy link</button></div>`;
  h+=`<div class="rsplit"><b>How it pays</b><span>${(s.rate*100).toFixed(1)}% of every pot your players play, for ${AFF.months} months after they join</span><span>1.5% once you bring ${AFF.highAt}+ players</span><span>It comes from the ONI fee: your players pay nothing extra</span><span>Paid out on-chain at launch</span></div>`;
  if(s.refs.length){h+=`<h4 class="pf2-h">Your players</h4><div class="lbwrap"><table class="lbt clean"><thead><tr><th>Player</th><th class="num">Matches</th><th class="num">Volume</th><th class="num">You earned</th></tr></thead><tbody>`+
    s.refs.map(r=>`<tr><td class="who"><button type="button" class="plink" data-pid="${esc(r.id)}">${esc(r.p.name||nameOf(r.id))}</button></td><td class="num">${s.by[r.id].games}</td><td class="num">${usd(s.by[r.id].vol)}</td><td class="num win">${usd(Math.round(s.by[r.id].earn))}</td></tr>`).join('')+'</tbody></table></div>';}
  else h+='<div class="lb-empty">No players yet. Share your link: you earn from every pot they play.</div>';
  sec.innerHTML=h;const c=document.getElementById('aff-copy');if(c)c.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(link).then(()=>toast('Affiliate link copied'),()=>toast(link));};
}

/* ===================== CLANS PAGE ===================== */
let CLAN_TAB='season',CLAN_SEL=null;
function clanWeek(){const since=lastDrop();const b=computeBoard(DB.matches.filter(x=>(x.ts||0)>=since));const out={};for(const p of b.list){const c=clanOf(p.id);if(!c)continue;const o=out[c]||(out[c]={tag:c,pts:0,members:0});o.pts+=p.pts;o.members++;}
  return Object.values(out).sort((a,b)=>b.pts-a.pts);}
function clanMembers(tag){return Object.entries(DB.profiles||{}).filter(([id,p])=>p&&safeClan(p.clan)===tag).map(([id,p])=>{const e=DB.board?DB.board.map.get(id):null;return{id,p,pts:e?e.pts:0,rating:e?e.rating:1000,lord:e&&e.lord};}).sort((a,b)=>b.pts-a.pts);}
function openClans(){auInit();SFX.select();CLAN_SEL=null;renderClans();show('p-clans');$('p-clans').scrollTop=0;}
function renderClans(){
  const me=myProfile();const my=me?safeClan(me.clan):'';const season=clanBoard(),week=clanWeek();const body=$('cl-body');
  const nextReset=new Date(lastDrop()+7*86400000);$('cl-clock').innerHTML=`Clan War resets in<b>${fmtLeft(nextReset-Date.now())}</b>Sundays 20:00 UTC`;
  let h='';
  if(my){const pos=season.findIndex(c=>c.tag===my);const c=season[pos];const mine=DB.me&&DB.board&&DB.board.map.get(DB.me);
    h+=`<div class="cl-mine"><div><span class="lb-kicker">Your clan</span><h3>[${my}]</h3></div><div class="pf2-quick"><div><b>${c?'#'+(pos+1):'-'}</b>Season rank</div><div><b>${c?c.pts:0}</b>Points</div><div><b>${clanMembers(my).length}</b>Members</div><div><b>${mine?mine.pts:0}</b>Your share</div></div>
      <div class="acts"><button class="arc" type="button" id="cl-view">View members</button><button class="arc alt" type="button" id="cl-leave">Leave clan</button></div></div>`;}
  else h+=`<div class="cl-mine"><div><span class="lb-kicker">No clan yet</span><h3>Create or join a clan</h3><small>Type a tag of 2 to 5 letters or numbers. If the clan exists you join it, if not you create it.</small></div>
      <div class="cl-join"><input class="nmin" id="cl-tag" maxlength="5" placeholder="e.g. COOK" aria-label="Clan tag"><button class="arc gold" type="button" id="cl-go">${me?'Join or create':'Create an account first'}</button></div></div>`;
  h+=`<div class="lb-tabs"><button class="lb-tab" type="button" data-ct="season" aria-pressed="${CLAN_TAB==='season'}">Season ranking</button><button class="lb-tab" type="button" data-ct="week" aria-pressed="${CLAN_TAB==='week'}">Clan War, this week</button></div>`;
  const list=CLAN_TAB==='week'?week:season;
  if(!list.length)h+=`<div class="lb-empty">${CLAN_TAB==='week'?'No clan points yet this week. Win ranked 1v1s to score for your clan.':'No clans yet. Be the first to create one.'}</div>`;
  else h+=`<div class="lbwrap"><table class="lbt clean"><thead><tr><th>#</th><th>Clan</th><th class="num">Members</th><th class="num">Points</th><th></th></tr></thead><tbody>`+
    list.map((c,i)=>`<tr class="${c.tag===my?'me':''}"><td class="pos">${i+1}</td><td class="who">[${esc(c.tag)}]</td><td class="num">${c.members}</td><td class="num">${c.pts}</td><td class="num"><button type="button" class="plink" data-clan="${esc(c.tag)}">Members</button></td></tr>`).join('')+'</tbody></table></div>';
  if(CLAN_SEL){const ms=clanMembers(CLAN_SEL);h+=`<h4 class="pf2-h">[${esc(CLAN_SEL)}] members</h4><div class="cl-members">`+ms.map(x=>`<div class="fr-row"><div class="fr-who"><b><span class="dot ${isOnline(x.id)?'on':''}"></span><button type="button" class="plink" data-pid="${esc(x.id)}">${esc(x.p.name||nameOf(x.id))}</button></b><small>${rankChip(x.rating,x.lord)} ${x.pts} points</small></div></div>`).join('')+'</div>';}
  body.innerHTML=h;wirePlayerLinks(body);
  body.querySelectorAll('[data-ct]').forEach(b=>b.onclick=()=>{CLAN_TAB=b.dataset.ct;renderClans();});
  body.querySelectorAll('[data-clan]').forEach(b=>b.onclick=()=>{CLAN_SEL=b.dataset.clan;renderClans();});
  const v=document.getElementById('cl-view');if(v)v.onclick=()=>{CLAN_SEL=my;renderClans();};
  const l=document.getElementById('cl-leave');if(l)l.onclick=async()=>{await patchProfile({clan:null});toast('You left ['+my+']');renderClans();};
  const go=document.getElementById('cl-go');if(go)go.onclick=async()=>{if(!me){openProfile();return;}const t=safeClan(($('cl-tag').value||'').toUpperCase().replace(/[^A-Z0-9]/g,''));if(!t){toast('Use 2 to 5 letters or numbers');return;}await patchProfile({clan:t});bump('clanjoin');checkAch();toast('Welcome to ['+t+']');renderClans();};
  const ti=document.getElementById('cl-tag');if(ti)ti.oninput=()=>{ti.value=ti.value.toUpperCase().replace(/[^A-Z0-9]/g,'');};
}

/* ===================== EVENTS -> SOUND + FX ===================== */
function processEvents(m){
  if(!m||!m.events)return;
  for(const e of m.events){if(e.id<=lastEv)continue;lastEv=e.id;
    switch(e.type){
      case 'round':SFX.taiko();setTimeout(()=>SFX.taiko(),180);break;
      case 'fight':SFX.fight();FX.shake=3;break;
      case 'swing':SFX.swing(e.a);break;
      case 'jump2':SFX.jump();sparks(e.x,e.y,5,['#F3E9E4','#C9A9A2']);break;
      case 'hit':{const heavy=e.a&1,combo=e.a>>1;SFX.hit(heavy);sparks(e.x,e.y,heavy?14:9,['#FFFFFF','#FFB000','#C1121F']);FX.shake=heavy?5:3;if(combo>=2)pop(combo+' HIT COMBO',e.x,e.y-18,'#FFB000');break;}
      case 'block':SFX.block();sparks(e.x,e.y,7,['#FFFFFF','#DDE3EE','#FFB000']);break;
      case 'special':{const kit=e.a>>1;SFX.special(kit);if(kit===2)FX.shake=4;pop(['CURSE!','STAFF STRIKE!','DRAGON FIRE!','FOX BLINK','SKY DIVE!','COUNTER STANCE','PHASE','HELLFIRE!'][kit]||'',e.x,e.y-14,'#FF6A00');break;}
      case 'gbreak':SFX.clash();SFX.hit(1);FX.shake=7;sparks(e.x,e.y,18,['#FFE08A','#FFFFFF','#FFB000']);pop('GUARD BREAK',e.x,e.y-14,'#FFE08A');break;
      case 'tech':SFX.block();sparks(e.x,e.y,10,['#FFFFFF','#DDE3EE']);pop('TECH',e.x,e.y-16,'#F3E9E4');break;
      case 'throw':SFX.hit(1);FX.shake=4;pop('THROW',e.x,e.y-18,'#FFB000');break;
      case 'dash':SFX.jump();sparks(e.x,e.y-2,5,['#C9A9A2','#8A6A5A']);break;
      case 'super':SFX.special(2);SFX.fight();FX.flash=10;FX.shake=6;FX.superT=40;pop('ONI WRATH',e.x,e.y-26,'#FFB000');break;
      case 'blink':sparks(e.x,e.y,12,['#7FE7FF','#FFFFFF','#C49BFF']);break;
      case 'counter':SFX.splash();sparks(e.x,e.y,16,['#7FE7FF','#9BF07A','#FFFFFF']);pop('COUNTER!',e.x,e.y-22,'#7FE7FF');FX.shake=5;break;
      case 'phase':sparks(e.x,e.y,10,['#9B59D0','#2EC4B6','#FFFFFF']);break;
      case 'clash':SFX.clash();sparks(e.x,e.y,14,['#FF6A00','#2EC4B6','#FFFFFF']);FX.shake=4;break;
      case 'ko':{SFX.ko();musicStop();FX.shake=10;FX.flash=8;sparks(e.x,e.y,26,['#FFFFFF','#FFB000','#C1121F']);
        const wf=m.f[e.a];const tier=wf?CH[wf.ch].tier:0;const final=m.wins&&m.wins[e.a]>=2;
        if(tier>=2&&final){FX.fin={x:e.x,y:e.y,t:0,tier,c:PAL[wf.ch][palOf(m,e.a)].main};if(tier===3){sparks(e.x,e.y,40,['#FFB000','#FFE08A','#FFFFFF']);setTimeout(()=>SFX.win(),300);}else SFX.clash();}
        break;}
      case 'time':case 'draw':SFX.taiko();musicStop();break;
      case 'win':SFX.win();break;
    }
  }
}

/* ===================== LOOP ===================== */
let acc=0,last=performance.now();
const titleF=[{ch:'oni',x:62,face:1},{ch:'oni',x:258,face:-1}].map(o=>Object.assign({y:GROUND,st:'idle',t:0,flash:0,air:false},o));
function render(m){
  if(mode==='village'){renderVillage();return;}
  const mapI=m?m.map:1;
  const sx=FX.shake?Math.round((Math.random()*2-1)*FX.shake):0,sy=FX.shake?Math.round((Math.random()*2-1)*FX.shake):0;
  G=ctx;ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#0A0506';ctx.fillRect(0,0,960,540);ctx.setTransform(3,0,0,3,0,0);ctx.imageSmoothingEnabled=false;
  if(m&&m.scene==='vs'){drawVS(m,m.sceneT);return;}
  if(BGHI[mapI]){ctx.setTransform(2,0,0,2,sx*3,sy*3);ctx.drawImage(BGHI[mapI],0,0);}else{ctx.setTransform(3,0,0,3,sx*3,sy*3);ctx.drawImage(BG[mapI],0,0);}
  ctx.setTransform(3,0,0,3,sx*3,sy*3);drawAmb(mapI);
  if(!m){
    titleF.forEach((f,i)=>drawFighter(f,frameN,i));
    const b=Math.round(Math.sin(frameN*0.05)*2);
    txt('ONI',160,30+b,34,'#D7262E','#1A0506');txt('THE CURSE YOU CHOOSE',160,54,7,'#F3E9E4','#1A0506');
    ctx.setTransform(3,0,0,3,0,0);return;
  }
  drawAura();const order=m.f[0].st==='hurt'?[0,1]:[1,0];order.forEach(i=>drawFighter(m.f[i],frameN,palOf(m,i)));
  m.proj.forEach(p=>drawProj(p,frameN,palOf(m,p.owner)));
  for(const s of FX.sparks)rect(s.x,s.y,s.life>8?2:1,s.life>8?2:1,s.c);
  ctx.setTransform(3,0,0,3,0,0);
  const me=mode==='guest'?1:0;if(mode!=='demo')hud(m,mode==='spectate'?-1:me);
  for(const p of FX.pops)txt(p.text,Math.max(48,Math.min(272,p.x)),p.y,7,p.c,'#1A0506');
  if(mode==='training')drawTraining(m);
  if(m.scene==='intro'){const nd=m.need||2,fin=nd>1&&m.wins[0]===nd-1&&m.wins[1]===nd-1;
    if(m.sceneT<72)txt(nd===1?'KNOCKOUT':fin?'FINAL ROUND':'ROUND '+m.round,160,70,fin||nd===1?18:20,fin||nd===1?'#FFB000':'#F3E9E4','#1A0506');
    if(m.sceneT<72&&nd===3&&m.round===1)txt('BEST OF 5',160,92,8,'#FFB000','#1A0506');
    if(m.sceneT>=72)txt('FIGHT!',160,74,26,'#D7262E','#1A0506');}
  if(m.scene==='ko'){
    if(m.winner<0)txt('DRAW',160,78,24,'#F3E9E4','#1A0506');
    else if(m.timer<=0&&m.f[1-m.winner].hp>0)txt('TIME',160,78,24,'#FFB000','#2A1300');
    else{const k=m.sceneT<12?1.6-m.sceneT*0.05:1;txt('K.O.',160,78,Math.round(34*k),'#D7262E','#FFB000');}
    if(m.sceneT>70&&m.winner>=0){txt(fname(m.f[m.winner].ch,palOf(m,m.winner))+' WINS',160,108,10,'#F3E9E4','#1A0506');if(m.perfect)txt('FLAWLESS',160,124,10,'#FFB000','#2A1300');}
  }
  if(m.scene==='matchEnd'){
    const sp=mode==='spectate',won=m.winner===me;
    txt(sp?fname(m.f[m.winner].ch,palOf(m,m.winner))+' WINS':(won?'YOU WIN':'YOU LOSE'),160,60,sp?14:20,won||sp?'#FFB000':'#D7262E','#1A0506');
    if(m.stake>0&&!sp){const p=payout(m.stake);txt(won?'+'+usd(p.win):'-'+usd(m.stake),160,84,11,won?'#2EC4B6':'#D7262E','#1A0506');}
    else if(m.perfect)txt('FLAWLESS VICTORY',160,86,9,'#F3E9E4','#1A0506');
    if(mode==='cpu'&&!won&&contT>0){const n=Math.ceil(contT/60)-1;txt('CONTINUE? '+Math.max(0,n),160,106,10,'#F3E9E4','#D7262E');}
  }
  if(FX.superT>0){FX.superT--;ctx.fillStyle='rgba(10,0,0,'+Math.min(0.35,FX.superT/60)+')';ctx.fillRect(0,0,W,H);}
  drawFinisher();
  if(FX.flash>0&&!COMFORT.on){ctx.fillStyle='rgba(255,255,255,'+(FX.flash/14)+')';ctx.fillRect(0,0,W,H);}
}
function loop(now){
  requestAnimationFrame(loop);
  const dt=Math.min(100,now-last);last=now;frameN++;
  document.body.classList.toggle('village',mode==='village');
  if(mode==='village'&&!document.body.classList.contains('menu')){acc+=dt;let n=0;while(acc>=1000/60&&n<5){vilTick(sampleInput());acc-=1000/60;n++;}if(n>=5)acc=0;}
  if(mode==='cpu'||mode==='host'||mode==='tourney'||mode==='training'||mode==='boss'||mode==='demo'){
    acc+=dt;
    while(M){const stepMs=M.slow>0?1000/60*2.5:1000/60;if(acc<stepMs)break;acc-=stepMs;
      const mine=mode==='demo'?cpuInput(M,0,DEMO.mem,2):sampleInput();const other=mode==='demo'?cpuInput(M,1,cpuMem,2):mode==='training'?dummyInput():(mode==='cpu'||mode==='tourney'||mode==='boss')?cpuInput(M,1,cpuMem,level):hostTick();
      step(M,[mine,other]);if(mode==='training')trainingTick(mine);if(M.slow>0)M.slow--;}
    if(mode==='host'&&M){hostPublish();if(M.scene==='matchEnd'&&!M.recorded){M.recorded=true;recordMatch(M);}}
    if(M){processEvents(M);
      if(M.scene==='matchEnd'&&M.sceneT>90&&!endShown)endPanel();
      if(mode==='cpu'&&M&&M.scene==='matchEnd'&&contT>0&&M.winner!==0){contT-=dt/16.67;if(contT<=0)toTitle();}
    }
    render(M);
  } else if(mode==='guest'||mode==='spectate'){
    guestTick(sampleInput());const m=interp();processEvents(M);
    if(M&&M.scene==='matchEnd'&&M.sceneT>90&&!endShown)endPanel();
    render(m||null);
  } else render(null);
  demoTick();if(M&&M.f)auraTick(M);updFx(M?M.map:1);
  if(document.body.classList.contains('menu')&&$('p-cauldron').classList.contains('on'))renderCauldrons();
  if(document.body.classList.contains('menu')){tickShowcases();tickTrophy();}
}
function boot(){buildAll();refreshTitle();refreshProfileBtn();renderLanding();startDemo();show('p-landing');requestAnimationFrame(loop);netInit();dbInit();}
if(document.fonts&&document.fonts.load){Promise.race([document.fonts.load('8px "Press Start 2P"'),new Promise(r=>setTimeout(r,1500))]).then(boot,boot);}else boot();
