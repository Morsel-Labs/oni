# ONI: The Curse You Choose

1v1 pixel fighting game στο browser, με χωριό (open world hub), ranked seasons, τουρνουά (TENKA), community boss (Enma), καζάνια και server για το **theonicurse.xyz**.

## Γρήγορο ξεκίνημα
```bash
npm install            # μόνο για τα τεστ
npm run build          # φτιάχνει dist/oni-fighter.html και server/public/index.html
npm test               # τεστ μηχανικών και ροής (28 πλήρεις αγώνες με CPU)
npm run server         # τρέχει τον server στο http://localhost:8080
```
Μπορείς να ανοίξεις και κατευθείαν το `dist/oni-fighter.html` στον browser. Τα online κομμάτια θέλουν είτε claude.ai είτε τον server.

## Δομή
```
game/
  sim.js        Η μάχη. Καθαρή, ντετερμινιστική, χωρίς DOM. Χαρακτήρες (CH, KITS), φυσική, hitboxes, AI του CPU.
  main.js       Όλο το υπόλοιπο παιχνίδι: rendering, ήχος, input, μενού, χωριό, online, leaderboard, market, τουρνουά.
  page.html     HTML και CSS. Τα %%ART%%, %%SIM%% και %%MAIN%% τα συμπληρώνει το build.
  art/
    hi.js       Οι χαρακτήρες σε υψηλή ανάλυση (σκελετός και στάσεις). Ένας renderer για μάχη, πορτρέτα και previews.
    arenas_hi.js  Οι αρένες (480x270).
    vil.js      Το χωριό: χάρτης, chibi, ταμπέλες, champions, κελί του boss.
    cauldhi.js  Τα καζάνια.
    gods2.js    God tier (Raijin, Fujin), μόνο ως preview για τώρα.
tools/build.js  Ενώνει τα παραπάνω σε ένα αρχείο HTML.
tests/          mech.js (μηχανικές μάχης), flow.js (ολόκληρα παιχνίδια με CPU).
server/         Ο game server. Δες server/README.md για το στήσιμο.
dist/           Το έτοιμο παιχνίδι μετά το build.
```

## Πώς δουλεύει
- **Μάχη**: `step(match, [input0, input1])` 60 φορές το δευτερόλεπτο, στο `sim.js`. Χωρίς τυχαιότητα, οπότε ίδια inputs δίνουν ίδιο αποτέλεσμα. Το rendering διαβάζει μόνο την κατάσταση.
- **Κλίμακα**: όλα τα hitboxes πολλαπλασιάζονται με το `GEO` (1.45). Τα γραφικά ζωγραφίζονται σε 480x270 και 1 μονάδα κόσμου = 1.5 px. Οι κινήσεις στο `hi.js` ζωγραφίζονται όσο ακριβώς φτάνει το hitbox.
- **Online**: το παιχνίδι ζητάει τρεις υπηρεσίες με `window.claude.use('room' | 'db' | 'user')`. Στο claude.ai τις δίνει το claude.ai. Στο theonicurse.xyz τις δίνει ο δικός μας server μέσω του `server/public/shim.js`, με την ίδια ακριβώς μορφή, οπότε το παιχνίδι δεν αλλάζει.
- **1v1**: ο host τρέχει τη μάχη και στέλνει την κατάσταση. Ο guest στέλνει μόνο inputs. (Φάση 2: η μάχη θα τρέχει στον server.)
- **Βάση (collections)**: `matches`, `profiles`, `boss`, `tickets` (airdrop points), `practice` (CPU streaks), `data/users/{id}/inv` (inventory). Κανόνες στο `server/src/rules.js`: κανείς δεν γράφει στα έγγραφα άλλου, κανείς δεν σβήνει matches.

## Πού αλλάζουν τα βασικά
| Τι | Πού |
|---|---|
| Χαρακτήρες, ζωή, ζημιά, κινήσεις | `sim.js` → `CH` |
| Αρένες και stakes | `main.js` → `MAPS` |
| Τουρνουά | `main.js` → `CUPS`, `TSPLIT` |
| Season (2 εβδομάδες), έπαθλα | `main.js` → `SEASON_START`, `BRACKETS`, `ELIG`, `paidPlaces` |
| Activity bonus | `main.js` → `ACT` |
| Ranks | `main.js` → `RANKS` |
| Founders (Genesis Oni) | `main.js` → `FOUNDER_CAP` |

## Κανόνες της ομάδας
1. **"Style, never power."** Ό,τι πουλιέται δεν δίνει πλεονέκτημα στις μάχες με λεφτά. Το balance είναι 48–53% σε όλα τα matchups.
2. **Αλλαγή στο `sim.js` = τρέχεις `npm test`** και ελέγχεις το balance.
3. Μετά από κάθε αλλαγή: `npm run build` και άνοιγμα του `dist/oni-fighter.html` σε desktop και κινητό.
4. Δουλεύουμε σε **branches** και κάνουμε **pull request** στο `main`.

## Λειτουργίες (Wave 1)
Διαδραστικό tutorial (10 βήματα), Arcade mode (6 αντίπαλοι + Enma), daily missions (airdrop points), achievements, clans (tag στο προφίλ, καρτέλα Clans), referrals (`?ref=ID`), bounty (+25 points για νίκη πάνω στον #1 σε rating), Weekly Free Cup, κάρτα K.O. για share, event Yokai Night (Οκτώβριος). Όλα στο `game/main.js`, ενότητα "WAVE 1".

## Γνωστά ανοιχτά θέματα
- Φάση 1: η μάχη των 1v1 τρέχει στον host. Πριν τα πραγματικά stakes πρέπει να τρέχει στον server.
- Η σύνδεση wallet είναι έτοιμη στον server (`/api/nonce`, `/api/wallet`) αλλά όχι ακόμα στο κουμπί "Connect wallet".
- God tier και PvE Final Boss (Shuten-dōji) υπάρχουν μόνο ως teasers.
- Wave 2: Season Pass, Spectate, combo trials. Το "Find match" θέλει τη μάχη στον server.
- Το χωριό είναι 1120x720. Το αρχικό χωριό βρίσκεται στο (VOX, VOY) μέσα στον μεγαλύτερο κόσμο (δες `game/art/vil.js`).
